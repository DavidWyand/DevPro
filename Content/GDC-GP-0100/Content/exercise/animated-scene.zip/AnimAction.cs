using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev
{
    public struct AnimAction
    {
        /// <summary>
        /// Action to take at the end of the animation
        /// </summary>
        public enum EndAction
        {
            Stop,
            Restart,
            Reverse
        };

        private bool _isAnimating;

        private int _startCell;
        private int _endCell;
        private float _totalTime;
        private float _timeLeft;
        private float _step;
        private EndAction _endAction;

        /// <summary>
        /// Currently animating?
        /// </summary>
        public bool IsAnimating
        {
            get { return _isAnimating; }
        }

        /// <summary>
        /// Begin a cell animation
        /// </summary>
        /// <param name="startCell">The starting cell index for the animation</param>
        /// <param name="endCell">The ending cell index for the animation</param>
        /// <param name="timeInMilliseconds">Time taken to play through the cell animation, in milliseconds</param>
        /// <param name="endAction">Action to take when the animation reaches the end</param>
        public void Activate(int startCell, int endCell, int time, EndAction endAction = EndAction.Restart)
        {
            _isAnimating = true;
            _endAction = endAction;
            _startCell = startCell;
            _endCell = endCell;
            _totalTime = time;
            _timeLeft = time;

            if(time > 0)
            {
                _step = ((float)((endCell+1) - startCell)) / ((float)time);
            }
        }

        /// <summary>
        /// Perform a single step through the cell animation
        /// </summary>
        /// <param name="delta">Time that has passed, in milliseconds</param>
        /// <returns>The cell index to display</returns>
        public int Update(float delta)
        {
            if(!_isAnimating)
            {
                return 0;
            }

            int result = 0;
            _timeLeft -= delta;
            if(_timeLeft > 0.0f)
            {
                // Calculate a new cell index
                result = _calculateResult();
            }
            else
            {
                // The elapsed timeInMilliseconds has reached the end of the cell animation.  Determine what to do next.
                switch(_endAction)
                {
                    case EndAction.Restart:
                        // Reset the timeInMilliseconds and return the starting value.  Take into account any left over
                        // timeInMilliseconds from the last loop through the animation.
                        _timeLeft = _totalTime + _timeLeft;
                        result = _calculateResult();
                        break;

                    case EndAction.Reverse:
                        // Reverse the direction
                        _step *= -1.0f;
                        int temp = _startCell;
                        _startCell = _endCell;
                        _endCell = temp;

                        // Reset the timeInMilliseconds left but also take into account any current remaining timeInMilliseconds
                        _timeLeft = _totalTime + _timeLeft;

                        result = _calculateResult();
                        break;

                    default:
                        // EndAction.Stop
                        _isAnimating = false;
                        result = _endCell;
                        break;
                }
            }

            return result;
        }

        /// <summary>
        /// Calculate the current cell index
        /// </summary>
        /// <returns>The calculated cell index</returns>
        private int _calculateResult()
        {
            return _startCell + (int)Math.Floor((double)(_step * (_totalTime - _timeLeft)));
        }
    }
}
