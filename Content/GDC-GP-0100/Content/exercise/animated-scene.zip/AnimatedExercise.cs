using Microsoft.Xna.Framework;
using GameDev.Utilities;

namespace GameDev.Exercises
{
    class AnimatedExercise : Module
    {
//*********** Begin Focus Area 1 **************//
        #region Sprites and Textures
        private float _textureRatio = 17f;        

        private SpriteManager _spriteManager = new SpriteManager();

        private Sprite _background;
        private SpriteTexture _backgroundTexture;

        private Sprite _bubble;
        private SpriteTexture _bubbleTexture;

        private Sprite _bubbleBackPlate;
        private SpriteTexture _bubbleBackPlateTexture;

        private Sprite _fishbowl;
        private SpriteTexture _fishbowlTexture;

        private Sprite _fishingline;
        private SpriteTexture _fishinglineTexture;

        private Sprite _moon;
        private SpriteTexture _moonTexture;

        private Sprite _pig;
        private SpriteTexture _pigTexture;

        private Sprite _turtleBackFlipper1;
        private SpriteTexture _turtleBackFlipper1Texture;

        private Sprite _turtleBackFlipper2;
        private SpriteTexture _turtleBackFlipper2Texture;

        private Sprite _turtleEye;
        private SpriteTexture _turtleEyeTexture;

        private Sprite _turtleEyelids;
        private SpriteTexture _turtleEyelidsTexture;

        private Sprite _turtleFrontFlipper1;
        private SpriteTexture _turtleFrontFlipper1Texture;

        private Sprite _turtleFrontFlipper2;
        private SpriteTexture _turtleFrontFlipper2Texture;

        private Sprite _turtleHead;
        private SpriteTexture _turtleHeadTexture;

        private Sprite _turtleShell;
        private SpriteTexture _turtleShellTexture;
        #endregion

        public enum FlightPattern
        {
            Circle = 0,
            Chaos,
            FigureEight,
        };

//*********** End Focus Area 1 **************//

        

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            // Initialize the SpriteManager for this module
            _spriteManager = new SpriteManager();

            // Initialize sprites and textures
            _turtleShell = new Sprite(9);
            _turtleShellTexture = new SpriteTexture("Graphics\\art_turtleshell");

            _turtleHead = new Sprite(10);
            _turtleHeadTexture = new SpriteTexture("Graphics\\art_turtle_head");            

            _background = new Sprite(0);
            _backgroundTexture = new SpriteTexture("Graphics\\background");

            //*********** Begin Focus Area 2 ***********//

            // Turtle eyelids (layer 12)

            // Turtle eye (layer 11)

            // Turtle front flipper 1 (layer 10)

            // Turtle front flipper 2 (layer 8)

            // Turtle back flipper 1 (layer 8)

            // Turtle back flipper 2 (layer 8)

            // Bubble back plate (layer 7)

            // Bubble (layer 8)

            // Fishing line (layer 11)

            // Fishbowl (layer 11)

            // Moon (layer 9)

            // Pig (layer 8)

            //*********** End Focus Area 2 ***********//

        }

        /// <summary>
        /// Set the turtle sprites' properties and add them to the SpriteManager
        /// </summary>
        private void CreateTurtle()
        {
            // Shell
            _turtleShell.SetSpriteTexture(_turtleShellTexture);
            _turtleShell.SetSize(_turtleShellTexture.ImageWidth / _textureRatio, _turtleShellTexture.ImageHeight / _textureRatio);
            _turtleShell.SetPosition(-5, -2);
            _turtleShell.MoveAmount(new Vector2(0f, 0.4f), 1000, MotionAction.EndAction.Reverse);
            _spriteManager.AddSprite(_turtleShell);

            // Head
            _turtleHead.SetSpriteTexture(_turtleHeadTexture);
            _turtleHead.SetSize(_turtleHeadTexture.ImageWidth / _textureRatio, _turtleHeadTexture.ImageHeight / _textureRatio);
            _turtleHead.SetPosition(-21.0f, -9f);
            _turtleHead.MoveAmount(new Vector2(0f, 0.4f), 1000, MotionAction.EndAction.Reverse);
            _spriteManager.AddSprite(_turtleHead);

            //*********** Begin Focus Area 3 ***********//

            // Eye - MoveAmount same as _turtleHead; SetPivotPoint to 0.1, 0.1; RotateContinuous 180 degrees (remember to convert to Radians) over 500 milliseconds

            // Eyelids - MoveAmount same as _turtleHead

            // Front flipper (x2) - MoveAmount same as _turtleHead; SetPivotPoint to -0.5, 0.5; RotateAmount 5 degrees over 800 ms, reverse at end

            // Back flipper (x2) - MoveAmount same as _turtleHead; SetPivotPoint to -0.5, 0.5; RotateAmount 5 degrees over 800 ms, reverse at end

            //*********** End Focus Area 3 ***********//

        }

        /// <summary>
        /// Create the props that decorate the turtle: Bubble plate, bubble, and fishing line.
        /// </summary>
        private void CreateTurtleProps()
        {
            // Create four flags
            CreateFlag(new Vector2(-16, 6.3f), GetConvertedColor(58, 215, 84));
            CreateFlag(new Vector2(-19.2f, 5.2f), GetConvertedColor(210, 56, 92));
            CreateFlag(new Vector2(-17.7f, 3.8f), GetConvertedColor(212, 133, 56));
            CreateFlag(new Vector2(-16, 1.1f), GetConvertedColor(58, 215, 84));

            //*********** Begin Focus Area 4 ***********//

            // Add the bubble plate - MoveAmount same as _turtleHead


            // Create the bubble - SetSize(1, 1); MoveTo(20, 45, 15000, Restart); SizeTo(textureWidth / textureRatio, textureHeight / textureRatio, 15000, Restart)


            // Add the fishing line - MoveAmount same as _turtleHead; SetPivotPoint to 0.0, 0.5; RotateContinuous(180 degrees, 2000)

            //*********** End Focus Area 4 ***********//

        }

        /// <summary>
        /// Create the sprites for the background, moon, and fishbowl.
        /// </summary>
        private void CreateEnvironment()
        {
            // Add the background
            _background.SetSpriteTexture(_backgroundTexture);
            _background.SetSize(_backgroundTexture.ImageWidth / _textureRatio, _backgroundTexture.ImageHeight / _textureRatio);
            _spriteManager.AddSprite(_background);

            //*********** Begin Focus Area 5 ***********//

            // Add the moon and rotate continuously 


            // Add the fishbowl and rotate continuously


            // Add the pig and make it move back & forth, also scaling
            // (MoveAmount(-4, 2, 1800, MotionAction.EndAction.Reverse)
            // SizeTo(_pig.Size * 0.8f, 2000, MotionAction.EndAction.Reverse);
            
            //*********** End Focus Area 5 ***********//

        }

        /// <summary>
        /// Create a flag. Size, animation, and adding to the SpriteManager are automatic.
        /// </summary>        
        /// <param name="position">X/Y position for the flag</param>
        /// <param name="color">The tint of the sprite, since the source images are greyscale</param>
        private void CreateFlag(Vector2 position, Vector4 color)
        {
            //*********** Begin Focus Area 6 ***********//

            // Create the SpriteTexture for the flag. 
            // Remember to set the cell width/height and load the content

            // Create the flag sprite (set the layer too)            

            // Set the flag sprite texture

            // Set the flag sprite size

            // Set the flag sprite position

            // Set flag sprite tint

            // Animate through the five cells and restart            

            // Add the flag sprite to the sprite manager

            //*********** End Focus Area 6 ***********//
          
        }

        /// <summary>
        /// Create a butterfly. Size, animation, and adding to the SpriteManager are automatic.
        /// </summary>        
        /// <param name="position">The X/Y position for the butterfly</param>
        /// <param name="color">The color tint for the butterfly, since the source image is greyscale</param>
        private void CreateButterfly(Vector2 position, Vector4 color, FlightPattern pattern)
        {
            //*********** Begin Focus Area 7 ***********//

            // Create the SpriteTexture for the butterfly. 
            // Remember to set the cell width/height and load the content

            // Create the butterfly sprite (set the layer too)                        

            // Set the butterfly sprite texture

            // Set the butterfly sprite size

            // Set the butterfly sprite position

            // Set butterfly sprite tint

            // Animate through the two cells and restart            

            // Animate motion based on type
            switch (pattern)
            {
                case FlightPattern.Circle:
                    var circleTime = (int)((((2.0f * MathHelper.Pi * 5.0f) / 5.0f) * 1000) / 2);

                    // Set pivot point to 1.0, 1.0

                    // Rotate continuously by -180 degrees, at a rate of circleTime

                    break;

                case FlightPattern.Chaos:
                    var ovaltime = (int)(((2.0f * MathHelper.Pi * 5.0f) / 5.0f) * 400);

                    // Set pivot point to 0.5, 3.0f

                    // Move To position.X + 6, position.Y + 10, ovaltime, Reverse

                    // Rotate continuously by -90 degrees, at a rate of ovaltime

                    break;

                case FlightPattern.FigureEight:

                    // Set pivot point to 0.0f, -0.5

                    // Rotate continuously by 180 degrees, 1 second

                    // Move Amount 10, 0, 1.8 seconds, Reverse

                    break;
            }

            // Add the butterfly sprite to the sprite manager            

            //*********** End Focus Area 7 ***********//

        }

        /// <summary>
        /// Create a star that falls through the sky
        /// </summary>
        /// <param name="position">Starting X/Y position for the sta.r</param>
        /// <param name="target">Ending X/Y position for the star.</param>
        /// <param name="descentTime">The timeInMilliseconds it takes the star to travel between position and target, in milliseconds</param>
        private void CreateStar(Vector2 position, Vector2 target, int descentTime)
        {
            //*********** Begin Focus Area 8 ***********//

            // Create the SpriteTexture for the star. 
            // Remember to load the content

            // Create the star sprite (set the layer too)            

            // Set the star sprite texture

            // Set the star sprite size

            // Set the star sprite position            

            // Animation - MoveTo(target, descentTime, Restart), RotateContinuous(360 degrees, 2 seconds)

            // Add the star sprite to the sprite manager

            //*********** End Focus Area 8 ***********//

        }

        /// <summary>
        /// Add the really weird stuff to the scene, such as butterflies and stars.
        /// </summary>
        private void CreateChaos()
        {
            CreateButterfly(new Vector2(8.2f, -4.0f), new Vector4(0.95f, 0.53f, 0.08f, 1f), FlightPattern.Circle);
            CreateButterfly(new Vector2(14.9f, -3.8f), new Vector4(0.75f, 0.28f, 0.23f, 1f), FlightPattern.FigureEight);
            CreateButterfly(new Vector2(14.5f, -1.0f), new Vector4(0.41f, 0.12f, 0.49f, 1f), FlightPattern.Chaos);
            CreateButterfly(new Vector2(1.1f, -6.8f), new Vector4(0.06f, 0.61f, 0.83f, 1f), FlightPattern.FigureEight);

            CreateStar(new Vector2(-83, 57), new Vector2(53, -37), 2000);
            CreateStar(new Vector2(-53, 57), new Vector2(40, -37), 3000);
            CreateStar(new Vector2(-23, 57), new Vector2(80, -57), 8000);
            CreateStar(new Vector2(-53, 57), new Vector2(53, -37), 9000);
        }

        /// <summary>
        /// Load the textures that are set as properties in this module, as opposed to the 
        /// textures used in creating dynamic sprites (stars, flags, butterflies)
        /// </summary>
        private void LoadTextures()
        {
            _backgroundTexture.LoadContent(_contentManager);
            _turtleHeadTexture.LoadContent(_contentManager);
            _turtleShellTexture.LoadContent(_contentManager);

            _bubbleTexture.LoadContent(_contentManager);
            _bubbleBackPlateTexture.LoadContent(_contentManager);
            _fishbowlTexture.LoadContent(_contentManager);
            _fishinglineTexture.LoadContent(_contentManager);
            _moonTexture.LoadContent(_contentManager);
            _pigTexture.LoadContent(_contentManager);
            _turtleBackFlipper1Texture.LoadContent(_contentManager);
            _turtleBackFlipper2Texture.LoadContent(_contentManager);
            _turtleEyeTexture.LoadContent(_contentManager);
            _turtleEyelidsTexture.LoadContent(_contentManager);
            _turtleFrontFlipper1Texture.LoadContent(_contentManager);
            _turtleFrontFlipper2Texture.LoadContent(_contentManager);        
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();

            LoadTextures();
            CreateTurtle();
            CreateTurtleProps();
            CreateEnvironment();
            CreateChaos();
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="timeInMilliseconds">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Update all sprites
            _spriteManager.UpdateSprites(time);
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            base.Render();

            // Render all sprites
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);
        }

        /// <summary>
        /// Convert red, green, blue color values with a range of 0 - 255, to a Vector4 with a range of 0.0 to 1.0
        /// </summary>
        /// <param name="red">0-255 value for red</param>
        /// <param name="green">0-255 value for green</param>
        /// <param name="blue">0-255 value for blue</param>
        /// <returns></returns>
        private Vector4 GetConvertedColor(float red, float green, float blue)
        {
            var output = new Vector4();
            output.X = red / 255;
            output.Y = green / 255;
            output.Z = blue / 255;
            output.W = 1.0f;
            return output;
        }
    }
}