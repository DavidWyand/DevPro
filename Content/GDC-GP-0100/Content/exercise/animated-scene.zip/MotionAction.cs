using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev
{
    public struct MotionAction
    {
        /// <summary>
        /// Action to take at the end of the motion
        /// </summary>
        public enum EndAction
        {
            Stop,
            Restart,
            Reverse,
            Continuous
        };

        private bool _inMotion;

        private float _start;
        private float _destination;
        private float _totalTime;
        private float _timeLeft;
        private float _step;
        private EndAction _endAction;

        /// <summary>
        /// Currently in motion?
        /// </summary>
        public bool IsInMotion
        {
            get { return _inMotion; }
        }

        /// <summary>
        /// Will the Update() method return a relative or absolute value?
        /// </summary>
        public bool IsRelativeMotion
        {
            get { return _endAction == EndAction.Continuous; }
        }

        /// <summary>
        /// Begin a motion
        /// </summary>
        /// <param name="start">The starting value for the motion</param>
        /// <param name="destination">The ending value for the motion</param>
        /// <param name="timeInMilliseconds">Time taken to play through the motion, in milliseconds</param>
        /// <param name="endAction">Action to take when the motion reaches the end</param>
        public void Activate(float start, float destination, int time, EndAction endAction = EndAction.Stop)
        {
            _inMotion = true;
            _endAction = endAction;
            _start = start;
            _destination = destination;
            _totalTime = time;
            _timeLeft = time;

            if (time > 0)
            {
                _step = (_destination - _start) / time;
            }
        }

        /// <summary>
        /// Perform a single step through the motion
        /// </summary>
        /// <param name="delta">Time that has passed, in milliseconds</param>
        /// <returns>The calculated motion value</returns>
        public float Update(float delta)
        {
            if (!_inMotion)
                return _destination;

            // Continuous motion doesn't stop and returns the amount to step by
            if (_endAction == EndAction.Continuous)
            {
                return _step * delta;
            }

            // Handle non-continuous motion
            _timeLeft -= delta;
            float result = 0.0f;
            if (_timeLeft > 0.0f)
            {
                // Calculate a new motion value
                result = _calculateResult();
            }
            else
            {
                // The elapsed timeInMilliseconds has reached the end of the motion.  Determine what to do next.
                switch (_endAction)
                {
                    case EndAction.Restart:
                        // Reset the timeInMilliseconds and return the starting value.  Take into account any left over
                        // timeInMilliseconds from the last loop through the motion.
                        _timeLeft = _totalTime + _timeLeft;
                        result = _calculateResult();
                        break;

                    case EndAction.Reverse:
                        // Reverse the direction
                        _step *= -1.0f;
                        float temp = _start;
                        _start = _destination;
                        _destination = temp;

                        // Reset the timeInMilliseconds left but also take into account any current remaining timeInMilliseconds
                        _timeLeft = _totalTime + _timeLeft;

                        result = _calculateResult();
                        break;

                    default:
                        // EndAction.Stop
                        _inMotion = false;
                        result = _destination;
                        break;
                }
            }

            return result;
        }

        /// <summary>
        /// Calculate the current motion value
        /// </summary>
        /// <returns>The calculated motion value</returns>
        private float _calculateResult()
        {
            return _start + _step * (_totalTime - _timeLeft);
        }
    }
}