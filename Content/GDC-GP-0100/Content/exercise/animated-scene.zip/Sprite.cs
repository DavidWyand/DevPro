using System;
using Microsoft.Xna.Framework;
using GameDev.Utilities;

namespace GameDev
{
    public class Sprite
    {
        #region Member Variables

        // Properties of the sprite
        private SpriteQuad _quad;
        private SpriteTexture _texture;

        private Matrix _translationMatrix;
        private Vector2 _translation;
        private Matrix _pivotPointMatrix;
        private Vector2 _pivotPoint;
        private Matrix _rotationMatrix;
        private float _rotation;
        private Matrix _sizeMatrix;
        private Vector2 _size;
        private Vector4 _tint;
        private bool _visible = true;

        // These are used for motion
        private MotionAction _moveToX;
        private MotionAction _moveToY;
        private MotionAction _rotateTo;
        private MotionAction _sizeToX;
        private MotionAction _sizeToY;
        
        // This is used for animation
        private AnimAction _animate;

        // Rendering layer for the sprite.  Lower values render first.
        private int _layer;

        #endregion

        #region Properties

        /// <summary>
        /// Current position of the sprite
        /// </summary>
        public Vector2 Position
        {
            get { return _translation; }
        }

        /// <summary>
        /// Set the position of the sprite
        /// </summary>
        /// <param name="x">Sprite x position</param>
        /// <param name="y">Sprite y position</param>
        public void SetPosition(float x, float y)
        {
            //*********** Begin Focus Area 1 ***********//

            // Store the x/y in the translation property

            //*********** End Focus Area 1 ***********//


            //*********** Begin Focus Area 2 ***********//

            // Create a translation matrix

            //*********** End Focus Area 2 ***********//

        }

        /// <summary>
        /// Current rotation of the sprite
        /// </summary>
        public float Rotation
        {
            get { return _rotation; }
        }

        /// <summary>
        /// Set the rotation of the sprite
        /// </summary>
        /// <param name="rot">Sprite rotation in radians</param>
        public void SetRotation(float rot)
        {
            //*********** Begin Focus Area 3 ***********//

            // Store the rotation in the correct property

            //*********** End Focus Area 3 ***********//


            //*********** Begin Focus Area 4 ***********//

            // Create a rotation matrix

            //*********** End Focus Area 4 ***********//

        }

        /// <summary>
        /// Size of the sprite
        /// </summary>
        public Vector2 Size
        {
            get { return _size; }
        }

        /// <summary>
        /// Set the size of the sprite
        /// </summary>
        /// <param name="x">Size of sprite in the x axis</param>
        /// <param name="y">Size of sprite in the y axis</param>
        public void SetSize(float x, float y)
        {
            //*********** Begin Focus Area 5 ***********//

            // Store the size

            //*********** End Focus Area 5 ***********//


            //*********** Begin Focus Area 6 ***********//

            // Create a scale matrix

            //*********** End Focus Area 6 ***********//

        }

        /// <summary>
        /// Rotation pivot point of the sprite.  In pre-sized coordinates (-0.5 to 0.5)
        /// </summary>
        public Vector2 PivotPoint
        {
            get { return _pivotPoint; }
        }

        /// <summary>
        /// Set the rotation pivot point of the sprite
        /// </summary>
        /// <param name="x">Local X axis pivot point location, in pre-sized coordinates (-0.5 to 0.5)</param>
        /// <param name="y">Local Y axis pivot point location, in pre-sized coordinates (-0.5 to 0.5)</param>
        public void SetPivotPoint(float x, float y)
        {
            // We need to negate the passed in values as we want to move the pivot point down
            // rather than move the sprite's image down.
            _pivotPoint.X = x * -1.0f;
            _pivotPoint.Y = y * -1.0f;

            //*********** Begin Focus Area 7 ***********//

            // Create a translation matrix for the pivot point

            //*********** End Focus Area 7 ***********//

        }

        /// <summary>
        /// Has the sprite's texture been flipped horizontally?
        /// </summary>
        public bool FlipHorizontal
        {
            get { return _quad.FlipHorizontal; }
        }

        /// <summary>
        /// Set the sprite's texture to be flipped horizontally
        /// </summary>
        /// <param name="flip">If true then the sprite's texture will be flipped horizontally</param>
        public void SetFlipHorizontal(bool flip)
        {
            _quad.SetFlipHorizontal(flip);
        }

        /// <summary>
        /// Has the sprite's texture been flipped vertically?
        /// </summary>
        public bool FlipVertical
        {
            get { return _quad.FlipVertical; }
        }

        /// <summary>
        /// Set the sprite's texture to be flipped vertically
        /// </summary>
        /// <param name="flip">If true then the sprite's texture will be flipped vertically</param>
        public void SetFlipVertical(bool flip)
        {
            _quad.SetFlipVertical(flip);
        }

        /// <summary>
        /// Get the current color tint of the sprite
        /// </summary>
        public Vector4 Tint
        {
            get { return _tint; }
        }

        /// <summary>
        /// Set the sprite's tint colour and alpha values
        /// </summary>
        /// <param name="tint">Tint in the form of red, green, blue, alpha</param>
        public void SetTint(Vector4 tint)
        {
            _tint = tint;
            _quad.SetColor(_tint);
        }

        /// <summary>
        /// Get the sprite's rendering layer
        /// </summary>
        public int Layer
        {
            get { return _layer; }
        }

        /// <summary>
        /// Get the sprite's visibility status.
        /// </summary>
        public bool Visible
        {
            get { return _visible; }
        }

        #endregion

        /// <summary>
        /// Sprite constructor
        /// </summary>
        /// <param name="layer">Rendering layer of the sprite (defaults to 0).  Lower values render first.</param>
        public Sprite(int layer=0)
        {
            //*********** Begin Focus Area 8 ***********//

            // Build the SpriteQuad

            //*********** End Focus Area 8 ***********//


            //*********** Begin Focus Area 9 ***********//

            // Default values for each of the sprite's matrices
            //_translationMatrix = 
            //_translation = 

            //*********** End Focus Area 9 ***********//


            //*********** Begin Focus Area 10 ***********//

            //_pivotPointMatrix = 
            //_pivotPoint = 

            //*********** End Focus Area 10 ***********//


            //*********** Begin Focus Area 11 ***********//

            //_rotationMatrix = 
            //_rotation = 

            //*********** End Focus Area 11 ***********//


            //*********** Begin Focus Area 12 ***********//

            //_sizeMatrix = 
            //_size = 

            //*********** End Focus Area 12 ***********//


            // Default color tint of all white
            _tint = Vector4.One;

            // Store the layer the sprite will render on
            _layer = layer;
        }

        /// <summary>
        /// Set the sprite's texture used for rendering
        /// </summary>
        /// <param name="content">Content manager</param>
        /// <param name="texture">SpriteTexture</param>
        public void SetSpriteTexture(SpriteTexture texture)
        {
            _texture = texture;
            _quad.SetSpriteTexture(_texture);
        }

        #region Motion Methods

        /// <summary>
        /// Move to an absolute location over the given timeInMilliseconds span
        /// </summary>
        /// <param name="x">Absolute destination X</param>
        /// <param name="y">Absolute destination Y</param>
        /// <param name="timeInMilliseconds">Time to reach destination in milliseconds</param>
        /// <param name="endAction">What happens when the final position is reached</param>
        public void MoveTo(float x, float y, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            Vector2 destination;
            destination.X = x;
            destination.Y = y;
            MoveTo(destination, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Move to an absolute location over the given timeInMilliseconds span
        /// </summary>
        /// <param name="destination">Absolute destination</param>
        /// <param name="timeInMilliseconds">Time to reach destination in milliseconds</param>
        /// <param name="endAction">What happens when the final position is reached</param>
        public void MoveTo(Vector2 destination, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            _moveToX.Activate(_translation.X, destination.X, timeInMilliseconds, endAction);
            _moveToY.Activate(_translation.Y, destination.Y, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Move by a relative amount over the given timeInMilliseconds span
        /// </summary>
        /// <param name="relativeX">Amount to move in the X direction</param>
        /// <param name="relativeY">Amount to move in the Y direction</param>
        /// <param name="timeInMilliseconds">Time to reach destination in milliseconds</param>
        /// <param name="endAction">What happens when the final destination is reached></param>
        public void MoveAmount(float relativeX, float relativeY, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            Vector2 move;
            move.X = relativeX;
            move.Y = relativeY;
            MoveAmount(move, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Move by a relative amount over the given timeInMilliseconds span
        /// </summary>
        /// <param name="relativeMove">Amount to move</param>
        /// <param name="timeInMilliseconds">Time to reach destination in milliseconds</param>
        /// <param name="endAction">What happens when the final destination is reached</param>
        public void MoveAmount(Vector2 relativeMove, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            _moveToX.Activate(_translation.X, _translation.X + relativeMove.X, timeInMilliseconds, endAction);
            _moveToY.Activate(_translation.Y, _translation.Y + relativeMove.Y, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Rotate to an absolute angle over the given timeInMilliseconds span
        /// </summary>
        /// <param name="absoluteAngle">Absolute angle in radians</param>
        /// <param name="timeInMilliseconds">Time to reach destination in milliseconds</param>
        /// <param name="endAction">What happens when the final angle is reached</param>
        public void RotateTo(float absoluteAngle, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            _rotateTo.Activate(_rotation, absoluteAngle, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Rotate by a relative angle over the given timeInMilliseconds span
        /// </summary>
        /// <param name="relativeAngle">Amount to rotate in radians</param>
        /// <param name="timeInMilliseconds">Time to reach destination in milliseconds</param>
        /// <param name="endAction">What happens when the final angle is reached</param>
        public void RotateAmount(float relativeAngle, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            _rotateTo.Activate(_rotation, _rotation + relativeAngle, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Continuously rotate by the given angle at the given rate
        /// </summary>
        /// <param name="angle">Amount to rotate over timeInMilliseconds in radians</param>
        /// <param name="timeInMilliseconds">The timeInMilliseconds it takes to rotate the given amount, in milliseconds</param>
        public void RotateContinuous(float angle, int timeInMilliseconds)
        {
            _rotateTo.Activate(_rotation, _rotation + angle, timeInMilliseconds, MotionAction.EndAction.Continuous);
        }

        /// <summary>
        /// Resize the sprite to an absolute size over the given timeInMilliseconds span
        /// </summary>
        /// <param name="x">Absolute size along X axis</param>
        /// <param name="y">Absolute size along Y axis</param>
        /// <param name="timeInMilliseconds">Time taken to reach new size in milliseconds</param>
        /// <param name="endAction">What happens when the final size is reached</param>
        public void SizeTo(float x, float y, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            Vector2 finalSize;
            finalSize.X = x;
            finalSize.Y = y;
            SizeTo(finalSize, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Resize the sprite to an absolute size over the given timeInMilliseconds span
        /// </summary>
        /// <param name="finalSize">Absolute size</param>
        /// <param name="timeInMilliseconds">Time taken to reach new size in milliseconds</param>
        /// <param name="endAction">What happens when the final size is reached</param>
        public void SizeTo(Vector2 finalSize, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            _sizeToX.Activate(_size.X, finalSize.X, timeInMilliseconds, endAction);
            _sizeToY.Activate(_size.Y, finalSize.Y, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Resize by a realtive amount over the given timeInMilliseconds span
        /// </summary>
        /// <param name="relativeSizeX">Amount to resize along the X axis</param>
        /// <param name="relativeSizeY">Amount to resize along the Y axis</param>
        /// <param name="timeInMilliseconds">Time taken to reach new size in milliseconds</param>
        /// <param name="endAction">What happens when the final size is reached</param>
        public void SizeAmount(float relativeSizeX, float relativeSizeY, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            Vector2 size;
            size.X = relativeSizeX;
            size.Y = relativeSizeY;
            SizeAmount(size, timeInMilliseconds, endAction);
        }

        /// <summary>
        /// Resize by a relative amount over the given timeInMilliseconds span
        /// </summary>
        /// <param name="relativeSize">Amount to resize</param>
        /// <param name="timeInMilliseconds">Time taken to reach new size in milliseconds</param>
        /// <param name="endAction">What happens when the final size is reached</param>
        public void SizeAmount(Vector2 relativeSize, int timeInMilliseconds, MotionAction.EndAction endAction = MotionAction.EndAction.Stop)
        {
            _sizeToX.Activate(_size.X, _size.X + relativeSize.X, timeInMilliseconds, endAction);
            _sizeToY.Activate(_size.Y, _size.Y + relativeSize.Y, timeInMilliseconds, endAction);
        }

        #endregion

        #region Animation Methods

        /// <summary>
        /// Start the sprite's cell animation
        /// </summary>
        /// <param name="startCell">Animation's starting cell index</param>
        /// <param name="endCell">Animation's ending cell index</param>
        /// <param name="timeInMilliseconds">Time taken to animate through the cells, in milliseconds</param>
        /// <param name="endAction">What happens when the final cell is reached</param>
        public void Animate(int startCell, int endCell, int timeInMilliseconds, AnimAction.EndAction endAction = AnimAction.EndAction.Restart)
        {
            _animate.Activate(startCell, endCell, timeInMilliseconds, endAction);
        }

        #endregion

        /// <summary>
        /// Update the sprite's actions and animation, if any
        /// </summary>
        /// <param name="timeInMilliseconds">Time that has passed</param>
        public void Update(GameTime time)
        {
            // Determine how much timeInMilliseconds has passed, in milliseconds
            TimeSpan deltaTimeSpan = time.ElapsedGameTime;
            float deltaTime = (float)deltaTimeSpan.TotalMilliseconds;

            // Movement
            if(_moveToX.IsInMotion || _moveToY.IsInMotion)
            {
                float posX = _moveToX.Update(deltaTime);
                float posY = _moveToY.Update(deltaTime);
                SetPosition(posX, posY);
            }

            // Rotation
            if(_rotateTo.IsInMotion)
            {
                float rot = _rotateTo.Update(deltaTime);

                if (!_rotateTo.IsRelativeMotion)
                {
                    SetRotation(rot);
                }
                else
                {
                    float finalRot = _rotation + rot;

                    // Keep rotation within proper values.
                    while(finalRot > MathHelper.ToRadians(360.0f))
                    {
                        finalRot -= MathHelper.ToRadians(360.0f);
                    }
                    while(finalRot < 0.0f)
                    {
                        finalRot += MathHelper.ToRadians(360.0f);
                    }

                    SetRotation(finalRot);
                }
            }

            // Scale
            if(_sizeToX.IsInMotion || _sizeToY.IsInMotion)
            {
                float sizeX = _sizeToX.Update(deltaTime);
                float sizeY = _sizeToY.Update(deltaTime);
                SetSize(sizeX, sizeY);
            }

            // Animation
            if(_animate.IsAnimating)
            {
                int cell = _animate.Update(deltaTime);
                _texture.SetCell(cell);
            }
        }

        /// <summary>
        /// Render the sprite
        /// </summary>        
        /// <param name="camera">The camera used to render with</param>
        /// <param name="updateStates">Should the sprite update the various render states?  Defaults to true.</param>
        public void Render(Camera camera)
        {
            // Calculate the World * View * Projection matrix
            Matrix world;
            world = _pivotPointMatrix * _sizeMatrix * _rotationMatrix * _translationMatrix;
            Matrix worldViewProjection;
            worldViewProjection = world * camera.GetView() * camera.GetProjection();

            _quad.SetWorldViewProjection(worldViewProjection);

            _quad.Render();
        }
    }
}
