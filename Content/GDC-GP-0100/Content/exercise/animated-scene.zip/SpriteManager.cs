using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GameDev
{
    class SpriteManager
    {
        /// <summary>
        /// Used by the sorted sprite list to sort by sprite _layer
        /// </summary>
        class LayerCompare : IComparer<Sprite>
        {
            public int Compare(Sprite x, Sprite y)
            {
                if (x.Layer < y.Layer)
                {
                    return -1;
                }
                else if (x.Layer > y.Layer)
                {
                    return 1;
                }

                return 0;
            }
        }

        static LayerCompare _renderLayerCompare = new LayerCompare();

        /// <summary>
        /// Holds a list of sprites that will be automatically rendered using the
        /// static methods.  This is list is sorted by _layer.  This list takes the place
        /// of a scene manager that would be part of a larger game engine.
        /// </summary>
        static private List<Sprite> _spriteList = new List<Sprite>();

        public static List<Sprite> SpriteList
        {
            get
            {
                return _spriteList;
            }
        }

        /// <summary>
        /// Update the render states for the sprites
        /// </summary>
        /// <param name="graphics">Graphics device</param>
        private void _updateRenderStates(GraphicsDevice graphics)
        {
            BlendState blendState = new BlendState();
            blendState.AlphaBlendFunction = BlendFunction.Add;
            blendState.AlphaSourceBlend = Blend.SourceAlpha;
            blendState.ColorSourceBlend = Blend.SourceAlpha;
            blendState.AlphaDestinationBlend = Blend.InverseSourceAlpha;
            blendState.ColorDestinationBlend = Blend.InverseSourceAlpha;
            graphics.BlendState = blendState;

            DepthStencilState depthState = new DepthStencilState();
            depthState.DepthBufferEnable = true;
            depthState.DepthBufferFunction = CompareFunction.LessEqual;
            depthState.DepthBufferWriteEnable = true;
            graphics.DepthStencilState = depthState;

            RasterizerState state = new RasterizerState();
            state.CullMode = CullMode.None;
            graphics.RasterizerState = state;
        }

        /// <summary>
        /// Add a sprite to the manager
        /// </summary>
        /// <param name="sprite">Sprite class</param>
        public void AddSprite(Sprite sprite)
        {
            _spriteList.Add(sprite);
            _spriteList.Sort(_renderLayerCompare);
        }

        /// <summary>
        /// Add a list of sprites to the manager
        /// </summary>
        /// <param name="sprites">Array of Sprite objects</param>
        public void AddSprites(Sprite[] sprites)
        {
            foreach(Sprite sprite in sprites)
            {
                _spriteList.Add(sprite);
                _spriteList.Sort(_renderLayerCompare);
            }
        }

        /// <summary>
        /// Remove a sprite from the manager
        /// </summary>
        /// <param name="sprite">Sprite class</param>
        public void RemoveSprite(Sprite sprite)
        {
            _spriteList.Remove(sprite);
        }

        /// <summary>
        /// Update all sprites
        /// </summary>
        /// <param name="timeInMilliseconds">GameTime</param>
        public void UpdateSprites(GameTime time)
        {
            foreach (Sprite s in _spriteList)
            {
                s.Update(time);
            }
        }

        /// <summary>
        /// Render all sprites
        /// </summary>
        /// <param name="graphics">Graphics device</param>
        /// <param name="camera">Camera used for view and projection matrices</param>
        public void RenderSprites(GraphicsDevice graphics, GameDev.Utilities.Camera camera)
        {
            _updateRenderStates(graphics);

            foreach (Sprite s in _spriteList)
            {
                // Only render if the Sprite is visible
                if (s.Visible)
                    s.Render(camera);
            }
        }
    }
}
