using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace GameDev
{
    public class SpriteQuad
    {
        #region Member Variables

        // Coordinates of the quad
        private Vector3 _origin;
        private Vector3 _upperLeft;
        private Vector3 _lowerLeft;
        private Vector3 _upperRight;
        private Vector3 _lowerRight;

        // Vertices of the quad
        private VertexPositionTexture[] _vertices;

        private Matrix _worldViewProjection;

        private Vector4 _color;

        // Determines if the quad's texture should be flipped
        private bool _flipHorizontal;
        private bool _flipVertical;

        // Static vertex buffer for the quad
        private VertexBuffer _vertexBuffer;

        // Used to define the sprite's rendering effect
        private Effect _effect;
        private EffectParameter _effectWorldViewProjection;
        private EffectParameter _effectDiffuseColor;
        private EffectParameter _effectTexture;
        private EffectParameter _effectTextureUV;   // A float4 in the form of top, left, sizeU, sizeV

        // Transformed UV's to be passed to the shader for the quad.  Used for cell animation.
        // X = U location in the texture
        // Y = V location in the texture
        // Z = Width of texture used
        // W = Height of the texture used
        private Vector4 _effectUV;

        // The SpriteTexture used to render with
        private SpriteTexture _texture;

        #endregion

        #region Properties

        /// <summary>
        /// Returns true if the quad's texture has been flipped horizontally
        /// </summary>
        public bool FlipHorizontal
        {
            get { return _flipHorizontal; }
        }

        /// <summary>
        /// Set if the quad's texture should be flipped horizontally
        /// </summary>
        /// <param name="flip">Set to true to flip the quad's texture horizontally</param>
        public void SetFlipHorizontal(bool flip)
        {
            _flipHorizontal = flip;
        }

        /// <summary>
        /// Returns true if the quad's texture has been flipped vertically
        /// </summary>
        public bool FlipVertical
        {
            get { return _flipVertical; }
        }

        /// <summary>
        /// Set if the quad's texture should be flipped vertically
        /// </summary>
        /// <param name="flip">Set to true to flip the quad's texture vertically</param>
        public void SetFlipVertical(bool flip)
        {
            _flipVertical = flip;
        }

        /// <summary>
        /// Set the sprite's concatenated world, view, projection matrix
        /// </summary>
        /// <param name="worldViewProjection">Concatenated world, view, projection matrix</param>
        public void SetWorldViewProjection(Matrix worldViewProjection)
        {
            _worldViewProjection = worldViewProjection;
        }

        /// <summary>
        /// Set the color tint used to render the sprite
        /// </summary>
        /// <param name="color">Color in the form of red, green, blue, alpha</param>
        public void SetColor(Vector4 color)
        {
            _color = color;
        }

        #endregion

        /// <summary>
        /// BufferedQuad constructor
        /// </summary>
        /// <param name="origin">Initial world origin of the quad</param>
        /// <param name="width">Initial width of the quad</param>
        /// <param name="height">Initial height of the quad</param>
        /// <param name="flipHorizontal">Should the quad's texture be horizontally flipped?  Defaults to false.</param>
        /// <param name="flipVertical">Should the quad's texture be vertically flipped?  Defaults to false.</param>
        public SpriteQuad(Vector3 origin, float width, float height, bool flipHorizontal = false, bool flipVertical = false)
        {
            // Store the origin
            _origin = origin;

            // Store the two flip properties
            _flipHorizontal = flipHorizontal;
            _flipVertical = flipVertical;

            // Set the world view project to Identity
            _worldViewProjection = Matrix.Identity;

            // Initialize the color property to white
            _color = new Vector4(1.0f, 1.0f, 1.0f, 1.0f);

            //*********** Begin Focus Area 1 ***********//

            // Get the half-width and half-height, so the corners are formed from the origin of the quad (center)
            
            //*********** End Focus Area 1 ***********//


            //*********** Begin Focus Area 2 ***********//

            // Calculate the quad corners based on origin and dimensions
            
            //*********** End Focus Area 2 ***********//


            //*********** Begin Focus Area 3 ***********//

            // Initialize the _vertices

            //*********** End Focus Area 3 ***********//


            //*********** Begin Focus Area 4 ***********//

            // Set the position and texture coordinate for each vertex

            //*********** End Focus Area 4 ***********//

        }

        /// <summary>
        /// Set the sprite's texture used for rendering
        /// </summary>
        /// <param name="contentManager">Content manager</param>
        /// <param name="texture">The SpriteTexture to be used by the sprite</param>
        public void SetSpriteTexture(SpriteTexture texture)
        {
            // Store the SpriteTexture
            _texture = texture;
            ContentManager contentManager = _texture.ContentManager;

            // Load the shader effect used by Sprites
            _effect = contentManager.Load<Effect>("Shaders\\SpriteShader.mgfxo");

            // Extract the shader constants
            _effectWorldViewProjection = _effect.Parameters["WorldViewProjection"];
            _effectDiffuseColor = _effect.Parameters["DiffuseColor"];
            _effectTexture = _effect.Parameters["SpriteTexture"];
            _effectTextureUV = _effect.Parameters["SpriteTextureUV"];

            // Build and set the static vertex buffer
            _vertexBuffer = new VertexBuffer(_texture.Texture.GraphicsDevice, VertexPositionTexture.VertexDeclaration, 4, BufferUsage.None);
            _vertexBuffer.SetData(_vertices);

            // Provide default texture UV values to be passed to the shader
            _effectUV.X = 0.0f;
            _effectUV.Y = 0.0f;
            _effectUV.Z = 1.0f;
            _effectUV.W = 1.0f;
        }

        /// <summary>
        /// Update the UV coordinates used to render the sprite
        /// </summary>
        private void _UpdateUV()
        {
            _effectUV = _texture.TextureUV;

            if(_flipHorizontal)
            {
                float temp = _effectUV.X;
                _effectUV.X = _effectUV.X + _effectUV.Z;
                _effectUV.Z = _effectUV.Z * -1.0f;
            }

            if(_flipVertical)
            {
                float temp = _effectUV.Y;
                _effectUV.Y = _effectUV.Y + _effectUV.W;
                _effectUV.W = _effectUV.W * -1.0f;
            }
        }

        /// <summary>
        /// Render the sprite
        /// </summary>
        /// <param name="graphics">The graphics device</param>
        public void Render()
        {
            GraphicsDevice graphics = _texture.Texture.GraphicsDevice;

            // Check if the texture's UV coordinates have changed.  This can occur
            // during cell animation.
            if(_texture.IsDirty)
            {
                // The texture's UV coordinates have changed so update our values
                _UpdateUV();
            }

            // Need to set up the constants each timeInMilliseconds as the effect may be
            // shared between multiple sprites.
            _effectWorldViewProjection.SetValue(_worldViewProjection);
            _effectTexture.SetValue(_texture.Texture);
            _effectTextureUV.SetValue(_effectUV);
            _effectDiffuseColor.SetValue(_color);

            // Set up the shader effect
            _effect.CurrentTechnique = _effect.Techniques["Technique1"];
            _effect.CurrentTechnique.Passes[0].Apply();

            // Draw the sprite's quad
            graphics.SetVertexBuffer(_vertexBuffer);
            graphics.DrawPrimitives(PrimitiveType.TriangleStrip, 0, 2);
        }
    }
}
