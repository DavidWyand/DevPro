using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace GameDev
{
    public class SpriteTexture
    {
        #region Member Variable

        // Path to the texture that will be loaded
        private string _texturePath;

        // Used by cell animation
        private int _cellCount;
        private int _cellRows;
        private int _cellColumns;
        private float _cellWidth;
        private float _cellHeight;
        private float _imageWidth;
        private float _imageHeight;

        // The texture itself
        private Texture2D _texture;

        // UV coordinates within the texture that the quad will use.
        // In the form of: x, y, width, height
        private Vector4 _textureUV;

        // Have the texture's UV coordinates changed
        private bool _isDirty;

        // Current animation cell
        private int _cellIndex = 0;

        // Default ContentManager used to load sprite texture and shader        
        private ContentManager _contentManager;

        #endregion

        #region Properties

        /// <summary>
        /// Get the texture
        /// </summary>
        public Texture2D Texture
        {
            get {return _texture;}
        }

        /// <summary>
        /// Get the number of available cells for cell animation
        /// </summary>
        public int CellCount
        {
            get { return _cellCount; }
        }

        /// <summary>
        /// Get the number of rows for cell animation
        /// </summary>
        public int CellRows
        {
            get { return _cellRows; }
        }

        /// <summary>
        /// Get the number of columns for cell animation
        /// </summary>
        public int CellColumns
        {
            get { return _cellColumns; }
        }

        /// <summary>
        /// Get the width of a cell used in cell animation
        /// </summary>
        public float CellWidth
        {
            get { return _cellWidth; }
        }

        /// <summary>
        /// Get the height of a cell used in cell animation
        /// </summary>
        public float CellHeight
        {
            get { return _cellHeight; }
        }

        /// <summary>
        /// Get the current cell index used in cell animation
        /// </summary>
        public int CellIndex
        {
            get { return _cellIndex; }
        }

        /// <summary>
        /// Get the width of the image used for this texture
        /// </summary>
        public float ImageWidth
        {
            get { return _imageWidth; }
        }
        
        /// <summary>
        /// Get the height of the image used for this texture
        /// </summary>
        public float ImageHeight
        {
            get { return _imageHeight; }
        }

        /// <summary>
        /// The texture UV coordinates in the form of x, y, width, height
        /// </summary>
        public Vector4 TextureUV
        {
            get
            {
                // Clear the dirty flag
                _isDirty = false;

                // Return the texture coordinates in the form of x, y, width, height
                return _textureUV;
            }
        }

        /// <summary>
        /// Have the texture's UV coordinates been modified
        /// </summary>
        public bool IsDirty
        {
            get { return _isDirty; }
        }

        /// <summary>
        /// Default ContentManager used to load sprite texture and shader
        /// </summary>
        public ContentManager ContentManager
        {
            get { return _contentManager; }
        }

        #endregion

        /// <summary>
        /// SpriteTexture constructor
        /// </summary>
        public SpriteTexture(string texturePath = "")
        {
            _isDirty = false;
            _texturePath = texturePath;
        }

        /// <summary>
        /// Set the SpriteTexture's properties
        /// </summary>
        /// <param name="texturePath">Content path to the texture</param>
        /// <param name="cellWidth">Width of an individual cell used for cell animation</param>
        /// <param name="cellHeight">Height of an individual cell used for cell animation</param>
        /// <param name="cellIndex">Starting cell index used for cell animation</param>
        public void Set(string texturePath, int cellWidth = 0, int cellHeight = 0, int cellIndex = 0)
        {
            //*********** Begin Focus Area 1 ***********//

            // Store the texture path

            // Store the cell width

            // Store the cell height

            // Store the cell index

            //*********** End Focus Area 1 ***********//

        }

        /// <summary>
        /// Set the SpriteTexture's properties
        /// </summary>        
        /// <param name="cellWidth">Width of an individual cell used for cell animation</param>
        /// <param name="cellHeight">Height of an individual cell used for cell animation</param>
        /// <param name="cellIndex">Starting cell index used for cell animation</param>
        public void SetCells(int cellWidth = 0, int cellHeight = 0, int cellIndex = 0)
        {
            _cellWidth = (float)cellWidth;
            _cellHeight = (float)cellHeight;
            _cellIndex = cellIndex;
        }

        /// <summary>
        /// Load the SpriteTexture's content
        /// </summary>
        /// <param name="contentManager">Content manager</param>
        public void LoadContent(ContentManager contentManager)
        {
            _contentManager = contentManager;

            //*********** Begin Focus Area 2 ***********//

            // Load the texture


            // Get the texture's dimensions


            // Determine cell dimensions in none were provided in Set()
            if (_cellWidth == 0f)
                _cellWidth = _imageWidth;

            if (_cellHeight == 0f)
                _cellHeight = _imageHeight;

            // Calculate the number of cell rows and columns

            //*********** End Focus Area 2 ***********//

            
            // Set the current cell index
            SetCell(_cellIndex);
        }

        /// <summary>
        /// Set the currently displayed cell from the texture.
        /// </summary>
        /// <param name="cellIndex">The cell index to display</param>
        public void SetCell(int cellIndex)
        {
            //*********** Begin Focus Area 3 ***********//

            // Make sure the cellIndex is within range. Return otherwise


            // Store the current cell index


            // Calculate the size of an individual texel
            float texelWidthScale = 1.0f / _imageWidth;
            float texelHeightScale = 1.0f / _imageHeight;

            // Texel dimensions of a cell


            // Pixel Position


            // New UV origin to render with


            // Set the full texture UV coordinates


            // Indicate that the UV coordinates have changed

            //*********** End Focus Area 3 ***********//

        }
    }
}
