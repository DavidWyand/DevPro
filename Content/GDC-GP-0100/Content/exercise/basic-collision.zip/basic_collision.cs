using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;
using GameDev.Utilities;

namespace GameDev
{
    class basic_collision : Module
    {
        SpriteManager _spriteManager;
        Sprite _background;
        Sprite _planet;
        Sprite[] _ships;
        Sprite[] _shipExplosions;
        Vector3[] _shipVelocities;
        
        float _shipSpeed = 100.0f;
        float _shipWidth = 60;
        float _shipHeight = 40;
        float _planetWidthHeight = 400;

        //*********** Begin Focus Area 1 ***********//
        //*********** End Focus Area 1 ***********//



        //*********** Begin Focus Area 5 ***********//
        //*********** End Focus Area 5 ***********//

         

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            _spriteManager = new SpriteManager();
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            OrthoCamera cam = new OrthoCamera();
            cam.Bounds = _graphicsDevice.Viewport.Bounds;
            DefaultCamera = cam;

            DebugDraw.Initialize(_graphicsDevice, _contentManager);
            
            // Setup some render states
            SetupRenderState();

            SpriteTexture backgroundTexture = new SpriteTexture("Graphics\\Space_Background");
            SpriteTexture planetTexture = new SpriteTexture("Graphics\\planetoid");
            SpriteTexture shipTexture = new SpriteTexture("Graphics\\playerShip");
            backgroundTexture.LoadContent(_contentManager);
            planetTexture.LoadContent(_contentManager);
            shipTexture.LoadContent(_contentManager);


            _background = new Sprite();
            _background.SetSpriteTexture(backgroundTexture);
            _background.SetPosition(_graphicsDevice.Viewport.Bounds.Width / 2, _graphicsDevice.Viewport.Bounds.Height / 2);
            _background.SetSize(_graphicsDevice.Viewport.Bounds.Width, _graphicsDevice.Viewport.Bounds.Height);
            _background.SetFlipVertical(true);
            _spriteManager.AddSprite(_background);

            //*********** Begin Focus Area 4 ***********//

            //*********** End Focus Area 4 ***********//

          

            _shipVelocities = new Vector3[3];
            _ships = new Sprite[3];
            _shipExplosions = new Sprite[3];
            for (int i = 0; i < _ships.Length; i++)
            {
                _ships[i] = new Sprite(1);
                _ships[i].SetSpriteTexture(shipTexture);
                _ships[i].SetFlipVertical(true);
                _ships[i].SetSize(_shipWidth, _shipHeight);
                _ships[i].SetPosition(100, (_graphicsDevice.Viewport.Bounds.Height / 2) - 25);
                _spriteManager.AddSprite(_ships[i]);

                _shipVelocities[i] = Vector3.UnitX * _shipSpeed;

                SpriteTexture explosionTexture = new SpriteTexture("Graphics\\poisonCloud");
                explosionTexture.SetCells(64, 64, 0);
                explosionTexture.LoadContent(_contentManager);

                _shipExplosions[i] = new Sprite(2);
                _shipExplosions[i].SetSpriteTexture(explosionTexture);
                _shipExplosions[i].SetFlipVertical(true);
                _shipExplosions[i].SetSize(explosionTexture.CellWidth, explosionTexture.CellHeight);
                _shipExplosions[i].Animate(0, 16, 400, AnimAction.EndAction.Stop);
            }
            _ships[0].SetPosition(_ships[0].Position.X, _ships[0].Position.Y - 200);
            _ships[2].SetPosition(_ships[2].Position.X, _ships[2].Position.Y + 200);         
        }        

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {            
            for( int i = 0; i < _ships.Length; i++ )
            {
                Sprite ship = _ships[i];
                if (ship.Visible)
                {
                    Vector3 futurePosition = ship.Position + (_shipVelocities[i] * (float)time.ElapsedGameTime.TotalSeconds);
                    
                    //*********** Begin Focus Area 3 ***********//

                    //*********** End Focus Area 3 ***********//


                    //*********** Begin Focus Area 7 ***********//

                    //*********** End Focus Area 7 ***********//

          

                    // See if the ship will collide with the planet
                    if( ship.Visible )
                    {
                        //*********** Begin Focus Area 6 ***********//

                        //*********** End Focus Area 6 ***********//

                    }

                    ship.Position = futurePosition;
                }
            }

            _spriteManager.UpdateSprites(time);
        }

        //*********** Begin Focus Area 2 ***********//

        //*********** End Focus Area 2 ***********//

          

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            Matrix viewProjection = DefaultCamera.View * DefaultCamera.Projection;
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);

            //*********** Begin Focus Area 8 ***********//

            //*********** End Focus Area 8 ***********//

          
        }
    }
}
