using GameDev;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using GameDev.Utilities;
using System;

namespace GameDev.FinishedExercises
{
    class Asteroid : GameObject
    {
        /// <summary>
        /// Three different asteroid states
        /// </summary>
        public enum AsteroidState
        {
            /// <summary>
            /// Asteroid is whole, no damage, starting state
            /// </summary>
            Whole = 0,
            /// <summary>
            /// Asteroid has been hit once
            /// </summary>
            Broken,
            /// <summary>
            /// Asteroid has been hit twice, destroy and hide
            /// </summary>
            Hidden
        };

        // Current asteroid state
        public AsteroidState State;

        // Speed of asteroid (used in both X and Y components of Velocity)
        private float _asteroidSpeed;

        // Smaller pieces for the asteroid
        public Asteroid[] Pieces;        

        /// <summary>
        /// Asteroid constructor
        /// </summary>
        /// <param name="startingPosition">X and Y coordinates on screen</param>
        /// <param name="startingVelocity">Speed and direction for game object movement</param>
        /// <param name="size">Width and height of this game object</param>
        /// <param name="angle">Initial angle in degrees</param>
        public Asteroid(Vector3 startingPosition, Vector2 startingVelocity, Vector2 size, float angle)
            : base(startingPosition, startingVelocity, size, angle)
        {
            State = AsteroidState.Whole;
            _asteroidSpeed = 0.25f;
            
            Angle = angle;

            float xVelocity = (float)(Math.Cos(MathHelper.ToRadians(Angle)) * _asteroidSpeed);
            float yVelocity = (float)(Math.Sin(MathHelper.ToRadians(Angle)) * _asteroidSpeed);

            Velocity = new Vector2(xVelocity, yVelocity);
            SetRotation(MathHelper.ToRadians(Angle));            
        }               

        /// <summary>
        /// Build two smaller pieces that are inactive until this asteroid is hit
        /// </summary>
        public void MakePieces()
        {
            Pieces = new Asteroid[2];
            for (int i = 0; i < 2; i++)
            {
                Pieces[i] = new Asteroid(new Vector3(-100.0f, -100.0f, 0.0f), new Vector2(0.0f, 0.0f), new Vector2(Size.X / 2, Size.Y / 2), 0);
                Pieces[i].SetSpriteTexture(Texture.Copy());                
                Pieces[i].State = AsteroidState.Broken;

                if (GameObjectCollisionDelegate == CheckBoxCollision)
                    Pieces[i].GameObjectCollisionDelegate = Pieces[i].CheckBoxCollision;
                else
                    Pieces[i].GameObjectCollisionDelegate = Pieces[i].CheckCircleCollision;
            }
        }

        /// <summary>
        /// Update the asteroid, mainly its smaller pieces
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values</param>
        public override void UpdateGameObject(GameTime gameTime)
        {
            base.UpdateGameObject(gameTime);            

            // If this asteroid has smaller pieces, update them
            if (Pieces != null)
            {
                foreach (Asteroid piece in Pieces)
                {
                    if (piece.Visible)
                        piece.UpdateGameObject(gameTime);
                }
            }
        }
        
        /// <summary>
        /// Called when the asteroid is hit. Reaction is based on its state.
        /// </summary>
        public override void Hit()
        {
            switch(State)
            {
                // Asteroid is a whole piece
                case AsteroidState.Whole:

                    // Go through the smaller sub-pieces
                    Random rand = new Random();
                    foreach (Asteroid piece in Pieces)
                    {
                        // Start the pieces where this asteroid was last located
                        piece.SetPosition(Position.X, Position.Y);

                        // Set a random angle
                        piece.Angle = rand.Next(360);
                        piece.SetRotation(MathHelper.ToRadians(piece.Angle));

                        // Set the velocity for the pieces
                        float velocityX = (float)(Math.Cos(MathHelper.ToRadians(piece.Angle)) * _asteroidSpeed);
                        float velocityY = (float)(Math.Sin(MathHelper.ToRadians(piece.Angle)) * _asteroidSpeed);
                        piece.Velocity = new Vector2(velocityX, velocityY);
                        piece.Texture.SetCell(rand.Next(3));                        
                        piece.State = AsteroidState.Broken;
                    }

                    // Stop movement, and move the asteroid off screen                    
                    SetPosition(-100, -100);
                    Velocity = new Vector2(0.0f, 0.0f);

                    // Update state of asteroid to the Hidden value as the pieces take over from here
                    State = AsteroidState.Hidden;
                    break;
                
                // Asteroid is in smaller pieces
                case AsteroidState.Broken:
                    
                    // Stop movement, and move the asteroid off screen                   
                    SetPosition(-100, -100);
                    Velocity = new Vector2(0.0f, 0.0f);
                
                    // Update state of asteroid to the next value
                    State++;
                    break;

                // Asteroid has been destroyed (do nothing)
                case AsteroidState.Hidden:
                default:
                    break;
            }
        }
        
        /// <summary>
        /// Collision routine for Asteroid which will check against itself and its pieces
        /// </summary>
        /// <param name="gameObject">The game object to check collision against (could be ship or a projectile)</param>
        /// <returns>The asteroid or one of its pieces, if they collide. null otherwise</returns>
        public Asteroid CheckAsteroidCollision(GameObject gameObject)
        {
            if (State != AsteroidState.Hidden && GameObjectCollisionDelegate(gameObject))
                return this;

            // Go through all the pieces and check for their collision with the game object
            foreach(Asteroid piece in Pieces)
            {
                if (piece.State == AsteroidState.Hidden)
                    continue;

                if (piece.GameObjectCollisionDelegate(gameObject))
                    return piece;
            }

            return null;
        }        
    }
}