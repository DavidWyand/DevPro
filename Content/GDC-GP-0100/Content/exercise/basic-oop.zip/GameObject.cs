using GameDev;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using GameDev.Utilities;
using System;

namespace GameDev.FinishedExercises
{
    //*********** Begin Focus Area 1 ***********//

    //*********** End Focus Area 1 ***********//
          
}
