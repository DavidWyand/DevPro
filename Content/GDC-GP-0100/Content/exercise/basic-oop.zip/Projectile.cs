using GameDev;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using GameDev.Utilities;
using System;

namespace GameDev.FinishedExercises
{
    class Projectile : GameObject
    {
        // Number of seconds a projectile lasts before pooling
        private float _lifeTime;

        // Number of seconds a projectile has existed since firing
        private float _currentTime;

        // Whether this projectile is in the pool or not
        private bool _isAvailable;

        /// <summary>
        /// Get this projectile's availability
        /// </summary>
        public bool IsAvailable
        {
            get { return _isAvailable; }
        }

        /// <summary>
        /// Projectile constructor
        /// </summary>
        /// <param name="startingPosition">X and Y coordinates on screen</param>
        /// <param name="startingVelocity">Speed and direction for game object movement</param>
        /// <param name="size">Width and height of this game object</param>
        /// <param name="angle">Initial angle in degrees</param>
        public Projectile(Vector3 startingPosition, Vector2 startingVelocity, Vector2 size, float angle)
            : base(startingPosition, startingVelocity, size, angle)
        {
            _lifeTime = 1.0f;
            _currentTime = 0.0f;
            _isAvailable = true;
            SetVisible(false);
        }
   
        /// <summary>
        /// Call after the ship as shot this projectile, removing it from the pool
        /// </summary>
        public void Shoot()
        {
            SetVisible(true);
            _isAvailable = false;
        }

        /// <summary>
        /// Update this projectile's lifetime and availability
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values</param>
        public override void UpdateGameObject(GameTime gameTime)
        {
            base.UpdateGameObject(gameTime);

            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = gameTime.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            if (!_isAvailable)
                _currentTime += deltaSeconds;

            if (_currentTime >= _lifeTime)
            {
                _isAvailable = true;
                _currentTime = 0.0f; 
                
                Velocity = new Vector2(0.0f, 0.0f);                
                SetPosition(-900, -900);                
                SetVisible(false);
            }
        }    
    
        /// <summary>
        /// Call when the projectile as collided with an object that isn't the ship
        /// </summary>
        public override void Hit()
        {
            _isAvailable = false;
            SetVisible(false);
        }
    }
}