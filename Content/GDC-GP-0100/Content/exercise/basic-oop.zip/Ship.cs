using GameDev;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using GameDev.Utilities;
using System;

namespace GameDev.FinishedExercises
{
    class Ship : GameObject
    {
        // Whether the ship is respawning or not
        bool _respawning;

        // How long it takes the ship to respawn
        float _respawnDelay;

        // Cumulative seconds the ship has been respawning
        float _respawnTime;

        // Index into array of projectiles
        int _currentShot;

        // Whether the ship has loaded the next projectile or not
        bool _nextShotReady;

        // Cumulative seconds since the last shot was fired
        float _shotTimer;

        // Texture used for the projectils
        public SpriteTexture ProjectileTexture;

        // List of projectiles this ship can fire
        public Projectile[] Projectiles;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="startingPosition">X and Y coordinates on screen</param>
        /// <param name="startingVelocity">Speed and direction for game object movement</param>
        /// <param name="size">Width and height of this game object</param>
        /// <param name="angle">Initial angle in degrees</param>
        public Ship(Vector3 startingPosition, Vector2 startingVelocity, Vector2 size, float angle)
            : base(startingPosition, startingVelocity, size, angle)
        {
            // Initialize ship member variables to default values
            Acceleration = 0.01f;
            Friction = 0.05f;

            _respawning = false;
            _respawnDelay = 3.0f;
            _respawnTime = 0.0f;

            _shotTimer = 0.0f;
            _currentShot = 0;
            _nextShotReady = true;
        }

        /// <summary>
        /// Build all the projectiles
        /// </summary>
        public void LoadProjectiles()
        {
            Projectiles = new Projectile[5];

            for (int i = 0; i < Projectiles.Length; i++)
            {                
                SpriteTexture projectileTexture = ProjectileTexture.Copy();
                projectileTexture.LoadContent(ProjectileTexture.ContentManager);
                
                var projectile = new Projectile(new Vector3(100.0f, 100.0f, 0.0f), new Vector2(0.0f, 0.0f), new Vector2(2.5f, 1.25f), 0.0f);                
                projectile.SetSpriteTexture(projectileTexture);
                projectile.GameObjectCollisionDelegate = GameObjectCollisionDelegate;

                Projectiles[i] = projectile;
            }
        }

        /// <summary>
        /// Ship update for managing respawning, projectile reloading, and speed control
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values</param>
        public override void UpdateGameObject(GameTime gameTime)
        {            
            base.UpdateGameObject(gameTime);

            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = gameTime.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            // If the ship is respawning
            if (_respawning)
            {
                // Check to see enough time has passed. If so, respawn. If not, do not continue updating
                _respawnTime += deltaSeconds;
                if (_respawnTime >= _respawnDelay)
                    Respawn();
                else
                    return;
            }

            // Check to see if enough time has passed that the ship can fire again
            if (_nextShotReady == false)
                _shotTimer += deltaSeconds;

            if (_shotTimer > 0.5f)
            {
                _nextShotReady = true;
                _shotTimer = 0.0f;
            }

            // Decrease the ship's velocity
            if (Velocity.Length() > Friction * deltaSeconds)
            {
                Vector2 normalizedVelocity = new Vector2(Velocity.X, Velocity.Y);
                normalizedVelocity.Normalize();

                Velocity -= normalizedVelocity * Friction * deltaSeconds;
            }
            else
            {
                Velocity.X = 0;
                Velocity.Y = 0;
            }
        }        

        /// <summary>
        /// Fires a projectile
        /// </summary>
        public void Shoot()
        {
            if (!_nextShotReady || !Projectiles[_currentShot].IsAvailable)
                return;

            // Make the projectile unavailable and visible
            Projectiles[_currentShot].Shoot();

            // Set the projectile to the ship's position
            Projectiles[_currentShot].SetPosition(Position.X, Position.Y);

            // Set the projectile's angle to the ship's angle
            Projectiles[_currentShot].SetRotation(MathHelper.ToRadians(Angle));

            // Set projectile's velocity
            float projectileSpeed = 1.0f;            
            
            Projectiles[_currentShot].Velocity.X = (float)(Math.Cos(MathHelper.ToRadians(Angle)) * projectileSpeed);
            Projectiles[_currentShot].Velocity.Y = (float)(Math.Sin(MathHelper.ToRadians(Angle)) * projectileSpeed);

            // Toggle the ability to shoot
            _nextShotReady = false; 
            
            // Go to the next shot index and clamp it
            _currentShot++;            
            if (_currentShot >= Projectiles.Length)
                _currentShot = 0;
        }

        /// <summary>
        ///  Called when hit with an object that isn't a projectile
        /// </summary>
        public override void Hit()
        {
            // Stop moving, rotating, rendering, and reset to the center
            Angle = 0.0f;
            Velocity = new Vector2(0.0f, 0.0f);
            SetRotation(Angle);
            SetPosition(0.0f, 0.0f);
            SetVisible(false);

            // Toggle respawning
            _respawning = true;
        }

        /// <summary>
        /// Called when respawn timer is finished
        /// </summary>
        public void Respawn()
        {
            // Reset respawning variables and start rendering again
            SetVisible(true); 
            _respawning = false;
            _respawnTime = 0.0f;
        }

        public void SetSpeed(float x, float y)
        {
            Velocity.X = MathHelper.Clamp(x, -1.0f, 1.0f);
            Velocity.Y = MathHelper.Clamp(y, -1.0f, 1.0f);
        }
    }
}
