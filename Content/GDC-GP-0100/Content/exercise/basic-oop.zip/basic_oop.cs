using GameDev;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using GameDev.Utilities;
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using System.IO;

namespace GameDev.FinishedExercises
{
    class Asteroids : Module
    {
        // XNA/MonoGame sprite objects for rendering text
        SpriteBatch _spriteBatch;
        SpriteFont _font;

        // Main SpriteManager which updates and renders all Sprite objects
        SpriteManager _spriteManager;        
        float _textureRatio = 17f;

        // Space background
        Sprite _background;
        SpriteTexture _backgroundTexture;

        // Player's ship
        Ship _ship;
        SpriteTexture _shipTexture;

        // Asteroid entities
        Asteroid[] _asteroids;        

        // Game members
        int _currentScore;
        int _highScore;

        //*********** Begin Focus Area 7 ***********//

        //*********** End Focus Area 7 ***********//


        //*********** Begin Focus Area 8 ***********//

        //*********** End Focus Area 8 ***********//

          

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {           
            _spriteManager = new SpriteManager();
            _background = new Sprite(0);
            _spriteManager.AddSprite(_background);

            //*********** Begin Focus Area 2 ***********//

            //*********** End Focus Area 2 ***********//


            Random rand = new Random();
            //*********** Begin Focus Area 3 ***********//
            
            //*********** End Focus Area 3 ***********//



            //*********** Begin Focus Area 9 ***********//

            //*********** End Focus Area 9 ***********//

        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            // Build the sprite batch and font for rendering text
            _spriteBatch = new SpriteBatch(_graphicsDevice);
            _font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");            

            // Build the background            
            _backgroundTexture = new SpriteTexture("Graphics\\AsteroidBackground");            
            _backgroundTexture.LoadContent(_contentManager);
            _background.SetSpriteTexture(_backgroundTexture);
            _background.SetSize(_backgroundTexture.ImageWidth / _textureRatio, _backgroundTexture.ImageHeight / _textureRatio);
            
            // Build the ship
            _shipTexture = new SpriteTexture("Graphics\\Ship1");            
            _shipTexture.LoadContent(_contentManager);                        
            _ship.SetSpriteTexture(_shipTexture);
            _ship.ProjectileTexture = new SpriteTexture("Graphics\\Projectile");
            _ship.ProjectileTexture.LoadContent(_contentManager);
            _ship.LoadProjectiles();            
            _spriteManager.AddSprites(_ship.Projectiles);
            
            // Build the asteroids  
            Random rand = new Random();
            foreach (Asteroid asteroid in _asteroids)
            {
                var asteroidTexture = new SpriteTexture();

                asteroidTexture.Set("Graphics\\Asteroid");
                asteroidTexture.LoadContent(_contentManager);
                
                asteroid.SetSpriteTexture(asteroidTexture);
                asteroid.MakePieces();
                
                _spriteManager.AddSprites(asteroid.Pieces);
            }
        }
        
        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Update all sprites
            _spriteManager.UpdateSprites(time);

            //*********** Begin Focus Area 4 ***********//

            //*********** End Focus Area 4 ***********//


            foreach (Projectile projectile in _ship.Projectiles)
                projectile.UpdateGameObject(time);
            
            // Check for collisions
            CheckCollisions();

            //*********** Begin Focus Area 5 ***********//

            //*********** End Focus Area 5 ***********//

        }
       
        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            base.Render();

            // Render all sprites
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);

            // Render game text/UI
            _spriteBatch.Begin();            
            _spriteBatch.DrawString(_font, "High Score: " + _highScore.ToString(), new Vector2(0.0f, 0.0f), Color.White);
            _spriteBatch.DrawString(_font, "Current Score: " + _currentScore.ToString(), new Vector2(0.0f, 25.0f), Color.White);            
            _spriteBatch.End();
        }        

        /// <summary>
        /// Handle input reaction here
        /// </summary>
        /// <param name="keyboardState">Main keyboard state in the game</param>
        /// <param name="mouseState">Main mouse state in the game</param>
        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {
            if (!_ship.Visible)
                return;

            //*********** Begin Focus Area 6 ***********//

            //*********** End Focus Area 6 ***********//

          
        }

        /// <summary>
        /// Check collision for all objects (ship, projectiles, asteroids)
        /// </summary>
        public void CheckCollisions()
        {
            // Loop through all the asteroids
            foreach (Asteroid asteroid in _asteroids)
            {
                foreach (Projectile projectile in _ship.Projectiles)
                {
                    // If the projectile is invisible (inactive), continue to next iteration
                    if (!projectile.Visible)
                        continue;

                    // Check for projectile to asteroid collision
                    var hitObject = asteroid.CheckAsteroidCollision(projectile);
                    if (hitObject != null)
                    {
                        projectile.Hit();
                        hitObject.Hit();

                        _currentScore += 20;

                        if (_currentScore > _highScore)
                            _highScore = _currentScore;
                    }
                }

                // Don't check for collision with a respawning ship or if the game is over
                if (!_ship.Visible)
                    continue;

                // Check for ship to asteroid collision
                var pieceHit = asteroid.CheckAsteroidCollision(_ship);

                if (pieceHit != null)
                {
                    // Collision occurred, so call Hit on both objects
                    pieceHit.Hit();
                    _ship.Hit();

                    // Even if the player is damaged, increase the score
                    _currentScore += 10;

                    if (_currentScore > _highScore)
                        _highScore = _currentScore;
                }
            }
        }

        /// <summary>
        /// Final Module method called before game shuts down
        /// </summary>
        public override void Destroy()
        {
            //*********** Begin Focus Area 10 ***********//

            //*********** End Focus Area 10 ***********//


            base.Destroy();
        }
    }
}
