using Microsoft.Xna.Framework;
using GameDev.Utilities;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Input;

namespace GameDev
{
    class BehaviorsExercise : Module
    {
        List<EntitySystem> _systemList = new List<EntitySystem>();
        SharedObjects _blackBoard;

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            clearColor = Color.Black;
            Mouse.SetPosition(640, 360);
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            // Set up camera and render state
            OrthoCamera cam = new OrthoCamera();
            cam.Bounds = _graphicsDevice.Viewport.Bounds;
            DefaultCamera = cam;            
            SetupRenderState();
            
            // Create a "blackboard", which is an object containing
            // critical objects we can use in other parts of the game
            _blackBoard = new SharedObjects(_graphicsDevice, _contentManager, DefaultCamera);
            
            //*********** Begin Focus Area 1 ***********//
            
            // Create a player that can render, has location info, collision, and physics

            //*********** End Focus Area 1 ***********//


            
            //*********** Begin Focus Area 2 ***********//

            // Create a SpriteSystem for rendering Entities that have render and transform components

            //*********** End Focus Area 2 ***********//


            
            //*********** Begin Focus Area 3 ***********//

            // Create a FollowMouseSystem, which will cause the player to follow the mouse

            //*********** End Focus Area 3 ***********//


            
            //*********** Begin Focus Area 4 ***********//

            // Create an enemy that can render, has location info, collision, and physics

            //*********** End Focus Area 4 ***********//


            
            //*********** Begin Focus Area 8 ***********//

            // Add collision component to the player and enemy

            //*********** End Focus Area 8 ***********//

          
            
            //*********** Begin Focus Area 12 ***********//

            // Create a ChaseTargetSystem, which will cause the enemy to chase the player when close enough

            //*********** End Focus Area 12 ***********//

          
            
            //*********** Begin Focus Area 13 ***********//

            // Create a KeyboardMoveSystem, which will cause the player to have basic up/down/left/right movement

            //*********** End Focus Area 13 ***********//


            foreach (EntitySystem processor in _systemList)
                processor.BlackBoard = _blackBoard;
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Store the current game time for use in other systems
            _blackBoard.GameTime = time;
        }
        
        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {   
            // Run all entity processors
            foreach (EntitySystem processor in _systemList)
                processor.ProcessEntities();
            
            // Update the render state
            SetupRenderState();
        }        
    }
}
