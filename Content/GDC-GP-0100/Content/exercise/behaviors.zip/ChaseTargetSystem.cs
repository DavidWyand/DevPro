using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace GameDev
{
    public class ChaseTargetSystem : EntitySystem
    {
        // Add a private field for speed
        //*********** Begin Focus Area 9 ***********//

        //*********** End Focus Area 9 ***********//

        
        /// <summary>
        /// Initializes a new instance of ChaseTargetSystem
        /// </summary>
        /// <param name="blackBoard">Black board.</param>
        public ChaseTargetSystem(float chaseSpeed)            
        {
            name = "ChaseTargetSystem";

            // Assign the speed
            //*********** Begin Focus Area 10 ***********//

            //*********** End Focus Area 10 ***********//

          
        }

        /// <summary>
        /// Processes the entity.
        /// </summary>
        /// <param name="entity">Entity.</param>
        protected override void ProcessEntity(Entity entity)
        {
            TransformComponent transComp = entity.GetComponent<TransformComponent>();
            CollisionComponent collComp = entity.GetComponent<CollisionComponent>();
            
            Entity target = collComp.Target;
            CollisionComponent targetCollisionComponent = target.GetComponent<CollisionComponent>();
            TransformComponent targetTransformComponent = target.GetComponent<TransformComponent>();            
            
            //*********** Begin Focus Area 11 ***********//

            // Get the bounding spheres

            // Update the bounding spheres' centers

            // If spheres intersect, update the Entity's position to chase the target
            //*********** End Focus Area 11 ***********//

          
        }
    }
}
