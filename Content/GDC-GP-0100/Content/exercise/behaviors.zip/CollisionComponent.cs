using Microsoft.Xna.Framework;

namespace GameDev
{
    class CollisionComponent : Component
    {
        // Declare fields and properties for radius, bounding sphere, and target
        //*********** Begin Focus Area 5 ***********//

        //*********** End Focus Area 5 ***********//


        private Entity _target;
        public Entity Target
        {
            get { return _target; }
            set { _target = value; }
        }

        /// <summary>
        /// Initialize an instance of SensorComponent component
        /// </summary>        
        public CollisionComponent(float radius, Entity target = null)
        {
            // Set the radius and target, then initialize this component
            //*********** Begin Focus Area 6 ***********//

            //*********** End Focus Area 6 ***********//


            Initialize();
        }

        /// <summary>
        /// Initialize the data and state for the Component
        /// </summary>
        public override void Initialize()
        {
            name = "SensorComponent";

            // Allocate a new bounding sphere
            //*********** Begin Focus Area 7 ***********//

            //*********** End Focus Area 7 ***********//

          
        }
    }
}
