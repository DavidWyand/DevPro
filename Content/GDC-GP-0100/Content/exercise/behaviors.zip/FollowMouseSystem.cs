using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace GameDev
{
    public class FollowMouseSystem : EntitySystem
    {
        /// <summary>
        /// Initializes a new instance of FollowMouseSystem
        /// </summary>
        /// <param name="blackBoard">Black board.</param>
        public FollowMouseSystem()
        {
            name = "FollowMouseSystem";
        }

        /// <summary>
        /// Processes the entity.
        /// </summary>
        /// <param name="entity">Entity.</param>
        protected override void ProcessEntity(Entity entity)
        {
            TransformComponent transComp = entity.GetComponent<TransformComponent>();
            Vector3 oldPosition = transComp.Position;
            MouseState mouseState = Mouse.GetState();
            Vector3 newPosition = new Vector3(MathHelper.Clamp(mouseState.X, 0, 1280), MathHelper.Clamp(mouseState.Y, 0, 720), 0);

            transComp.Position = newPosition;
        }
    }
}
