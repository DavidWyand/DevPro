using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace GameDev
{
    public class KeyboardMoveSystem : EntitySystem
    {
        Keys _upKey;
        Keys _downKey;
        Keys _leftKey;
        Keys _rightKey;
        float _moveSpeed;

        /// <summary>
        /// Initializes a new instance of KeyboardMoveSystem
        /// </summary>
        /// <param name="blackBoard">Black board.</param>
        public KeyboardMoveSystem(Keys upKey, Keys downKey, Keys leftKey, Keys rightKey, float moveSpeed)
        {
            name = "KeyboardMoveSystem";
            _upKey = upKey;
            _downKey = downKey;
            _rightKey = rightKey;
            _leftKey = leftKey;
            _moveSpeed = moveSpeed;
        }

        /// <summary>
        /// Processes the entity.
        /// </summary>
        /// <param name="entity">Entity.</param>
        protected override void ProcessEntity(Entity entity)
        {
            KeyboardState keyboardState = Keyboard.GetState();

            TransformComponent transComp = entity.GetComponent<TransformComponent>();

            TimeSpan deltaTimeSpan = BlackBoard.GameTime.ElapsedGameTime;
            float deltaTime = (float)deltaTimeSpan.TotalMilliseconds;

            float newX = transComp.Position.X;
            float newY = transComp.Position.Y;

            if (keyboardState.IsKeyDown(_upKey))
                newY = transComp.Position.Y - _moveSpeed * deltaTime;
            
            if (keyboardState.IsKeyDown(_downKey))
                newY = transComp.Position.Y + _moveSpeed * deltaTime;
            
            if (keyboardState.IsKeyDown(_leftKey))
                newX = transComp.Position.X - _moveSpeed * deltaTime;
            
            if (keyboardState.IsKeyDown(_rightKey))
                newX = transComp.Position.X + _moveSpeed * deltaTime;

            newX = MathHelper.Clamp(newX, 0, 1280);
            newY = MathHelper.Clamp(newY, 0, 720);
            transComp.Position = new Vector3(newX, newY, 0.0f);
        }
    }
}
