using GameDev.Utilities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameDev
{
    public class RenderComponent : Component
    {
        /// <summary>
        /// Private backing field for the vertex buffer used in rendering
        /// </summary>
        VertexBuffer _vertexBuffer;

        /// <summary>
        /// Private backing field for the vertex declaration used in rendering
        /// </summary>
        VertexDeclaration _vertexDecl;

        /// <summary>
        /// Private backing field for the color tint applied to the render
        /// </summary>
        Color _color;

        /// <summary>
        /// Private backing field for the textures used in rendreing
        /// </summary>
        List<Texture2D> _textures;

        /// <summary>
        /// Sprite effect (shader) used for rendering
        /// </summary>
        Effect _effect;

        /// <summary>
        /// Content path to the effect to load, if an Effect is not passed into the constructor
        /// </summary>
        public string EffectPath { get; set; }

        /// <summary>
        /// Content path to the texture to load, if a Texture2D is not passed into the constructor
        /// </summary>
        public string TexturePath { get; set; }

        /// <summary>
        /// Toggles the rendering
        /// </summary>
        public bool Visible { get; set; }

        /// <summary>
        /// Vertex buffer used for rendering
        /// </summary>
        public VertexBuffer VertBuffer
        {
            get { return _vertexBuffer; }
            set { _vertexBuffer = value; }
        }

        /// <summary>
        /// Vertex declaration used for rendering
        /// </summary>
        public VertexDeclaration VertDeclaration
        {
            get { return _vertexDecl; }
            set { _vertexDecl = value; }
        }

        /// <summary>
        /// Color tint applied to the sprite rendering
        /// </summary>
        public Color Color
        {
            get { return _color; }
            set { _color = value; }
        }

        /// <summary>
        /// Effect used in point sprite rendering
        /// </summary>
        public Effect Effect
        {
            get { return _effect; }
            set { _effect = value; }
        }

        /// <summary>
        /// Any textures used in the point sprite rendering
        /// </summary>
        public List<Texture2D> Textures
        {
            get { return _textures; }
            set { }
        }        

        /// <summary>
        /// Initialize a new instance of RenderComponent
        /// </summary>
        /// <param name="texturePath">Content path to the texture to load</param>        
        public RenderComponent(string texturePath)
        {
            EffectPath = "Shaders\\PointSprite.mgfxo"; 
            TexturePath = texturePath;             
            
            Initialize();
        }

        /// <summary>
        /// Initialize a new instance of RenderComponent
        /// </summary>
        /// <param name="effect">Point sprite effect</param>
        /// <param name="texture">Textured used for the point sprite rendering</param>
        public RenderComponent(Effect effect = null, Texture2D texture = null)
        {
            Initialize();

            _effect = effect;

            if (texture != null)
                _textures.Add(texture);
        }

        /// <summary>
        /// Initialize the data and state for the Component
        /// </summary>
        public override void Initialize() 
		{            
			name = "RenderComponent";
            enabled = false;

            Visible = true;            
            
            _textures = new List<Texture2D>();            

            _color = Color.White;            
		}      
    }
}
