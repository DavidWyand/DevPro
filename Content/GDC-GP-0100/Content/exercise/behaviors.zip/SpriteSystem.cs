using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace GameDev
{
    public class SpriteSystem : EntitySystem
    {		
		/// <summary>
		/// Initializes a new instance of EntitySystem
		/// </summary>
		/// <param name="blackBoard">Black board.</param>
        public SpriteSystem()
		{
            name = "SpriteSystem";
		}
		
        /// <summary>
        /// Load the content for the RenderComponent
        /// </summary>
        /// <param name="renderComp">Reference to the component that needs to load</param>
        void LoadContent(RenderComponent renderComp)
        {
            if (renderComp.EffectPath == null)
                renderComp.EffectPath = "Shaders\\PointSprite.mgfxo";
            if (renderComp.TexturePath == null)
                renderComp.TexturePath = "Graphics\\White";

            Texture2D texture = BlackBoard.Content.Load<Texture2D>(renderComp.TexturePath);
            renderComp.Textures.Add(texture);

            renderComp.Effect = BlackBoard.Content.Load<Effect>(renderComp.EffectPath);
        }

        /// <summary>
        /// Set up the RenderComponent's sprite effect before rendering
        /// </summary>
        /// <param name="renderComp">RenderComponent that contains the sprite effect</param>
        /// <param name="transComp">TransformComponent that contains orientation information</param>
        void SetupEffect(RenderComponent renderComp, TransformComponent transComp)
        {            
            renderComp.Effect.Parameters["Projection"].SetValue(BlackBoard.DefaultCamera.Projection);
            renderComp.Effect.Parameters["WorldView"].SetValue(transComp.WorldMatrix * BlackBoard.DefaultCamera.View);
            renderComp.Effect.Parameters["SpritePosition"].SetValue(new Vector2(0.0f, 0.0f));
            renderComp.Effect.Parameters["SpriteColor"].SetValue(renderComp.Color.ToVector4());
            renderComp.Effect.Parameters["SpriteSize"].SetValue(transComp.Size);

            if (renderComp.Textures.Count > 0)
            {
                renderComp.Effect.Parameters["SpriteTexture"].SetValue(renderComp.Textures[0]);
                renderComp.Effect.Parameters["UseTexture"].SetValue(true);
            }
            else
                renderComp.Effect.Parameters["UseTexture"].SetValue(false);
        }

        /// <summary>
        /// One time builder of the RenderComponent's vertex buffer
        /// </summary>
        /// <param name="renderComp">RenderComponent that contains the vertex buffer</param>
        void BuildVertexBuffer(RenderComponent renderComp)
        {
            if (renderComp.VertBuffer == null)
            {
                VertexElement[] elements = new VertexElement[1];
                elements[0] = new VertexElement(0, VertexElementFormat.Vector4, VertexElementUsage.Position, 0);
                renderComp.VertDeclaration = new VertexDeclaration(elements);

                Vector4[] verts = new Vector4[4];
                verts[0] = new Vector4(-1, 1, 0, 1);
                verts[1] = new Vector4(1, 1, 0, 1);
                verts[2] = new Vector4(-1, -1, 0, 1);
                verts[3] = new Vector4(1, -1, 0, 1);
                renderComp.VertBuffer = new VertexBuffer(BlackBoard.GraphicsDevice, renderComp.VertDeclaration, verts.Length, BufferUsage.WriteOnly);
                renderComp.VertBuffer.SetData(verts);
            }
        }

		/// <summary>
		/// Processes the entity.
		/// </summary>
		/// <param name="entity">Entity to process.</param>
        protected override void ProcessEntity(Entity entity)
        {
            RenderComponent renderComp = entity.GetComponent<RenderComponent>();
            TransformComponent transComp = entity.GetComponent<TransformComponent>();
            
            if (!renderComp.Enabled)
            {
                if (renderComp.Effect == null)
                    LoadContent(renderComp);

                BuildVertexBuffer(renderComp);
            }

            SetupEffect(renderComp, transComp);

            BlackBoard.GraphicsDevice.SetVertexBuffer(renderComp.VertBuffer);

            foreach (EffectPass pass in renderComp.Effect.CurrentTechnique.Passes)
            {
                pass.Apply();
                BlackBoard.GraphicsDevice.DrawPrimitives(PrimitiveType.TriangleStrip, 0, 2);
            }
        }		
    }
}
