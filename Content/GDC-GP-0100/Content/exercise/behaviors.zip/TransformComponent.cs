using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameDev
{
    public class TransformComponent : Component
    {
        /// <summary>
        /// Private backing field for this component's world matrix
        /// </summary>
        Matrix _worldMatrix;                

        /// <summary>
        /// Width/Height for Entity
        /// </summary>
        public Vector2 Size;

        /// <summary>
        /// Angle for Entity
        /// </summary>
        public float Rotation { get; set; }
        
        /// <summary>
        /// Entity's world matrix
        /// </summary>
        public Matrix WorldMatrix
        {
            get { return _worldMatrix; }
            set { _worldMatrix = value; }
        }

        /// <summary>
        /// Accessor for Entity's world matrix translation
        /// </summary>
        public Vector3 Position
        {
            get { return _worldMatrix.Translation; }
            set
            {
                _worldMatrix.Translation = value;
            }
        }

        /// <summary>
        /// Initialize an instance of TransformComponent with default values
        /// </summary>
        public TransformComponent()
        {
            _worldMatrix = Matrix.Identity;
            Size = new Vector2(1.0f, 1.0f);
            Rotation = 0.0f;
            Initialize();
        }

        /// <summary>
        /// Initialize an instance of TransformComponent with provided position, size, and rotation
        /// </summary>
        /// <param name="position">X/Y coordinate for Entity</param>
        /// <param name="size">Width/Height for Entity</param>
        /// <param name="rotation">Angle for Entity</param>
        public TransformComponent(Vector3 position, Vector2 size, float rotation)
        {
            _worldMatrix = Matrix.Identity;
            Position = position;
            Size = size;
            Rotation = rotation;
        }

        /// <summary>
        /// Initialize the data and state for the Component
        /// </summary>
        public override void Initialize() 
		{
			name = "TransformComponent";
            
            if (Size.X <= 0.0f)
                Size.X = 1.0f;

            if (Size.Y <= 0.0f)
                Size.Y = 1.0f;
		}
	}
}
