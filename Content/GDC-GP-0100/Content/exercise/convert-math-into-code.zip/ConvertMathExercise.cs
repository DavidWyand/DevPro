using GameDev.Utilities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System;

namespace GameDev.Exercises
{
    class ConvertMathExercise : Module
    {
        //*********** Begin Focus Area 1 ***********//
        public class Circle
        {
            public Circle()
            {

            }
        }
        //*********** End Focus Area 1 ***********//


        // Main SpriteManager which updates and renders all Sprite objects
        private SpriteManager _spriteManager = new SpriteManager();
        private float _textureRatio = 17f;

        private Sprite _ballOne = new Sprite(1);
        private SpriteTexture _ballOneTexture;

        private Sprite _ballTwo = new Sprite(1);
        private SpriteTexture _ballTwoTexture;

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            // Build the first ball
            _ballOneTexture = new SpriteTexture("Graphics\\football");
            _ballOneTexture.LoadContent(_contentManager);
            _ballOne.SetSpriteTexture(_ballOneTexture);
            _ballOne.SetSize(_ballOneTexture.ImageWidth / _textureRatio, _ballOneTexture.ImageHeight / _textureRatio);
            _ballOne.SetPosition(-10.0f, 0.0f);
            _spriteManager.AddSprite(_ballOne);
            
            
            // Build second ball
            _ballTwoTexture = new SpriteTexture("Graphics\\football");
            _ballTwoTexture.LoadContent(_contentManager);
            _ballTwo.SetSpriteTexture(_ballTwoTexture);
            _ballTwo.SetSize(_ballTwoTexture.ImageWidth / _textureRatio, _ballTwoTexture.ImageHeight / _textureRatio);
            _ballTwo.SetPosition(10.0f, 0.0f);
            _spriteManager.AddSprite(_ballTwo);

            //*********** Begin Focus Area 2 ***********//

            //*********** End Focus Area 2 ***********//
          
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            _spriteManager.UpdateSprites(time);

            //*********** Begin Focus Area 3 ***********//

            //*********** End Focus Area 3 ***********//


            //*********** Begin Focus Area 5 ***********//

            //*********** End Focus Area 5 ***********//

        }

        //*********** Begin Focus Area 4 ***********//

        //*********** End Focus Area 4 ***********//


        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);
        }
    }
}
