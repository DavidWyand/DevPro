using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class BubbleObject : SceneObject
    {
        private string _text = "";

        private float _textHalfWidth = 0.0f;
        private float _textHalfHeight = 0.0f;

        private SpriteFont _font;

        private bool _isCorrect;

        public bool IsCorrect
        {
            get { return _isCorrect; }
            set { _isCorrect = value; }
        }

        public BubbleObject(RenderObject obj)
            : base(obj)
        {
            _isCorrect = false;
        }

        public BubbleObject(bool isCorrect, RenderObject obj)
            : base(obj)
        {
            _isCorrect = isCorrect;
        }

        public void SetText(string text, SpriteFont font)
        {
            _text = text;
            _font = font;

            _textHalfWidth = _font.MeasureString(_text).X * 0.5f;
            _textHalfHeight = _font.MeasureString(_text).Y * 0.5f;
        }

        public override void RenderText(GraphicsDevice graphicsDevice, SpriteBatch spriteBatch)
        {
            Vector3 position = worldMatrix.Translation;

            DrawShadowedText(spriteBatch, _font, _text, position.X - _textHalfWidth, position.Y - _textHalfHeight);
        }

        public override void Update(GameTime time)
        {
            base.Update(time);
        }
    }
}
