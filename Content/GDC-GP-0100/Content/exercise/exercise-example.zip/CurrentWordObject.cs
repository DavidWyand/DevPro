using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class CurrentWordObject : SceneObject
    {
        private const float _posX = 400.0f;
        private const float _posY = 60.0f;
        private const float _spriteHalfWidth = 512.0f * 0.5f;
        private const float _spriteHalfHeight = 128.0f * 0.5f;
        private const float _wordTextOffsetX = -60.0f;
        private const float _wordTextOffsetY = -37.0f;

        private SpriteFont _font;

        private string _word = "";

        private SceneObject _headerObject;

        public CurrentWordObject(GraphicsDevice graphics, ContentManager content, Effect pointSpriteEffect,  string name, SpriteFont font)
            : base(name)
        {
            _font = font;

            PointSprite headerSprite = new PointSprite(graphics, pointSpriteEffect, GameTextures.HeaderTextTexture);
            headerSprite.Size = new Vector2(_spriteHalfWidth, _spriteHalfHeight);
            _headerObject = new SceneObject(headerSprite);
            _headerObject.WorldMatrix = Matrix.CreateTranslation(new Vector3(_posX, _posY, GamePlayState.ZPositionMidground));
        }

        public void SetWord(string word)
        {
            _word = word;
        }

        public override void Render(GraphicsDevice graphics, Camera camera)
        {
            base.Render(graphics, camera);

            if(Visible)
            {
                _headerObject.Render(graphics, camera);
            }
        }

        public override void RenderText(GraphicsDevice graphicsDevice, SpriteBatch spriteBatch)
        {
            DrawShadowedText(spriteBatch, _font, _word, _posX + _spriteHalfWidth + _wordTextOffsetX, _posY + _wordTextOffsetY);
        }
    }
}
