using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class ExerciseExampleExercise : Module
    {
        //*********** Begin Focus Area 1 ***********//

        // The list of words to present to the player.  This list may be added to and the
        // game will automatically use the additional words.
        private string[] _words = { "Sprite", "Matrix", "Vector", "Quad" };

        //*********** End Focus Area 1 *************//

        //*********** Begin Focus Area 2 ***********//

        // Should the list of words be randomized upon each play through?
        private bool _randomizeWordList = true;

        // Number of rows to display per word
        private const int _numberOfRowsPerWord = 4;

        // Number of correct words per row (the rest are randomly selected from the
        // remaining words)
        private const int _numberOfCorrectWordsPerRow = 2;

        // The amount awarded for a correct bubble pop
        private const int _correctScore = 100;

        // The amount awarded for an incorrect bubble pop
        private const int _incorrectScore = -50;

        // The size of each bubble
        private const float _bubbleSize = 70.0f;

        //*********** End Focus Area 2 *************//

        private SpriteBatch _spriteBatch;
        private SpriteFont _font;
        private SpriteFont _fontSmall;

        private GameTextures _gameTextures = new GameTextures();
        private GameSounds _gameSounds = new GameSounds();

        private SceneObjectManager _sceneManager = new SceneObjectManager();

        private Effect _pointSpriteEffect;

        private GameStateManager _gameStateManager;

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {

        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();

            OrthoCamera cam = new OrthoCamera();
            cam.Bounds = _graphicsDevice.Viewport.Bounds;
            DefaultCamera = cam;

            // Setup some render states
            SetupRenderState();

            Sprite2D.StaticEffect = _contentManager.Load<Effect>("Shaders\\Sprite2D.mgfxo");

            _spriteBatch = new SpriteBatch(_graphicsDevice);

            _font = _contentManager.Load<SpriteFont>("Fonts\\ArialBlack");
            _fontSmall = _contentManager.Load<SpriteFont>("Fonts\\ArialBlackSmall");

            _gameTextures.Init(_contentManager);
            _gameSounds.Init(_contentManager);

            _pointSpriteEffect = _contentManager.Load<Effect>("Shaders\\PointSprite.mgfxo");

            // Fill out the GamePlayState info
            GamePlayState.WordList = _words;
            GamePlayState.TotalWords = _words.Length;
            GamePlayState.RandomizeWordList = _randomizeWordList;
            GamePlayState.NumberOfRowsPerWord = _numberOfRowsPerWord;
            GamePlayState.NumberOfCorrectWordsPerRow = _numberOfCorrectWordsPerRow;
            GamePlayState.CorrectScore = _correctScore;
            GamePlayState.IncorrectScore = _incorrectScore;
            GamePlayState.BubbleSize = _bubbleSize;
            GamePlayState.BubbleSpawnYPosition = cam.Bounds.Height - GamePlayState.BubbleSize * 1.5f;

            // Build out the game state manager and the states
            _gameStateManager = new GameStateManager(_graphicsDevice, _contentManager, _pointSpriteEffect, _sceneManager);
            GameStateStartup gsStartup = new GameStateStartup();
            _gameStateManager.RegisterGameState(gsStartup);
            GameStateMainMenu gsMainMenu = new GameStateMainMenu();
            _gameStateManager.RegisterGameState(gsMainMenu);
            GameStateBegin gsBegin = new GameStateBegin(_font);
            _gameStateManager.RegisterGameState(gsBegin);
            GameStateBubblesUp gsBubblesUp = new GameStateBubblesUp(_font, _fontSmall);
            _gameStateManager.RegisterGameState(gsBubblesUp);
            GameStateEndSuccess gsEndSuccess = new GameStateEndSuccess(_font);
            _gameStateManager.RegisterGameState(gsEndSuccess);
            GameStateEndFail gsFailSuccess = new GameStateEndFail(_font);
            _gameStateManager.RegisterGameState(gsFailSuccess);

            // Kick off the game state machine
            _gameStateManager.RequestChangeToState("Startup");
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="timeInMilliseconds">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            _gameStateManager.Update(time);

            // Clean up any objects marked for deletion
            _sceneManager.CleanUp();

            // Update all scene objects
            _sceneManager.Update(time);
        }
        
        /// <summary>
        /// Update player input function
        /// </summary>
        /// <param name="keyboardState">Current state of the keyboard</param>
        /// <param name="mouseState">Current state of the mouse</param>
        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {
            _gameStateManager.UpdateInput(keyboardState, mouseState);
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            // Render all scene objects
            _sceneManager.Render(_graphicsDevice, DefaultCamera);

            // Render all text
            _spriteBatch.Begin();
            _sceneManager.RenderText(_graphicsDevice, _spriteBatch);
            _spriteBatch.End();

            SetupRenderState();
        }
    }
}