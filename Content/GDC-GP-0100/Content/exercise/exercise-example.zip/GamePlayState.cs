using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameDev.Exercises
{
    /// <summary>
    /// Holds static variables to track the current game play state
    /// </summary>
    class GamePlayState
    {
        // Score for a correct bubble
        static public int CorrectScore = 100;

        // SCore for an incorrect bubble
        static public int IncorrectScore = -50;

        // Player's current score
        static public int CurrentScore = 0;

        // Word the player is currently on
        static public int CurrentWord = 0;

        // The list of words to play through
        static public string[] WordList;

        // The total number of words the player will go through
        static public int TotalWords = 0;

        // Should the word list be randomized each time?
        static public bool RandomizeWordList = true;

        // The number of correct words that will appear in each row
        static public int NumberOfCorrectWordsPerRow = 2;

        // The number of rows of bubbles that will be presented per word
        static public int NumberOfRowsPerWord = 4;

        // The width of the bubble trough
        static public float TroughWidth = 800.0f;

        // The number of vertical bubble channels
        static public int NumberOfBubbleChannels = 6;

        // The location that bubbles will spawn
        static public float BubbleSpawnYPosition = 0.0f;

        // The maximum height the bubbles may reach before popping
        static public float BubbleMaxHeight = 200.0f;

        // The size of the bubbles
        static public float BubbleSize = 70.0f;

        // These are the Z position of various scene objects
        static public float ZPositionBackground = -10.0f;
        static public float ZPositionMidground = 10.0f;
        static public float ZPositionBubble = 0.0f;
    }
}
