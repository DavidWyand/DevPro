using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    /// <summary>
    /// "Begin" game state
    /// </summary>
    class GameStateBegin : GameState
    {
        private SpriteFont _font;

        public GameStateBegin(SpriteFont font)
        {
            _font = font;
        }

        public override string GetName()
        {
            return "Begin";
        }

        public override void OnEnter()
        {
            // Reset the game play stats
            GamePlayState.CurrentScore = 0;
            GamePlayState.CurrentWord = 0;

            SetupWordList();

            CreateGameElements();

            // Immediately move onto the next state
            Manager.RequestChangeToState("BubblesUp");
        }

        private void SetupWordList()
        {
            // Randomize the word list?
            if (GamePlayState.RandomizeWordList)
            {
                Random rndGen = new Random();

                string[] wordList = GamePlayState.WordList;
                GamePlayState.WordList = new string[GamePlayState.TotalWords];

                // Fill a list with indices into the word list.  We will then randomly pull from
                // this list and on each step, delete the chosen one from the list.  At the end
                // we'll have one index left to assign.
                List<int> indices = new List<int>();
                for (int i = 0; i < GamePlayState.TotalWords; ++i)
                {
                    // Fill the list
                    indices.Add(i);
                }

                int index = 0;
                for (int i = GamePlayState.TotalWords; i > 1; --i)
                {
                    int wordIndex = rndGen.Next(i);
                    GamePlayState.WordList[index] = wordList[indices[wordIndex]];
                    indices.RemoveAt(wordIndex);
                    index++;
                }
                GamePlayState.WordList[index] = wordList[indices[0]];
            }

        }

        private void CreateGameElements()
        {
            // Create the "The word to pop is:" header obejct
            CurrentWordObject headerObject = new CurrentWordObject(Manager.GraphicsDevice, Manager.ContentManager, Manager.PointSpriteEffect, "Header", _font);
            Manager.SceneObjectManager.AddObject(headerObject);

            // Start the header off as not visible.  This prevents it from flashing on screen
            // for a frame before the next state truns it off for the instruction screen.
            headerObject.Visible = false;

            // Create the score object
            CurrentScoreObject scoreObject = new CurrentScoreObject(Manager.GraphicsDevice, Manager.ContentManager, Manager.PointSpriteEffect, "Score", _font);
            Manager.SceneObjectManager.AddObject(scoreObject);
        }
    }
}
