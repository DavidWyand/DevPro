using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace GameDev.Exercises
{
    /// <summary>
    /// "EndSuccess" game state
    /// </summary>
    class GameStateEndSuccess : GameState
    {
        private SpriteFont _font;
        private float _midgroundZPos;

        private SceneObject _endScreen;
        private float _countdown;
        private bool _acceptMouseClick;

        private SoundEffectInstance _musicInstance;

        public GameStateEndSuccess(SpriteFont font)
        {
            _font = font;
            _midgroundZPos = GamePlayState.ZPositionMidground;
        }

        public override string GetName()
        {
            return "EndSuccess";
        }

        public override void OnEnter()
        {
            // Start the music
            _musicInstance = GameSounds.SuccessMusic.CreateInstance();
            _musicInstance.IsLooped = true;
            _musicInstance.Play();

            // Remove the game screen header
            SceneObject header = Manager.SceneObjectManager.FindObjectByName("Header");
            if(header != null)
            {
                Manager.SceneObjectManager.RemoveObject(header);
            }

            // Remove the game screen score
            SceneObject score = Manager.SceneObjectManager.FindObjectByName("Score");
            if(score != null)
            {
                Manager.SceneObjectManager.RemoveObject(score);
            }

            // Display the end screen
            _endScreen = new EndScreenSuccessObject(Manager.GraphicsDevice, Manager.ContentManager, Manager.PointSpriteEffect, _font, GamePlayState.CurrentScore);
            _endScreen.Position = new Vector3(Manager.GraphicsDevice.Viewport.Width * 0.5f, Manager.GraphicsDevice.Viewport.Height * 0.5f, _midgroundZPos);
            Manager.SceneObjectManager.AddObject(_endScreen);

            // Start the countdown before we'll accept a mouse click.  This prevents the player from accidentally
            // leaving this screen if they meant to click on the previous (bubbles) screen.
            _countdown = 1000.0f;
            _acceptMouseClick = false;
        }

        public override void OnLeave()
        {
            // Remove the end screen
            Manager.SceneObjectManager.RemoveObject(_endScreen);
            _endScreen = null;

            // Stop the music
            _musicInstance.Stop();
        }

        public override void Update(GameTime time)
        {
            if(_countdown > 0.0f)
            {
                _countdown -= (float)time.ElapsedGameTime.TotalMilliseconds;
            }
            else if(_countdown <= 0.0f)
            {
                _acceptMouseClick = true;
            }
        }

        public override void UpdateInput(bool mouseLeftClicked, Vector2 mousePosition)
        {
            if (_acceptMouseClick && mouseLeftClicked)
            {
                Manager.RequestChangeToState("MainMenu");
            }
        }
    }
}
