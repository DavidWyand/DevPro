using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class GameStateManager
    {
        // The list of registered game states
        private Dictionary<string, GameState> _stateList = new Dictionary<string, GameState>();

        // The current game state
        private GameState _currentState = null;

        // The requested state that will be switch to on the next tick
        private string _nextRequestedState = "";

        // The last state of the mouse button.  Pressed it true, Released is false
        private bool _lastMouseButtonState = false;

        private GraphicsDevice _graphicsDevice;
        private ContentManager _contentManager;
        private Effect _pointSpriteEffect;
        private SceneObjectManager _sceneObjectManager;

        /// <summary>
        /// The GraphicsDevice for the game
        /// </summary>
        public GraphicsDevice GraphicsDevice
        {
            get { return _graphicsDevice; }
        }

        /// <summary>
        /// The ContentManager for the game
        /// </summary>
        public ContentManager ContentManager
        {
            get { return _contentManager; }
        }

        /// <summary>
        /// The point sprite effect used for the game
        /// </summary>
        public Effect PointSpriteEffect
        {
            get { return _pointSpriteEffect; }
        }

        /// <summary>
        /// The SceneObjectManager for the game
        /// </summary>
        public SceneObjectManager SceneObjectManager
        {
            get { return _sceneObjectManager; }
        }

        public GameStateManager(GraphicsDevice graphicsDevice, ContentManager contentManager, Effect pointSpriteEffect, SceneObjectManager sceneObjectManager)
        {
            _graphicsDevice = graphicsDevice;
            _contentManager = contentManager;
            _pointSpriteEffect = pointSpriteEffect;
            _sceneObjectManager = sceneObjectManager;
        }

        public bool RegisterGameState(GameState state)
        {
            string name = state.GetName();
            if (name.Length == 0)
            {
                // Invalid name so we cannot register
                return false;
            }

            if (_stateList.ContainsKey(name))
            {
                // This game state name has already been registered
                return false;
            }

            // Add the game state to the list
            _stateList.Add(name, state);

            // Let the game state know about the registration
            state.OnRegistered(this);

            return true;
        }

        public bool UnregisterGameState(GameState state)
        {
            string name = state.GetName();
            if (name.Length == 0)
            {
                // Invalid name so we cannot unregister
                return false;
            }

            if (!_stateList.ContainsKey(name))
            {
                // This game state name has already been unregistered, or was never registered
                return false;
            }

            // Remove the game state from the list
            _stateList.Remove(name);

            // Let the game state know about the unregistration
            state.OnUnregistered();

            return true;
        }

        public bool RequestChangeToState(string stateName)
        {
            if (_stateList.ContainsKey(stateName))
            {
                // This request will be processed on the next tick
                _nextRequestedState = stateName;
                return true;
            }

            return false;
        }

        public void Update(GameTime time)
        {
            if (_currentState == null && _nextRequestedState.Length == 0)
            {
                // There is no current state and no requested state in queue.  Nothing to do.
                return;
            }

            if (_nextRequestedState.Length != 0)
            {
                // A request has been made to switch states.  Here is what we need to do:
                // 1. Call OnLeave() on the current state, if any
                // 2. Call OnEnter() on the new state
                // 3. Fall through to the remainder of the code in this method so Update() will be called on the new state

                // Call OnLeave() on the current state, if any
                if (_currentState != null)
                {
                    _currentState.OnLeave();
                    _currentState = null;
                }

                // Find the new state in the dictionary.  If it exists, make it the current state
                // and call its OnEnter().
                _stateList.TryGetValue(_nextRequestedState, out _currentState);
                _nextRequestedState = "";
                if (_currentState != null)
                {
                    _currentState.OnEnter();
                }
                else
                {
                    // _currentState is null so there is nothing we can do with it
                    return;
                }
            }

            // Update the current state this tick
            _currentState.Update(time);
        }

        public void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {
            bool buttonState = (mouseState.LeftButton == ButtonState.Pressed) ? true : false;
            if(_lastMouseButtonState != buttonState)
            {
                _lastMouseButtonState = buttonState;
                Vector2 mousePosition = new Vector2(mouseState.Position.X, mouseState.Position.Y);
                _currentState.UpdateInput(buttonState, mousePosition);
            }
        }
    }
}
