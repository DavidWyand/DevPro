using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class GameTextures
    {
        static public Texture2D BackgroundTexture;

        static public Texture2D TitleOverlayTexture;

        static public Texture2D BubbleBlueObjectTexture;
        static public Texture2D BubbleGreenObjectTexture;
        static public Texture2D BubbleRedObjectTexture;

        static public Texture2D InstructionTexture;
        static public Texture2D InstructionPressMouseTexture;

        static public Texture2D HeaderTextTexture;
        static public Texture2D HeaderScoreTexture;

        static public Texture2D EndFailedOverlayTexture;
        static public Texture2D EndFailedScoreTexture;
        static public Texture2D EndFailedPressMouseTexture;

        static public Texture2D EndSuccessOverlayTexture;
        static public Texture2D EndSuccessWinTexture;
        static public Texture2D EndSuccessScoreTexture;
        static public Texture2D EndSuccessPressMouseTexture;

        static public Texture2D BubblePopTexture;

        public void Init(ContentManager content)
        {
            //*********** Begin Focus Area 3 ***********//

            BackgroundTexture = content.Load<Texture2D>("Graphics\\bubblePopper_BackGround");

            //*********** End Focus Area 3 *************//

            TitleOverlayTexture = content.Load<Texture2D>("Graphics\\bubblePopper_TitleOverlay");

            BubbleBlueObjectTexture = content.Load<Texture2D>("Graphics\\bubblePopper_bubbleBlue");
            BubbleGreenObjectTexture = content.Load<Texture2D>("Graphics\\bubblePopper_bubbleGreen");
            BubbleRedObjectTexture = content.Load<Texture2D>("Graphics\\bubblePopper_bubbleRed");

            InstructionTexture = content.Load<Texture2D>("Graphics\\bubblePopper_Instructions");
            InstructionPressMouseTexture = content.Load<Texture2D>("Graphics\\bubblePopper_PressMouseToPlay");

            HeaderTextTexture = content.Load<Texture2D>("Graphics\\bubblePopper_text_TheWordToPopIs");
            HeaderScoreTexture = content.Load<Texture2D>("Graphics\\bubblePopper_text_Score");

            EndFailedOverlayTexture = content.Load<Texture2D>("Graphics\\bubblePopper_YouFailedOverlay");
            EndFailedScoreTexture = content.Load<Texture2D>("Graphics\\bubblePopper_FinalScore");
            EndFailedPressMouseTexture = content.Load<Texture2D>("Graphics\\bubblePopper_PressMouseForMainMenu");

            EndSuccessOverlayTexture = content.Load<Texture2D>("Graphics\\bubblePopper_WinScreenOverlay");
            EndSuccessWinTexture = content.Load<Texture2D>("Graphics\\bubblePopper_text_YouWin");
            EndSuccessScoreTexture = content.Load<Texture2D>("Graphics\\bubblePopper_FinalScore");
            EndSuccessPressMouseTexture = content.Load<Texture2D>("Graphics\\bubblePopper_PressMouseForMainMenu");

            BubblePopTexture = content.Load<Texture2D>("Graphics\\bubblePopper_SpriteSheet_bubblePop");
        }
    }
}
