using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace GameDev.Exercises
{
    class InstructionScreenObject : SceneObject
    {
        private const float _boardObjectYOffset = -20.0f;
        private const float _titlePosY = -57.0f;
        private const float _pressObjectYOffset = 180.0f;

        private SpriteFont _font;

        private string _titleText = "";
        private float _titleHalfWidth;

        private SceneObject _boardObject;

        private SceneObject _pressObject;

        private SoundEffectInstance _soundInstance;

        public InstructionScreenObject(GraphicsDevice graphics, ContentManager content, Effect pointSpriteEffect, SpriteFont font, string name)
        {
            _font = font;

            PointSprite boardSprite = new PointSprite(graphics, pointSpriteEffect, GameTextures.InstructionTexture);
            boardSprite.Size = new Vector2(1024.0f * 0.5f, 512.0f * 0.5f);
            _boardObject = new SceneObject(boardSprite);
            _boardObject.WorldMatrix = Matrix.CreateTranslation(new Vector3(graphics.Viewport.Width*0.5f, graphics.Viewport.Height*0.5f, GamePlayState.ZPositionMidground));

            PointSprite pressSprite = new PointSprite(graphics, pointSpriteEffect, GameTextures.InstructionPressMouseTexture);
            pressSprite.Size = new Vector2(1024.0f * 0.5f, 256.0f * 0.5f);
            _pressObject = new SceneObject(pressSprite);
            _pressObject.WorldMatrix = Matrix.CreateTranslation(new Vector3(0.0f, 0.0f, GamePlayState.ZPositionMidground));

            _titleText = name;
            _titleHalfWidth = _font.MeasureString(_titleText).X * 0.5f;
        }

        public override void OnAddedToSceneManager(SceneObjectManager manager)
        {
            base.OnAddedToSceneManager(manager);

            // Play the sound
            _soundInstance = GameSounds.NewWordSound.CreateInstance();
            _soundInstance.IsLooped = false;
            _soundInstance.Play();

            //manager.AddObject(_boardObject);
        }

        public override void OnRemovedFromSceneManager(SceneObjectManager manager)
        {
            base.OnRemovedFromSceneManager(manager);

            //manager.RemoveObject(_boardObject);
        }

        public override void Render(GraphicsDevice graphics, Camera camera)
        {
            base.Render(graphics, camera);

            _boardObject.Position = new Vector3(Position.X, Position.Y + _boardObjectYOffset, Position.Z);
            _boardObject.Render(graphics, camera);

            _pressObject.Position = new Vector3(Position.X, Position.Y + _pressObjectYOffset, Position.Z);
            _pressObject.Render(graphics, camera);
        }

        public override void RenderText(GraphicsDevice graphicsDevice, SpriteBatch spriteBatch)
        {
            // Draw title
            float posX = Position.X - _titleHalfWidth;
            float posY = Position.Y + _titlePosY;

            DrawShadowedText(spriteBatch, _font, _titleText, posX, posY);
        }
    }
}
