using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class ScoreCorrectObject : SceneObject
    {
        private const float _durationMS = 2000.0f;

        private SpriteFont _font;
        private string _scoreText;

        private float _lifeMS = 0.0f;

        public ScoreCorrectObject(SpriteFont font, int score)
        {
            _font = font;
            _scoreText = score.ToString();

            AddForce(new Vector3(0.0f, -3000.0f, 0.0f));

            _lifeMS = _durationMS;
        }

        public override void Update(GameTime time)
        {
            base.Update(time);

            _lifeMS -= (float)time.ElapsedGameTime.TotalMilliseconds;
            if(_lifeMS <= 0.0f)
            {
                MarkForDeletion();
            }
        }

        public override void RenderText(GraphicsDevice graphicsDevice, SpriteBatch spriteBatch)
        {
            float posX = Position.X;
            float posY = Position.Y;

            DrawCorrectScoreText(spriteBatch, _font, _scoreText, posX, posY);
        }
    }
}
