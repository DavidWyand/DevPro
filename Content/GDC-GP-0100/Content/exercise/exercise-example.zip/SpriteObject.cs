using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class SpriteObject : SceneObject
    {
        private Sprite2D _sprite = null;
        private bool _killOnAnimEnd;

        public SpriteObject(TextureBase texture, Vector2 size, bool killOnAnimEnd = true)
            : base()
        {
            _sprite = new Sprite2D(Position, size, texture);
            _killOnAnimEnd = killOnAnimEnd;
        }

        public override void Render(GraphicsDevice graphics, Camera camera)
        {
            base.Render(graphics, camera);

            if (_sprite != null && !DeleteObject)
            {
                _sprite.Render(graphics, camera);
            }
        }

        public override void Update(GameTime time)
        {
            base.Update(time);

            if (_sprite != null)
            {
                TextureAnimated texture = _sprite.Texture as TextureAnimated;
                if (texture != null)
                {
                    if (!texture.IsAnimating() && _killOnAnimEnd)
                    {
                        // Must be done the single shot animation.  Mark for deletion
                        MarkForDeletion();
                    }
                }

                _sprite.Position = Position;
                _sprite.Update((float)time.ElapsedGameTime.TotalSeconds);
            }
        }
    }
}
