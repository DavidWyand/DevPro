using System;
using GameDev.Utilities;

namespace GameDev.Exercises
{
    class FunctionsExercise : Module
    {
        private SpriteManager _spriteManager = new SpriteManager();
        
        private Sprite _pigOne;
        private Sprite _pigTwo;

        private SpriteTexture _pigOneTexture;
        private SpriteTexture _pigTwoTexture;

        //*********** Begin Focus Area 1 ***********//
        
        // Write the InitializeSprite method here

        // Write the InitializeTexture method here

        // Write the SetSpriteProperties method here
        
        //*********** End Focus Area 1 ***********//


        //*********** Begin Focus Area 6 ***********//
        
        // Declare MoveDelegate here

        // Define MoveVertical here

        // Define MoveHorizontal here

        //*********** End Focus Area 6 ***********//


        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            //*********** Begin Focus Area 2 ***********//
            
            // Call InitializeSprite with pigs here

            
            //*********** End Focus Area 2 ***********//


            //*********** Begin Focus Area 3 ***********//
            
            // Call SetSpriteProperties with pigs here

            //*********** End Focus Area 3 ***********//

        }

        //*********** Begin Focus Area 4 ***********//
        
        // Fill in the LoadContent function here
        public override void LoadContent()
        {
            
        }

        //*********** End Focus Area 4 ***********//


        //*********** Begin Focus Area 5 ***********//
        
        // Fill in the Render function here
        public override void Render()
        {
            
        }

        //*********** End Focus Area 5 ***********//



        //*********** Begin Focus Area 7 ***********//
        public override void Update(Microsoft.Xna.Framework.GameTime time)
        {
            
        }
        //*********** End Focus Area 7 ***********//

          
    }
}
