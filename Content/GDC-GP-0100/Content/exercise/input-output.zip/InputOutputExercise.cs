using GameDev;
using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace GameDev
{
    class InputOutputExercise : Module
    {
        private SpriteBatch _spriteBatch;
        private SpriteFont _font;

        private SpriteManager _spriteManager = new SpriteManager();
        private float _textureRatio = 17f;

        private Sprite _background;

        private Sprite _currentTower;
        private SpriteTexture[] _towerTextures;

        private List<Sprite> _towers;

        private Vector2 _mousePosition;
        private Vector2 _worldSpaceMousePosition;


        //For tracking the total number of shots fired 
        private int _totalResourcesUsed = 0;

        //*********** Begin Focus Area 1 ***********//
        
        //*********** End Focus Area 1 ***********//




        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {

            _background = new Sprite(0);
            _currentTower = new Sprite(1);

            _towerTextures = new SpriteTexture[4];

            _towers = new List<Sprite>();

            _mousePosition = new Vector2(0, 0);
            _worldSpaceMousePosition = new Vector2(0, 0);


            //*********** Begin Focus Area 2 ***********//

            //*********** End Focus Area 2 ***********//


        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>        
        public override void LoadContent()
        {
            _graphicsDevice.BlendState = BlendState.AlphaBlend;

            //Initialize the SpriteBatch for font rendering
            _spriteBatch = new SpriteBatch(_graphicsDevice);

            //Load the Font
            _font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");

            //Load the background
            SpriteTexture backgroundTexture = new SpriteTexture("Graphics\\SpaceBackground");
            backgroundTexture.LoadContent(_contentManager);
            _background.SetSpriteTexture(backgroundTexture);
            _background.SetSize(backgroundTexture.ImageWidth / _textureRatio, backgroundTexture.ImageHeight / _textureRatio);
            _spriteManager.AddSprite(_background);

            //load the tower textures
            _towerTextures[0] = new SpriteTexture("Graphics\\Tower1");
            _towerTextures[1] = new SpriteTexture("Graphics\\Tower2");
            _towerTextures[2] = new SpriteTexture("Graphics\\Tower3");
            _towerTextures[3] = new SpriteTexture("Graphics\\Tower4");

            foreach (SpriteTexture texture in _towerTextures)
            {
                texture.LoadContent(_contentManager);
            }

            _currentTower.SetSpriteTexture(_towerTextures[0]);
            _currentTower.SetSize(_towerTextures[0].ImageWidth / _textureRatio, _towerTextures[0].ImageHeight / _textureRatio);
            _spriteManager.AddSprite(_currentTower);
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            _currentTower.SetPosition(_worldSpaceMousePosition.X, _worldSpaceMousePosition.Y);
        }

        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {
            //*********** Begin Focus Area 4 ***********//



            //*********** End Focus Area 4 ***********//


            //*********** Begin Focus Area 6 ***********//

            //*********** End Focus Area 6 ***********//


            //*********** Begin Focus Area 7 ***********//

            //*********** End Focus Area 7 ***********//


            //*********** Begin Focus Area 8 ***********//

            //*********** End Focus Area 8 ***********//


            //*********** Begin Focus Area 9 ***********//

            //*********** End Focus Area 9 ***********//


            //*********** Begin Focus Area 10 ***********//



            //*********** End Focus Area 10 ***********//


            //*********** Begin Focus Area 5 ***********//

            //*********** End Focus Area 5 ***********//


        }


        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);

            _spriteBatch.Begin();
            _spriteBatch.DrawString(_font, "Total Resources Used: " + _totalResourcesUsed, new Vector2(0f, 0f), Color.White);
            _spriteBatch.End();

        }

        public override void Destroy()
        {
            //*********** Begin Focus Area 3 ***********//

            //*********** End Focus Area 3 ***********//



        }

        public Sprite CreateTower(SpriteTexture currentTowerTexture, Vector2 worldSpacePosition)
        {
            Sprite tower = new Sprite(1);
            SpriteTexture towerTexture = currentTowerTexture.Copy();
            towerTexture.LoadContent(_contentManager);
            tower.SetSpriteTexture(towerTexture);
            tower.SetSize(towerTexture.ImageWidth / _textureRatio, towerTexture.ImageHeight / _textureRatio);
            tower.SetPosition(worldSpacePosition.X, worldSpacePosition.Y);
            tower.SetVisible(true);
            _spriteManager.AddSprite(tower);

            return tower;
        }

        public Vector2 CalculateWorldSpacePosition(Vector2 mousePosition)
        {
            return new Vector2((mousePosition.X - (_graphicsDevice.Viewport.Width / 2)) / _textureRatio, -(mousePosition.Y - (_graphicsDevice.Viewport.Height / 2)) / _textureRatio);
        }
    }
}