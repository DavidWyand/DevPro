using GameDev.Utilities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameDev.Exercises
{
    class LoopsExercise : Module
    {
        private SpriteManager _spriteManager = new SpriteManager();
        private List<Sprite> _spriteList = new List<Sprite>();
        private float[] _spriteDirections;

        public override void Create()
        {
            float nextShipPositionX = 0.0f;
            float nextShipPositionY = 0.0f;

            //*********** Begin Focus Area 1 ***********//

            //*********** End Focus Area 1 ***********//


            _spriteDirections = new float[_spriteList.Count];

            for (int i = 0; i < _spriteList.Count; i++)
            {
                _spriteDirections[i] = -6.0f;
            }
        }

        public override void LoadContent()
        {
            //*********** Begin Focus Area 2 ***********//

            //*********** End Focus Area 2 ***********//

        }

        public override void Update(GameTime time)
        {
            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            //*********** Begin Focus Area 3 ***********//

            //*********** End Focus Area 3 ***********//

        }
        public override void Render()
        {
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);
        }
    }
}
