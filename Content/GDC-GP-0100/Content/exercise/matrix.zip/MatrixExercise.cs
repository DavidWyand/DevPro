using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class MatrixExercise : Module
    {
        // Items for the astronaut
        private Quad _astronautQuad;
        private Texture2D _astronautTexture;
        
        // Items for the planet
        private Quad _planetQuad;
        private Texture2D _planetTexture;
        
        // Astronaut transform matrices
        private Matrix _translationWorldMatrix;
        private Matrix _translationLocalMatrix;
        private Matrix _rotationMatrix;
        private Matrix _scaleMatrix;

        // Calculated world matrix for the astronaut
        private Matrix _astronautWorldMatrix;

        // Astronaut's current rotation
        private float _currentRotation;

        // The amount the astronaut will rotate per second
        private float _rotationPerSecond;

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            // Location of the planet and the point which the astronaut will orbit
            Vector2 planetLocation = new Vector2(5.0f, 5.0f);

            // Build the rendered quads
            _astronautQuad = new Quad(new Vector3(0, 0, 0), 0.622f, 1.0f);
            _planetQuad = new Quad(new Vector3(planetLocation.X, planetLocation.Y, 0.0f), 2.0f, 2.0f);

            // Build the matrices for the astronaut

            //*********** Begin Focus Area 1 ***********//

            _translationWorldMatrix = Matrix.Identity;

            //*********** End Focus Area 1 ***********//


            //*********** Begin Focus Area 2 ***********//

            _translationLocalMatrix = Matrix.Identity;

            //*********** End Focus Area 2 ***********//


            //*********** Begin Focus Area 3 ***********//

            _currentRotation = 0.0f;
            _rotationMatrix = Matrix.Identity;

            //*********** End Focus Area 3 ***********//


            //*********** Begin Focus Area 4 ***********//

            _scaleMatrix = Matrix.Identity;

            //*********** End Focus Area 4 ***********//


            // Define the amount to rotate the astronaut each second, in radians
            _rotationPerSecond = MathHelper.ToRadians(-90.0f);
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            _graphicsDevice.BlendState = BlendState.AlphaBlend;

            // Load in texture for the astronaut quad
            _astronautTexture = _contentManager.Load<Texture2D>("Graphics\\astronaut");
            _astronautQuad.SetTexture(_astronautTexture);

            // Load in the texture for the planet
            _planetTexture = _contentManager.Load<Texture2D>("Graphics\\planetoid");
            _planetQuad.SetTexture(_planetTexture);            
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            // Increase the astronaut's rotation
            _currentRotation += _rotationPerSecond * deltaSeconds;

            // Ensure that the current rotation is not more than 2Pi radians (360 degrees), or less than zero,
            // so that it's values are reasonable and won't jitter.
            _currentRotation %= -MathHelper.TwoPi;

            //*********** Begin Focus Area 5 ***********//

            // Update the rotation matrix

            //*********** End Focus Area 5 ***********//


            //*********** Begin Focus Area 6 ***********//

            // Build the astronaut's world matrix

            //*********** End Focus Area 6 ***********//

        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            // Render the planet
            DrawTexturedQuad(_planetQuad, Matrix.Identity);

            // Render the astronaut
            DrawTexturedQuad(_astronautQuad, _astronautWorldMatrix);
        }
    }
}
