using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using GameDev.Utilities;
using System;

namespace GameDev.Exercises
{
    class NumberSystemsExercise : Module
    {
        //*********** Begin Focus Area 1 ***********//

        //*********** End Focus Area 1 ***********//

          
        // Main SpriteManager which updates and renders all Sprite objects
        private SpriteManager _spriteManager = new SpriteManager();

        // Space background
        private Sprite _background = new Sprite(0);
        private SpriteTexture _backgroundTexture;

        // Player's ship
        private Sprite _ship = new Sprite(1);
        private SpriteTexture _shipTexture;
        

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            OrthoCamera camera = new OrthoCamera();
            camera.Bounds = _graphicsDevice.Viewport.Bounds;
            DefaultCamera = camera;

            // Build the background
            _backgroundTexture = new SpriteTexture("Graphics\\Space_Background");
            _backgroundTexture.LoadContent(_contentManager);
            _background.SetSpriteTexture(_backgroundTexture);
            _background.SetFlipVertical(true);
            _background.SetPosition(_graphicsDevice.Viewport.Bounds.Width / 2, _graphicsDevice.Viewport.Bounds.Height / 2);
            _background.SetSize(_graphicsDevice.Viewport.Bounds.Width, _graphicsDevice.Viewport.Bounds.Height);
            _spriteManager.AddSprite(_background);

            _shipTexture = new SpriteTexture("Graphics\\ship");
            _shipTexture.LoadContent(_contentManager);
            _ship.SetSpriteTexture(_shipTexture);
            _ship.SetFlipVertical(true);
            _ship.SetPosition(_graphicsDevice.Viewport.Bounds.Width / 2, _graphicsDevice.Viewport.Bounds.Height / 2);
            _ship.SetSize(_shipTexture.ImageWidth / 2, _shipTexture.ImageHeight / 2);
            _ship.SetVisible(false);
            _spriteManager.AddSprite(_ship);
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            float moveAmount = 1.0f;
            float rotateAmount = 1.0f;

            //*********** Begin Focus Area 2 ***********//

            //*********** End Focus Area 2 ***********//


            //*********** Begin Focus Area 3 ***********//
            
            _ship.RotateAmount(MathHelper.ToRadians(rotateAmount), 100);

            //*********** End Focus Area 3 ***********//


            //*********** Begin Focus Area 4 ***********//
            
            _ship.MoveAmount(new Vector2(moveAmount), 100);

            //*********** End Focus Area 4 ***********//


            // Update all sprites
            _spriteManager.UpdateSprites(time);
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            base.Render();

            // Render all sprites
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);
        }

        /// <summary>
        /// Handle input reaction here
        /// </summary>
        /// <param name="keyboardState">Main keyboard state in the game</param>
        /// <param name="mouseState">Main mouse state in the game</param>
        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {
            if (keyboardState.IsKeyDown(Keys.Space) && !_ship.Visible)
            {
                //*********** Begin Focus Area 5 ***********//

                //*********** End Focus Area 5 ***********//

            }

            if (keyboardState.IsKeyDown(Keys.Enter) && _ship.Visible)
            {
                //*********** Begin Focus Area 6 ***********//

                //*********** End Focus Area 6 ***********//

            }

            if (keyboardState.IsKeyDown(Keys.Right))
            {
                //*********** Begin Focus Area 7 ***********//

                //*********** End Focus Area 7 ***********//

            }

            if (keyboardState.IsKeyDown(Keys.Left))
            {
                //*********** Begin Focus Area 8 ***********//

                //*********** End Focus Area 8 ***********//

            }
        }
    }
}
