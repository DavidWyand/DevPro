using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;
using Box2D.XNA;
using Box2D.XNA.TestBed.Framework;


namespace GameDev
{
    class physics_order_of_operations : Module
    {
        #region Rendering
        private SpriteBatch _spriteBatch;
        // Used to draw the instructions
        private SpriteFont _font;
        #endregion
        // The physics API object
        private PhysicsAPI _physics = new PhysicsAPI();
        #region Input 
        // Tracks the current keyboard state
        private KeyboardState _currentKeyboardState;
        // Used for tracking the state LAST frame
        private KeyboardState _oldKeyboardState;
        // This object stores the Mouse Joint
        private MouseJoint _cachedMouseJoint;
        // Used for tracking mouse drag
        private bool _isMouseDown = false;
        #endregion
        
        #region Level Objects
        // The Wrecking Ball
        private Body _ball;
        // The object that it attaches to
        private Body _anchor;
        // This is a "blank" object, required for mouse joint
        private Body _worldBody;
        // The ground object
        private Body _groundBody;
        // The Boxes 2D array
        private Body[,] _boxesArray;
        #endregion
        
        #region Exercise Variables

        // The number of chain links
        private int _segments = 0;
        // Size of the wrecking ball
        private float _wreckingBallSize = 1.0f;
        // Row and columsn for the boxes
        private int _rows = 1;
        private int _cols = 1;
        #endregion

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();

            _spriteBatch = new SpriteBatch(_graphicsDevice);

            _font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");

            _physics.Init(new Vector2(0.0f, -30.0f), true, _graphicsDevice, _contentManager);
            
            _physics.SetGravity(-30.0f);

            BodyDef bodyDef = new BodyDef();
            
            _worldBody = _physics.B2DWorld.CreateBody(bodyDef);

            CreateScene();
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            _physics.Step();
            DoInput(time);
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            _physics.Draw();
            _spriteBatch.Begin();
            _spriteBatch.DrawString(_font, "Left and Right arrow keys apply force to wrecking ball.\n" +
                "You can also click and drag the ball.\n" +
                "Segments = " + Math.Abs(_segments).ToString() + 
                "\nSize = " + Math.Abs(_wreckingBallSize).ToString() + 
                "\nRows = " + Math.Abs(_rows).ToString() + 
                "\nColumns = " + Math.Abs(_cols).ToString(), new Vector2(0.0f, 0.0f), Color.White);
            _spriteBatch.End();
        }
        
        /// <summary>
        /// Process mouse and keyboard input
        /// </summary>
        private void DoInput(GameTime time)
        {
            _currentKeyboardState = Keyboard.GetState();
            if (_ball != null)
            {
                if (_currentKeyboardState.IsKeyDown(Keys.Right))
                {
                    _physics.ApplyForce(_ball, new Vector2(1.0f, 0.0f), 1000.0f);
                }
                if (_currentKeyboardState.IsKeyDown(Keys.Left))
                {
                    _physics.ApplyForce(_ball, new Vector2(-1.0f, 0.0f), 1000.0f);
                }
            }
            _oldKeyboardState = _currentKeyboardState;

            MouseState ms = Mouse.GetState();
            float A = _graphicsDevice.Viewport.Width;
            float B = _graphicsDevice.Viewport.Height;
            float Xmin = A * -0.5f;
            float Xmax = A * 0.5f;
            float Ymin = B * -0.5f;
            float Ymax = B * 0.5f;
            Vector2 mousePos = new Vector2(ms.Position.X, ms.Position.Y);
            mousePos.X = (mousePos.X - Xmax) * 0.1f;
            mousePos.Y = (-mousePos.Y + Ymax) * 0.1f;
            if (ms.LeftButton == ButtonState.Pressed)
            {
                MouseDown(mousePos);
                _isMouseDown = true;
            }
            if (ms.LeftButton == ButtonState.Released)
            {
                MouseUp(mousePos);
                _isMouseDown = false;
            }
            if (_isMouseDown)
            {
                MouseDragged(mousePos);
            }

        }
        
        /// <summary>
        /// Gets caled when the left button is pressed
        /// </summary>
        /// <param name="mousePos">Postion of the mouse</param>
        private void MouseDown(Vector2 mousePos)
        {
            // If we already have a mouse joint created, no need to test and create another one
            if (_cachedMouseJoint != null)
            {
                return;
            }
            // Define a _fixture that will serve as the found fixture (if we find one)
            Fixture _fixture = null;
            // Traverse through each of the balls fixtures, looking for one that is being clicked on by the mouse cursor
            Fixture ballFixtures = _ball.GetFixtureList();
            while (ballFixtures != null)
            {
                if (ballFixtures.TestPoint(mousePos))
                {
                    _fixture = ballFixtures;
                    break;
                }
                ballFixtures = ballFixtures.GetNext();
            }
            // If we've found a clicked on fixture, create a mouse joint and link it to the found fixture
            if (_fixture != null)
            {
                Body body = _fixture.GetBody();
                MouseJointDef md = new MouseJointDef();
                md.bodyA = _worldBody;
                md.bodyB = body;
                md.target = mousePos;
                md.maxForce = 1000.0f * body.GetMass();
                _cachedMouseJoint = (MouseJoint)_physics.B2DWorld.CreateJoint(md);
                body.SetAwake(true);
            }

        }
        
        /// <summary>
        /// Gets called when the left button is released
        /// </summary>
        /// <param name="mousePos">Position of the mouse</param>
        private void MouseUp(Vector2 mousePos)
        {
            // If we have a created mouse joint, and let go of the left button, destroy it (to release the attached body / fixture)
            if (_cachedMouseJoint != null)
            {
                _physics.B2DWorld.DestroyJoint(_cachedMouseJoint);
                _cachedMouseJoint = null;
            }
        }
        
        /// <summary>
        /// Gets called when the left mouse button is down
        /// </summary>
        /// <param name="mousePos">Position of the mouse</param>
        private void MouseDragged(Vector2 mousePos)
        {
            if (_isMouseDown)
            {
                // Move around the body / fixture that is attached to the mouse joint
                if (_cachedMouseJoint != null)
                {
                    _cachedMouseJoint.SetTarget(mousePos);
                }
            }
        }
        
        /// <summary>
        /// Creates the wrecking ball object
        /// </summary>
        /// <param name="segments">Number of links in the chain</param>
        /// <param name="size">Size of the wrecking ball</param>
        private void CreateWreckingBall(int segments, float size)
        {
            size = Math.Abs(size);
            segments = Math.Abs(segments);
            if (segments == 0)
                segments = 1;
            Vector2[] verts = 
            {
                new Vector2(-1.0f, 0.0f),
                new Vector2(-3.0f, -8.0f),
                new Vector2(3.0f, -8.0f),
                new Vector2(1.0f, 0.0f)
            };
            _anchor = _physics.CreateStaticQuad(new Vector2(0.0f, 40.0f), verts, Color.Black);
            _ball = _physics.CreateCircle(new Vector2(-50.0f, 10.0f), size, Color.Black, 1.0f, 0.2f, 0.3f);

            Body[] ropeSegments = new Body[segments];
            float startingHeight = (float)segments / -2.0f;
            for (int i = 0; i < segments; i++)
            {
                ropeSegments[i] = _physics.CreateCircle(new Vector2(0.0f, startingHeight + (i)), 1.0f, Color.Black);
            }
            _physics.RevoluteJoint(_anchor, ropeSegments[segments - 1], new Vector2(0.0f, -8.0f), new Vector2(0.0f, 1.0f));
            _physics.RevoluteJoint(_ball, ropeSegments[0], new Vector2(0.0f, 5.0f), new Vector2(0.0f, -1.0f));

            for (int i = 1; i < ropeSegments.Length; i++)
            {
                _physics.RevoluteJoint(ropeSegments[i], ropeSegments[i - 1], new Vector2(0.0f, -1.0f), new Vector2(0.0f, 1.0f));
             
            }
        }
        
        /// <summary>
        /// Creates a 2D array of boxes
        /// </summary>
        /// <param name="rows">How many rows of boxes</param>
        /// <param name="cols">How many columns of boxes</param>
        /// <returns></returns>
        private Body[,] CreateBoxes(int rows, int cols)
        {
            rows = Math.Abs(rows);
            cols = Math.Abs(cols);
            Body[,] boxes = new Body[rows, cols];
            Vector2 startingPos = new Vector2(-10.0f, -35.0f);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    boxes[i,j] =  _physics.CreateBox(startingPos.X + (i * 3.0f), startingPos.Y + (j * 3.0f), 2.0f, 2.0f, _physics.RandomColor());
                }
            }
            return boxes;
        }
        
        /// <summary>
        /// Creates the entire scene
        /// </summary>
        private void CreateScene()
        {
            // Create the ground that the boxes will be placed on
            _groundBody = _physics.CreateStaticQuad(-100.0f, -40.0f, 200.0f, 1.0f, Color.Black);
            // Set up variables for this exercise
            int X = 1;
            int Y = 2;
            int Z = 3;
            float a = 1.0f;
            float b = 2.0f;
            float c = 3.0f;
            


            //*********** Begin Focus Area 3 ***********//
            _rows = X + Y * X + Y - Y - Z;
            _cols = Z + Y / Z - Y + Y;
            //*********** End Focus Area 3 ***********//

                                  

            //*********** Begin Focus Area 1 ***********//
            _segments = X + Z * Y / Y * X + Z / Y - X * Y;
            //*********** End Focus Area 1 ***********//


            //*********** Begin Focus Area 2 ***********//
            _wreckingBallSize = a - b + b * c - a - b;
            //*********** End Focus Area 2 ***********//

          
            CreateWreckingBall(_segments, _wreckingBallSize);
            _boxesArray = CreateBoxes(_rows, _cols);
        }
        
    }
}
