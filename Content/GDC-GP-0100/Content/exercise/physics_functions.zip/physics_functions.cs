using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Box2D.XNA;
using System.Diagnostics;
using System.Collections.Generic;

namespace GameDev
{
    class Key
    {
        
    };

    class physics_functions : Module
    {
        // Spritebatch so I can draw text.
        SpriteBatch spriteBatch;

        SpriteFont font;

        // Physics api to assist in shape creation
        PhysicsAPI physics = new PhysicsAPI();
        // The main vehicle body we will use for the player
        Body PlayerVehicle;
        // A list of wheeljoints so we can access them in the update loop
        List<Joint> wheeljoints = new List<Joint>();
        // speed multiplier for tracking input and motor speed
        float speedmultiplier = 0.0f;
        // The speed to use with the speed multiplier to control speed.  This is the wheel revolutions per second in radians.
        float wheelspeed = 400.0f;

        Key m_StartKey = null;

        private float _LL = 0;
        private float _LR = 0;
        private float _UR = 0;
        private float _UR_Slide = 0;
        private float _UL_Slide = 0;
        private float _RampSlide = 0.0f;
        private float _WheelBounce = 0.0f;


        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            //*********** Begin Focus Area 1 ***********//


            //*********** End Focus Area 1 ***********//


            // assign the appropriate floor creation function to the delegate
            //createFloorDelegate = CreateDefaultFloor;

            // Assign the appropriate vehicle creation function to createvehicledelegate.
            //createVehicleDelegate = CreateDefaultVehicle;
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();
            spriteBatch = new SpriteBatch(_graphicsDevice);
            
            font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");

            physics.Init(new Vector2(0.0f, -32.0f), true, _graphicsDevice, _contentManager);

            // Create the floor using the delegate
            CreateFloor();

            CreateVehicle(-30.0f, 0.0f);
        }
        

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            
            speedmultiplier = 0.0f;

            if(Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                speedmultiplier = -1.0f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {
                speedmultiplier = 1.0f;
            }

            float absRot = Math.Abs(PlayerVehicle.Rotation%6.28f);

            if (absRot > 1.57f && absRot < 4.71 )
            {
                speedmultiplier = 0.0f;
            }

            if (m_StartKey == null)
            {
                speedmultiplier = 0.0f;
            }

            foreach (RevoluteJoint j in wheeljoints)
            {
                j.SetMotorSpeed(wheelspeed * speedmultiplier);
            }
            

            physics.Step();
            
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            physics.Draw();

            spriteBatch.Begin();
            spriteBatch.DrawString(font, "GOAL", new Vector2(1150.0f, 650.0f), Color.White);

            spriteBatch.End();

        }

        /// <summary>
        /// Creates the default vehicle at the specified x and y coordinates.
        /// </summary>
        /// <param name="positionx">horizontal position on the screen between -75.0f to +75.0f</param>
        /// <param name="positiony">Vertical position on the screen</param>
        void CreateVehicle(float positionx = 0.0f, float positiony = 0.0f)
        {
            
            // first create a vehicle body
            Body vehicle = CreatePiece(positionx, positiony, 8.0f, 2.0f, Color.White);
        
            // Create the cab piece to this vehicle
            Body vehiclecab = CreatePiece(-0.5f+positionx, 3.25f+positiony, 3.0f, 1.0f, Color.White);

            // Attach the piece to the vehicle
            AttachPiece(vehicle, vehiclecab, -1.0f, 3.25f);
            
            // Create the bumper piece
            Body vehiclefrontbumper = CreatePiece(12.0f+positionx, -1.0f+positiony, 1.0f, 1.0f, Color.Gray);

            // Attach the piece to the vehicle
            AttachPiece(vehicle, vehiclefrontbumper, 9.0f, -1.0f);            
            
            // Add a spoiler to the vehicle
            Body vehiclespoiler = CreatePiece(positionx, 3.0f+positiony, 1.5f, 1.0f, Color.Red);                

            // Attach the piece to the vehicle
            AttachPiece(vehicle, vehiclespoiler, -10.0f, 3.0f);
            
            // Add front wheel to the vehicle
            Body frontwheel = CreateWheel(8.0f+positionx, -3.1f+positiony, 3.0f);

            // add a joint to attach the wheel
            AttachWheel(vehicle, frontwheel, 7.0f, -5.8f);         

            // add Rear wheel to the vehicle
            Body rearwheel = CreateWheel(-8.0f+positionx, -3.1f+positiony, 3.0f);
            
            // add a joint to attach the wheel
            AttachWheel(vehicle, rearwheel, -7.0f, -5.8f);
               
            // Assign the vehicle to PlayerVehicle so we have access to it
            PlayerVehicle = vehicle;
 
        }

        void CreateFloor()
        {
            // physics.CreateBox(new Vector2(0, -30), new Vector2(50, 1), Color.Purple).SetAwake(false);
            Vector2[] groundpoints = new Vector2[4];
            groundpoints[0] = new Vector2(-75, 2.5f);
            groundpoints[1] = new Vector2(-75, -2.5f);
            groundpoints[2] = new Vector2(45, -2.5f);
            groundpoints[3] = new Vector2(45, 2.5f);
            physics.CreateStaticQuad(new Vector2(0, -35), groundpoints, Color.Purple, 1.0f);

            // Create a goal area

            Vector2[] goalpoints = new Vector2[4];
            goalpoints[0] = new Vector2(45, 2.5f);
            goalpoints[1] = new Vector2(45, -2.5f);
            goalpoints[2] = new Vector2(75, -2.5f);
            goalpoints[3] = new Vector2(75, 2.5f);
            physics.CreateStaticQuad(new Vector2(0, -35), goalpoints, Color.Green, 0.8f);

            // Goal blocker
            Vector2[] rwallpoints = new Vector2[4];
            rwallpoints[0] = new Vector2(72, 85.0f);
            rwallpoints[1] = new Vector2(72, -75.5f);
            rwallpoints[2] = new Vector2(85, -75.5f);
            rwallpoints[3] = new Vector2(85, 85.0f);
            physics.CreateStaticQuad(new Vector2(0, -35), rwallpoints, Color.Green, 0.8f);


            // Create a wall behind so we don't fall off backwards.
            Vector2[] backwallpoints = new Vector2[4];
            backwallpoints[0] = new Vector2(-2.5f, 75.0f);
            backwallpoints[1] = new Vector2(-2.5f, -75.0f);
            backwallpoints[2] = new Vector2(2.5f, -75.0f);
            backwallpoints[3] = new Vector2(2.5f, 75.0f);
            physics.CreateStaticQuad(new Vector2(-75.0f, 0.0f), backwallpoints, Color.Purple);

            // Create ramp
            Vector2[] ramp = new Vector2[4];
            ramp[0] = new Vector2(-5 + _LL, -2.0f);
            ramp[1] = new Vector2(1 + _LR, -2.0f);
            ramp[2] = new Vector2(1 + _UR_Slide, 4.0f + _UR);


            physics.CreateTriangle(10.0f+ _RampSlide, -30.5f, ramp, Color.Yellow, 100.0f, 0.8f);
            

            // Create obstacles to block the vehicle
            Vector2[] jumpWall = new Vector2[4];
            jumpWall[0] = new Vector2(-1 , -2.0f);
            jumpWall[1] = new Vector2(1 , -2.0f);
            jumpWall[2] = new Vector2(1, 30.0f);
            jumpWall[3] = new Vector2(-1, 30.0f );

            physics.CreateStaticQuad(new Vector2(20.0f, -30.5f), jumpWall, Color.Red, 0.8f,0.3f);
        }

        #region UtilityFunctions
        

        Body CreatePiece(float xpos, float ypos, float xsize, float ysize, Color color)
        {
            return physics.CreateBox(xpos, ypos, new Vector2(xsize, ysize), color,0.3f);
        }

        Body CreateWheel(float xpos, float ypos, float size)
        {
            // Create the wheel and return it
            return physics.CreateCircle(new Vector2(xpos, ypos), size, Color.Black, 10.0f, 1.0f, 0.5f + _WheelBounce);
        }

        void AttachPiece(Body vehicle, Body piece, float xpos, float ypos)
        {
            // Create a weld joint to attach pieces together
            physics.WeldJoint(vehicle, piece, new Vector2(xpos, ypos), new Vector2(0, 0), false);
        }

        void AttachWheel(Body vehicle, Body wheel, float xpos, float ypos)
        {
            // Create a revolut joint to attach the wheel to the vehicle            
            RevoluteJoint wheeljoint = (RevoluteJoint)physics.RevoluteJoint(vehicle, wheel, new Vector2(xpos, ypos), new Vector2(0, 0),4.0f,false);
            // Set the torque for the wheel
            wheeljoint.SetMaxMotorTorque(80000.0f);
            // Add the wheel joint to the array of wheels so we can control them in the update loop
            wheeljoints.Add(wheeljoint);

        }

        Key GetKey()
        {
            return new Key();
        }

        void StartCar( Key keyIn )
        {
            m_StartKey = keyIn;
        }

        void LL_Slide(float slideLeft = 1.0f)
        {
            _LL -= slideLeft;
        }

        void LR_Slide(float slideRight = 1.0f)
        {
            _LR += slideRight;
        }

        void UR_Adjust(float slideLeft,float growUp)
        {
            _UR_Slide -= slideLeft;
            _UR += growUp;
        }

        void SlideRamp( float slideRight )
        {
            _RampSlide = slideRight;
        }

        void SetTireBounce( float addBounce )
        {
            _WheelBounce = addBounce;
        }
        #endregion

    }
}
