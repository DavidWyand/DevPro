using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;
using System.Collections.Generic;
using Box2D.XNA;

namespace GameDev
{
    class physics_loops : Module
    {
        // Various states for the moving platforms
        private enum PlatformState
        {
            Up,
            Down,
            Paused,
            BeginUp,
            BeginDown
        }

        // Class to define a moving platform
        private class MovingPlatform
        {
            public Body Platform;
            public float MaxY;
            public float MinY;
            public float Speed;
            public float PauseTime;
            public float PauseCountdownTimer;
            public PlatformState MovementState;
            public PlatformState MovementNextState;
        }

        private SpriteBatch _spriteBatch;

        private SpriteFont _font;

        // Various help text
        private string _playerHelpText = "LEFT ARROW and RIGHT ARROW to rotate.";
        private string _finishHelpText = "Race to the finish!";

        // Holds the time that is displayed at the top of the screen
        private string _timeText = "00:00";

        private PhysicsAPI _physics = new PhysicsAPI();

        // Track keyboard state
        private KeyboardState _currentKeyboardState;
        private KeyboardState _oldKeyboardState;

        // The ball that is controlled by the player
        private Body _ball = null;

        // List to store the elevators
        private List<MovingPlatform> _elevators = new List<MovingPlatform>();

        // Lists to store the moving platforms at the bottom of the screen
        private List<MovingPlatform> _bottomLeftPlatforms = new List<MovingPlatform>();
        private List<MovingPlatform> _bottomRightPlatforms = new List<MovingPlatform>();

        // Indicates that the player has moved this tick
        private bool _playerHasMoved = false;

        // Indicates that the game has started (triggered when the player starts to move)
        private bool _gameStart = false;

        // Indicates that the game has ended (triggered when the player reaches the green box)
        private bool _gameOver = false;

        // Tracks the time the game started
        private double _startingTime = 0.0;

        // Tracks how much time has passed until GameOver
        private long _playedMilliseconds = 0;

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();

            _spriteBatch = new SpriteBatch(_graphicsDevice);

            _font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");

            _physics.Init(new Vector2(0.0f, -30.0f), true, _graphicsDevice, _contentManager);

            // Create the static platforms
            CreatePlatform(new Vector2(-56.25f, 20.0f), new Vector2(22.5f, 5.0f), Color.Red);
            CreatePlatform(new Vector2(-70.0f, 25.0f), new Vector2(5.0f, 15.0f), Color.Red);
            CreatePlatform(new Vector2(0.0f, 20.0f), new Vector2(10.0f, 5.0f), Color.Red);
            CreatePlatform(new Vector2(50.0f, 20.0f), new Vector2(10.0f, 5.0f), Color.Red);

            CreatePlatform(new Vector2(50.0f, -5.0f), new Vector2(10.0f, 5.0f), Color.Red);
            CreatePlatform(new Vector2(0.0f, 0.0f), new Vector2(10.0f, 5.0f), Color.Red);
            CreatePlatform(new Vector2(-50.0f, -5.0f), new Vector2(10.0f, 5.0f), Color.Red);

            CreatePlatform(new Vector2(-50.0f, -31.5f), new Vector2(10.0f, 8.0f), Color.Red);
            CreatePlatform(new Vector2(0.0f, -31.5f), new Vector2(10.0f, 8.0f), Color.Red);
            CreatePlatform(new Vector2(50.625f, -31.5f), new Vector2(11.25f, 8.0f), Color.Red);
            CreatePlatform(new Vector2(61.875f, -34.0f), new Vector2(11.25f, 3.0f), Color.Green);
            CreatePlatform(new Vector2(70.0f, -26.5f), new Vector2(5.0f, 18.0f), Color.Red);
            CreatePlatform(new Vector2(56.25f, -20.0f), new Vector2(22.5f, 5.0f), Color.Red);
            CreatePlatform(new Vector2(50.0f, -12.5f), new Vector2(5.0f, 10.0f), Color.Red);

            // Create the elevators
            CreateElevators();

            // Create the bridges
            CreateTopBridges();
            CreateMiddleBridges();
            CreateBottomBridges();

            // Create the ball
            _ball = _physics.CreateCircle(new Vector2(-65.0f, 25.0f), 2.0f, Color.Orange, 3.0f, 6.0f, 0.0f);
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            _physics.Step();

            // Update each of the moving platforms
            UpdateMovingPlatforms(time, _elevators);
            UpdateMovingPlatforms(time, _bottomLeftPlatforms);
            UpdateMovingPlatforms(time, _bottomRightPlatforms);

            // Process user input
            DoInput(time);

            // Check if the game is over
            if(!_gameOver)
            {
                _gameOver = CheckGameOver();
            }

            // Start the timer once the player has stared moving
            if(_playerHasMoved && !_gameOver)
            {
                if(_gameStart)
                {
                    // Update the time
                    _playedMilliseconds = (int)(time.TotalGameTime.TotalMilliseconds - _startingTime);
                }
                else
                {
                    // Start the game and initialize the time
                    _gameStart = true;
                    _startingTime = time.TotalGameTime.TotalMilliseconds;
                    _playedMilliseconds = 0;
                }
            }
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            _physics.Draw();

            _spriteBatch.Begin();

            // Render the player help text
            Vector2 pos = new Vector2(15.0f, 210.0f);
            _spriteBatch.DrawString(_font, _playerHelpText, pos, Color.White);

            // Render the finish line help text
            pos.X = 1060.0f;
            pos.Y = 680.0f;
            _spriteBatch.DrawString(_font, _finishHelpText, pos, Color.White);

            // Calculate the timer's units
            long milliseconds;
            long seconds = Math.DivRem(_playedMilliseconds, 1000, out milliseconds);
            long minuteFrac;
            long minutes = Math.DivRem(seconds, 60, out minuteFrac);

            // Render the timer
            pos.X = 590.0f;
            pos.Y = 30.0f;
            _timeText = minutes.ToString("D2") + ":" + seconds.ToString("D2") + "." + milliseconds.ToString("D3");
            Color scoreColor = Color.White;
            if(_gameOver)
            {
                // Change the time to this color when the game is over
                scoreColor = Color.Yellow;
            }
            _spriteBatch.DrawString(_font, _timeText, pos, scoreColor);

            _spriteBatch.End();
        }

        /// <summary>
        /// Process keyboard input
        /// </summary>
        private void DoInput(GameTime time)
        {
            _currentKeyboardState = Keyboard.GetState();

            // Process the left arrow key being pressed
            if (_currentKeyboardState.IsKeyDown(Keys.Left))
            {
                if (_ball != null)
                {
                    // Apply torque forces to the ball
                    _physics.ApplyTorque(_ball, 1200.0f);
                    _playerHasMoved = true;
                }
            }

            // Process the right arrow key being pressed
            if (_currentKeyboardState.IsKeyDown(Keys.Right))
            {
                if (_ball != null)
                {
                    // Apply torque forces to the ball
                    _physics.ApplyTorque(_ball, -1200.0f);
                    _playerHasMoved = true;
                }
            }

            _oldKeyboardState = _currentKeyboardState;
        }

        /// <summary>
        /// Create a physics platform of the given position, size, and color
        /// </summary>
        /// <param name="position">Vector2 representing the platform's position</param>
        /// <param name="size">Vector2 representing the platform's size</param>
        /// <param name="color">Color of the platform</param>
        /// <returns>Physics Body</returns>
        private Body CreatePlatform(Vector2 position, Vector2 size, Color color)
        {
            Vector2[] verts = new Vector2[]
            {
                new Vector2(-0.5f * size.X, 0.5f * size.Y),
                new Vector2(-0.5f * size.X, -0.5f * size.Y),
                new Vector2(0.5f * size.X, -0.5f * size.Y),
                new Vector2(0.5f * size.X, 0.5f * size.Y),
            };

            return _physics.CreateStaticQuad(position, verts, color, 2.0f, 0.0f);
        }

        /// <summary>
        /// Create a wedge shaped physics platform of the given posistion, size, and color
        /// </summary>
        /// <param name="position">Vector2 representing the platform's position</param>
        /// <param name="size">Vector2 representing the platform's size</param>
        /// <param name="color">Color of the platform</param>
        /// <returns>Physics Body</returns>
        private Body CreateWedgePlatform(Vector2 position, Vector2 size, Color color)
        {
            Vector2[] verts = new Vector2[]
            {
                new Vector2(-0.5f * size.X, 0.5f * size.Y),
                new Vector2(-0.4f * size.X, -0.5f * size.Y),
                new Vector2(0.4f * size.X, -0.5f * size.Y),
                new Vector2(0.5f * size.X, 0.5f * size.Y),
            };

            return _physics.CreateStaticQuad(position, verts, color, 2.0f, 0.0f);
        }

        /// <summary>
        /// Create a physics platform that is intended to move like an elevator
        /// </summary>
        /// <param name="position">Vector2 representing the platform's position</param>
        /// <param name="size">Vector2 representing the platform's size</param>
        /// <param name="color">Color of the platform</param>
        /// <param name="friction">Friction of the platform's surface</param>
        /// <param name="restitution">Restitution (amount of force given back to a physics body on impact) of the platform's surface</param>
        /// <returns>Physics Body</returns>
        private Body CreateElevator(Vector2 position, Vector2 size, Color color, float friction = 0.3f, float restitution = 0.3f)
        {
            Vector2[] verts = new Vector2[]
            {
                new Vector2(-0.5f * size.X, 0.5f * size.Y),
                new Vector2(-0.5f * size.X, -0.5f * size.Y),
                new Vector2(0.5f * size.X, -0.5f * size.Y),
                new Vector2(0.5f * size.X, 0.5f * size.Y),
            };

            // Create the physics body definition
            BodyDef quadBodyDef = new BodyDef();
            quadBodyDef.type = BodyType.Kinematic;
            quadBodyDef.position = position;

            // Create the physics body
            Body quadBody = _physics.B2DWorld.CreateBody(quadBodyDef);
            quadBody.DebugColor = color;

            // Create the shape of the body
            PolygonShape quadShape = new PolygonShape();
            quadShape.Set(verts, 4);

            // Attach the shape to the body
            Fixture f = quadBody.CreateFixture(quadShape, 0.0f);
            f.SetFriction(friction);
            f.SetRestitution(restitution);

            // Recalcuate the body's properties based on its shape
            quadBody.ResetMassData();

            return quadBody;
        }

        /// <summary>
        /// Create the bridges at the top of the screen
        /// </summary>
        private void CreateTopBridges()
        {
            //*********** Begin Focus Area 2 ***********//

            // The width of each segment platform
            float segmentWidth = 0.6f;

            //*********** End Focus Area 2 ***********//


            // The height of each segment platform
            float segmentHeight = 2.0f;

            // Generate the platform segments on the left
            float segmentXPosition = -45.0f;

            //*********** Begin Focus Area 1 ***********//

            CreatePlatform(new Vector2(segmentXPosition + segmentWidth * 0.5f, 21.5f), new Vector2(segmentWidth, segmentHeight), Color.Gray);
            segmentXPosition += segmentWidth;

            //*********** End Focus Area 1 ***********//


            // Generate the platform segments on the right
            segmentXPosition = 5.0f;

            //*********** Begin Focus Area 3 ***********//

            CreatePlatform(new Vector2(segmentXPosition + segmentWidth * 0.5f, 21.5f), new Vector2(segmentWidth, 2.0f), Color.Gray);
            segmentXPosition += segmentWidth;

            //*********** End Focus Area 3 ***********//

        }

        /// <summary>
        /// Create the bridges in the middle of the screen
        /// </summary>
        private void CreateMiddleBridges()
        {
            //*********** Begin Focus Area 5 ***********//

            // The width of each platform segment
            float segmentWidth = 0.3f;

            //*********** End Focus Area 5 ***********//


            // The height of each platform segment
            float segmentHeight = 2.0f;

            // Calculate the angle and distance based on the span needed to cover
            float spanX = 40.0f;
            float spanY = 5.0f;
            float angle = (float)Math.Atan2(spanY, spanX);
            float distance = (float)Math.Sqrt(spanX * spanX + spanY * spanY);

            // Calculate the amount to advance our values per platform segment
            float stepX = segmentWidth * (float)Math.Cos(angle);
            float stepY = spanY / 8;
            float offsetX = segmentHeight * (float)Math.Sin(angle);
            float offsetY = segmentWidth * (float)Math.Sin(angle) * 0.5f;

            // Generate the platform segments on the left
            float segmentXPosition = -45.0f;

            int i = 0;
            Body body = null;

            //*********** Begin Focus Area 4 ***********//

            body = CreateWedgePlatform(new Vector2(segmentXPosition + segmentWidth * 0.5f + offsetX, -3.5f + offsetY + stepY * i), new Vector2(segmentWidth, segmentHeight), Color.DarkSlateGray);
            body.SetTransform(body.GetPosition(), angle);
            segmentXPosition += stepX;
            i += 1;

            //*********** End Focus Area 4 ***********//


            // Generate the platform segments on the right
            segmentXPosition = 4.75f;

            i = 0;

            //*********** Begin Focus Area 6 ***********//

            body = CreateWedgePlatform(new Vector2(segmentXPosition + segmentWidth * 0.5f + offsetX, 1.5f - offsetY - stepY * i), new Vector2(segmentWidth, segmentHeight), Color.DarkSlateGray);
            body.SetTransform(body.GetPosition(), -angle);
            segmentXPosition += stepX;
            i += 1;

            //*********** End Focus Area 6 ***********//


        }

        /// <summary>
        /// Create the bridges at the bottom of the screen
        /// </summary>
        private void CreateBottomBridges()
        {
            //*********** Begin Focus Area 8 ***********//

            // The width of each platform segment
            float segmentWidth = 0.2f;

            //*********** End Focus Area 8 ***********//



            // The height of each platform segment
            float segmentHeight = 2.0f;

            // Define all of the platform segments and add them to the lists.  The same
            // number of platform segments will be created on the left and right sides of
            // the screen.
            for (int i = 0; i < 8; ++i)
            {
                MovingPlatform leftSegment = new MovingPlatform();
                leftSegment.MaxY = -28.5f;
                leftSegment.MinY = -34.5f;
                leftSegment.Speed = 5.0f;
                leftSegment.PauseTime = 0.0f;
                leftSegment.PauseCountdownTimer = 0.0f;
                leftSegment.MovementState = PlatformState.Paused;
                leftSegment.MovementNextState = PlatformState.Paused;

                _bottomLeftPlatforms.Add(leftSegment);

                MovingPlatform rightSegment = new MovingPlatform();
                rightSegment.MaxY = -28.5f;
                rightSegment.MinY = -34.5f;
                rightSegment.Speed = 5.0f;
                rightSegment.PauseTime = 0.0f;
                rightSegment.PauseCountdownTimer = 0.0f;
                rightSegment.MovementState = PlatformState.Paused;
                rightSegment.MovementNextState = PlatformState.Paused;

                _bottomRightPlatforms.Add(rightSegment);
            }

            // Create each left platform segment instance
            float segmentX = -45.0f;
            float segmentY = -28.5f;

            //*********** Begin Focus Area 7 ***********//

            //platform.Platform = CreateBottomPlatformInstance(new Vector2(segmentX + segmentWidth * 0.5f, segmentY), new Vector2(segmentWidth, segmentHeight));
            //platform.MovementState = PlatformState.BeginUp;
            //segmentX += segmentWidth;
            //segmentY -= 0.85f;

            //*********** End Focus Area 7 ***********//


            // Create each right platform segment instance
            segmentX = 5.0f;
            segmentY = -34.5f;

            //*********** Begin Focus Area 9 ***********//

            //platform.Platform = CreateBottomPlatformInstance(new Vector2(segmentX + segmentWidth * 0.5f, segmentY), new Vector2(segmentWidth, segmentHeight));
            //platform.MovementState = PlatformState.BeginDown;
            //segmentX += segmentWidth;
            //segmentY += 0.85f;

            //*********** End Focus Area 9 ***********//

        }

        /// <summary>
        /// Create a physics body for a single bottom platform instance
        /// </summary>
        /// <param name="position">Vector2 representing the platform's position</param>
        /// <param name="size">Vector2 representing the platform's size</param>
        /// <returns>Physics Body</returns>
        private Body CreateBottomPlatformInstance(Vector2 position, Vector2 size)
        {
            Body platform = CreateElevator(position, size, Color.SaddleBrown);
            return platform;
        }

        /// <summary>
        /// Create the elevators for the level
        /// </summary>
        private void CreateElevators()
        {
            // Elevator 1
            MovingPlatform elevator1 = new MovingPlatform();
            elevator1.MaxY = 20.0f;
            elevator1.MinY = -5.0f;
            elevator1.Speed = 10.0f;
            elevator1.PauseTime = 1.0f;
            elevator1.PauseCountdownTimer = 1.0f;
            elevator1.MovementState = PlatformState.Paused;
            elevator1.MovementNextState = PlatformState.Down;
            elevator1.Platform = CreateElevator(new Vector2(64.0f, elevator1.MaxY), new Vector2(18.0f, 5.0f), Color.Purple, 5.0f, 0.0f);

            // Add elevator 1 to the list
            _elevators.Add(elevator1);

            // Elevator 2
            MovingPlatform elevator2 = new MovingPlatform();
            elevator2.MaxY = -5.0f;
            elevator2.MinY = -30.0f;
            elevator2.Speed = 10.0f;
            elevator2.PauseTime = 1.0f;
            elevator2.PauseCountdownTimer = 1.0f;
            elevator2.MovementState = PlatformState.Paused;
            elevator2.MovementNextState = PlatformState.Up;
            elevator2.Platform = CreateElevator(new Vector2(-64.0f, elevator2.MinY), new Vector2(18.0f, 5.0f), Color.Purple, 5.0f, 0.0f);

            // Add elevator 2 to the list
            _elevators.Add(elevator2);
        }

        /// <summary>
        /// Update each of the moving platforms in the given list
        /// </summary>
        /// <param name="time">The time this tick</param>
        /// <param name="platforms">The list of moving platforms to advance</param>
        private void UpdateMovingPlatforms(GameTime time, List<MovingPlatform> platforms)
        {
            // The amount of time that has passed this tick
            float elapsedTime = (float)time.ElapsedGameTime.TotalSeconds;

            // Go through the list of moving platforms and update them
            foreach (MovingPlatform platform in platforms)
            {
                if(platform.Platform != null)
                {
                    Body body = platform.Platform;
                    Vector2 pos = body.GetPosition();

                    if(platform.MovementState == PlatformState.Up)
                    {
                        if(pos.Y >= platform.MaxY)
                        {
                            body.SetLinearVelocity(new Vector2(0.0f, 0.0f));
                            platform.MovementState = PlatformState.Paused;
                            platform.MovementNextState = PlatformState.Down;
                            platform.PauseCountdownTimer = platform.PauseTime;

                            body.SetTransform(new Vector2(pos.X, platform.MaxY), body.GetAngle());
                        }
                    }
                    else if(platform.MovementState == PlatformState.Down)
                    {
                        if (pos.Y <= platform.MinY)
                        {
                            body.SetLinearVelocity(new Vector2(0.0f, 0.0f));
                            platform.MovementState = PlatformState.Paused;
                            platform.MovementNextState = PlatformState.Up;
                            platform.PauseCountdownTimer = platform.PauseTime;

                            body.SetTransform(new Vector2(pos.X, platform.MinY), body.GetAngle());
                        }
                    }
                    else if(platform.MovementState == PlatformState.Paused)
                    {
                        platform.PauseCountdownTimer -= elapsedTime;
                        if(platform.PauseCountdownTimer <= 0.0f)
                        {
                            platform.MovementState = platform.MovementNextState;
                            if (platform.MovementState == PlatformState.Up)
                            {
                                body.SetLinearVelocity(new Vector2(0.0f, platform.Speed));
                            }
                            else
                            {
                                body.SetLinearVelocity(new Vector2(0.0f, -platform.Speed));
                            }
                        }
                    }
                    else if(platform.MovementState == PlatformState.BeginUp)
                    {
                        body.SetLinearVelocity(new Vector2(0.0f, platform.Speed));
                        platform.MovementState = PlatformState.Up;
                    }
                    else if (platform.MovementState == PlatformState.BeginDown)
                    {
                        body.SetLinearVelocity(new Vector2(0.0f, -platform.Speed));
                        platform.MovementState = PlatformState.Down;
                    }
                }
            }
        }

        /// <summary>
        /// Check if the game is over.  This is based on the ball's position on the level to be above
        /// the green box.
        /// </summary>
        /// <returns></returns>
        private bool CheckGameOver()
        {
            if(_ball == null)
            {
                return false;
            }

            Vector2 pos = _ball.GetPosition();
            if(pos.X >= 56.25f && pos.X <= 67.5f && pos.Y >= -35.5f && pos.Y <= -25.0f)
            {
                return true;
            }

            return false;
        }
    }
}
