
using System.Diagnostics;
using Box2D.XNA;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

public class Platform
{
    // The paddle physics object
    private Body Paddle = null;

    private float _Acceleration = 1.0f;
    
    public float Acceleration
    {
        set { _Acceleration = value; }
    }

    /// <summary>
    /// Create the ground body
    /// </summary>
    public void CreatePlatform()
    {
        if (Paddle != null)//just one per game
            return; 

        Vector2[] verts = new Vector2[]
            {
                new Vector2(-100.0f, 3.0f),
                new Vector2(-100.0f, -3.0f),
                new Vector2(100.0f, -3.0f),
                new Vector2(100.0f, 3.0f),
            };

        Body bdy = GameDev.physics_variables.physics.CreateBox(new Vector2(0.0f, -30.0f), new Vector2(8.0f,2.0f), Color.DarkBlue, 10.0f, 0.3f, 0.0f);
        Filter filter = new Filter();
        bdy.GetFixtureList().GetFilterData(out filter);
        filter.categoryBits = 4;
        filter.maskBits = 7;
        bdy.GetFixtureList().SetFilterData(ref filter);
        bdy.SetFixedRotation(true);
        Paddle = bdy;
    }

    public void HandleInput()
    {
        if( Paddle != null )
        {
            float mass = Paddle.GetMass();
            Vector2 vel = Paddle.GetLinearVelocity();
            float speed = vel.Length();
            float assist = 1.0f;
            Vector2 impulse = new Vector2(mass * _Acceleration, 0.0f);

            //provides a bit of speed boost to assist the platform when things get heavier
            if (speed > 1.0f)
            {
                assist = MathUtils.Clamp(((30.0f - speed)/20.0f)+1.0f, 1.0f, 3f);
            }
            /*
            Debug.Write(magnifier + " \n");
            */
            if (Keyboard.GetState().IsKeyDown(Keys.Right))
            {
                if (vel.X < 0 && speed>5.0f)//put on some breaks when switching direction
                {
                    impulse.X *= speed / 10.0f;
                    //Debug.Write(assist + " breaks\n");
                }

                impulse *= assist;
               
                Paddle.ApplyLinearImpulse(impulse, Paddle.Position);
            }

            if (Keyboard.GetState().IsKeyDown(Keys.Left))
            {

                if (vel.X > 0 && speed > 5.0f)//put on some breaks when switching direction
                {
                    impulse.X *= speed / 10.0f;
                    //Debug.Write(assist + " breaks\n");
                }

                impulse *= assist;
                
                Paddle.ApplyLinearImpulse(-impulse, Paddle.Position);
            }

        }
    }
}