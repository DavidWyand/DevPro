using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System.Diagnostics;
using Box2D.XNA;

namespace GameDev
{

    class ShapeDropper
    {
        bool _StartDropper = false;
        float _StartTime = 0.0f;

        float _DropRate = 1.5f;
        bool _Winning = false;
        int _DropperSpread = 20;
        float _BoxScale = 5;
        int _NumStillBoxes = 1;
        float _Bounce = 0.0f;

        

        HashSet<Body> _Bodies = new HashSet<Body>();

        public ShapeDropper()
        {
            
        }

        public int NumStillBoxes
        {
            set { _NumStillBoxes = value; }
            get { return _NumStillBoxes; }
        }

        public bool Winning
        {
            get { return _Winning; }
        }

        public float Bouncyness
        {
            set { _Bounce = value; }
        }
       
        public float Gravity
        {
            set { GameDev.physics_variables.physics.SetGravity(value); }
        }

        public void StartDropper()
        {
            GameDev.physics_variables.physics.SetGravity(-32.0f);
            _StartDropper = true;
        }

        public float BoxSize
        {
            set { _BoxScale = value;}
        }

        public float DropRate
        {
            set {_DropRate = 1.0f/value;}
        }

        public int Variance
        {
            set { _DropperSpread = value; }
        }

        public float _SecondsToStart = 0.0f;
        public float _DropPace = 0.0f;
        public float _LightObject = 0.0f;
        public float _HeavyObject = 1.0f;

        public void Update( PhysicsAPI physics, GameTime time )
        {
            _Winning = false;

            List<Body> removelist = new List<Body>();
            foreach( Body body in _Bodies)
            {
                if( body.Position.Y<-33.0f )
                {
                    removelist.Add(body);
                }
            }//remove anyone below the base

            foreach( Body body in removelist )
            {
                _Bodies.Remove(body);
            }//now actually remove them

            int counter = 0;

            foreach (Body body in _Bodies)
            {
                if (body.GetLinearVelocity().Y < 0.1 && body.GetLinearVelocity().Y > -0.1)
                {
                    if (body.GetAngularVelocity() < 0.1)
                    {
                        counter++;
                    }
                }
            }

            if (counter >= NumStillBoxes)
            {
                _Winning = true;
            }


            if( _StartDropper )
            {
                if( _StartTime==0 )
                { 
                    _StartTime = (float)time.TotalGameTime.TotalMilliseconds;
                }

                if (time.TotalGameTime.TotalMilliseconds-_StartTime > _DropRate*1000 )
                {
                    _StartTime = time.TotalGameTime.Milliseconds;
                    Random rand = new Random();
                    int randI = rand.Next() % _DropperSpread;
                    randI -= _DropperSpread/2;
                    Body bdy = physics.CreateBox(new Vector2((float)randI, 40.0f), new Vector2(_BoxScale, _BoxScale*0.6f), Color.CornflowerBlue, 25.0f, 60.0f, _Bounce);
                    //bdy.SetAngularDamping(05.0f);
                    Filter filter = new Filter();
                    bdy.GetFixtureList().GetFilterData(out filter);
                    filter.categoryBits = 1;
                    filter.maskBits = 5;
                    bdy.GetFixtureList().SetFilterData(ref filter);
                    _StartTime = 0.0f;

                    _Bodies.Add(bdy);
                }

            }
        }

    }

}