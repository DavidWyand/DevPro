using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System.Diagnostics;
using Box2D.XNA;

namespace GameDev
{
    class physics_variables : Module
    {

        SpriteBatch _spriteBatch;

        static public PhysicsAPI physics = new PhysicsAPI();

        private KeyboardState _currentKeyboardState;

        //*********** Begin Focus Area 1 ***********//
        Platform _platform = null;
        ShapeDropper _shapeDropper = null;
        //*********** End Focus Area 1 ***********//


        SpriteFont _font;

        int _IntroTimer = 0;
        int _WinningCounter = 0;
        bool _GameWon = false;
        int _WinTime = 0;

        Texture2D test = null;
        
        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            this.clearColor = Color.WhiteSmoke;
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();

            _spriteBatch = new SpriteBatch(_graphicsDevice);

            _font = _contentManager.Load<SpriteFont>("Fonts\\Arial");
      
            physics.Init(new Vector2(0.0f, -30.0f), true, _graphicsDevice, _contentManager);

            // Build the ground
            Body bdy = CreateGround(new Vector2(0.0f, -39.0f), Color.WhiteSmoke);
  

            //*********** Begin Focus Area 2 ***********//
            // Create the moving platform

            // Start the shape dropper

            // Set platform properties

            // Set shape dropper properties
            //*********** End Focus Area 2 ***********//

        }

        /// <summary>
        /// Create the Paddle body
        /// </summary>
        private Body CreateGround(Vector2 position, Color color)
        {
            Vector2[] verts = new Vector2[]
            {
                new Vector2(-100.0f, 3.0f),
                new Vector2(-100.0f, -3.0f),
                new Vector2(100.0f, -3.0f),
                new Vector2(100.0f, 3.0f),
            };

            Body bdy =  physics.CreateStaticQuad(position, verts, color, 0.0f, 0.0f);
            Filter filter = new Filter();
            bdy.GetFixtureList().GetFilterData(out filter);
            filter.categoryBits = 2;
            filter.maskBits = 4;
            bdy.GetFixtureList().SetFilterData(ref filter);
            return bdy;
        }

       

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
 
            physics.Step();

            DoInput(time);

            if (_shapeDropper != null)
            {
                _shapeDropper.Update(physics, time);

                if (_shapeDropper.Winning)
                {
                    _WinningCounter += (int)time.ElapsedGameTime.TotalMilliseconds;

                    if (_WinningCounter > 1500 & !_GameWon)
                    {
                        _GameWon = true;
                        _WinTime = (int)time.TotalGameTime.TotalSeconds;
                    }

                }
                else
                {
                    _WinningCounter -= (int)time.ElapsedGameTime.TotalMilliseconds;
                    if (_WinningCounter < 0)
                        _WinningCounter = 0;
                }
            }

            if( _IntroTimer < 3000 )
            {
                _IntroTimer += (int)time.ElapsedGameTime.TotalMilliseconds;
            }
            
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {

            physics.Draw();

            _spriteBatch.Begin();


            int x = (_spriteBatch.GraphicsDevice.Viewport.Width / 2);
            int y = _spriteBatch.GraphicsDevice.Viewport.Height / 3;

            if( _IntroTimer <3000)
            {
                if (_shapeDropper != null)
                {
                    string text = "Use Arrows. Catch " + _shapeDropper.NumStillBoxes + " boxes";
                    Vector2 textSize = _font.MeasureString(text);
                    //_spriteBatch.DrawString(_font, text, new Vector2(x - textSize.X / 2, y - textSize.Y / 2), Color.BlueViolet);
                    _spriteBatch.DrawString(_font, text, new Vector2(x - textSize.X / 2, y - textSize.Y / 2), Color.BlueViolet);
                }
            }

            if (_GameWon)
            {
                string text = "You Won!\n It took "+_WinTime+" seconds";
                Vector2 textSize = _font.MeasureString(text);
                _spriteBatch.DrawString(_font, text, new Vector2(x - textSize.X / 2, y - textSize.Y / 2), Color.BlueViolet);
            }else
            if (_WinningCounter>0)
            {
                string text = "Hold it...hold it...";
                Vector2 textSize = _font.MeasureString(text);
                _spriteBatch.DrawString(_font, text, new Vector2(x - textSize.X / 2, y - textSize.Y / 2), Color.BlueViolet);
            }
            
            
            _spriteBatch.End();

            
        }

        /// <summary>
        /// Process keyboard input
        /// </summary>
        private void DoInput(GameTime time)
        {
            
            _currentKeyboardState = Keyboard.GetState();

            if(_platform!=null)
            {
                _platform.HandleInput();
            }
        }


    }
}
