using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System.Diagnostics;
using Box2D.XNA;

namespace GameDev
{
    class physics_variables : Module
    {
        private SpriteBatch _spriteBatch;

        private SpriteFont _font;

        private float TextY = 680.0f;
        private string CannonHelpText = "LEFT ARROW and RIGHT ARROW to rotate. SPACE to fire.";
        private string TargetHelpText = "Knock down target";

        PhysicsAPI physics = new PhysicsAPI();

        private KeyboardState CurrentKeyboardState;
        private KeyboardState OldKeyboardState;

        // Outside these limits cannon balls are destroyed
        private Vector2 WorldLimits = new Vector2(80.0f, 500.0f);

        #region Cannon

        // The physics body of the cannon
        private Body CannonBody = null;

        // The scale of the cannon
        private float CannonScale = 6.0f;

        // The position of the cannon on the screen
        private Vector2 CannonPosition = new Vector2(-60.0f, -26.0f);

        // The current rotation angle of the cannon
        private float CannonAngle = 0.0f;

        // The color of the cannon while waiting to become ready
        private Color CannonWaitColor = new Color(0.2f, 0.2f, 0.2f);

        // The color of the cannon when ready to fire
        private Color CannonReadyColor = new Color(0.2f, 0.7f, 0.2f);

        // The time it takes for the cannon to become ready to fire
        private float CannonReadyTime = 2.0f;

        // The current coutdown time until the cannon becomes ready to fire
        private float CannonReadyCountdownTimer;

        // Indicates if the cannon is ready
        private bool CannonReady;

        #endregion

        #region Cannon Balls

        // List of cannon ball physics bodies on screen
        private List<Body> CannonBalls = new List<Body>();

        // The size of a cannon ball
        private float CanoonBallSize = 1.5f;

        // The color of a cannon ball
        private Color CannonBallColor = new Color(0.1f, 0.1f, 0.1f);

        //*********** Begin Focus Area 5 ***********//

        // The amount of impulse force applied to a cannon ball when fired
        private float CannonBallImpulse = 300.0f;

        //*********** End Focus Area 5 ***********//


        #endregion

        #region Ground

        // The ground physics object
        private Body Ground = null;

        // The color of the ground
        private Color GroundColor = new Color(0.1f, 0.3f, 0.1f);

        #endregion

        #region Barriers

        // The first barrier physics body
        private Body Barrier1 = null;

        // The second barrier physics body
        private Body Barrier2 = null;

        // The first barrier's x position
        private float Barrier1X = 40.0f;

        // The second battier's x position
        private float Barrier2X = 30.0f;

        // Indicates if the first barrier is currently moving up
        private bool Barrier1MovingUp = true;

        // Indicates if the second barrier is currently moving up
        private bool Barrier2MovingUp = false;

        // The minimum y position a barrier should move
        private float BarrierMinY = -20.0f;

        // The maximum y position a barrier should move
        private float BarrierMaxY = 10.0f;

        // The speed of the moving barriers
        private float BarrierSpeed = 15.0f;

        // The color of the barriers
        private Color BarrierColor = new Color(0.8f, 0.2f, 0.2f);

        #endregion

        #region Target

        // The target physics body
        private Body Target = null;

        //*********** Begin Focus Area 2 ***********//

        // The target's position


        //*********** End Focus Area 2 ***********//


        //*********** Begin Focus Area 3 ***********//

        // The target's size


        //*********** End Focus Area 3 ***********//


        // The target's color
        private Color TargetColor = new Color(0.7f, 0.7f, 0.2f);

        #endregion
        
        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();

            _spriteBatch = new SpriteBatch(_graphicsDevice);

            _font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");

            physics.Init(new Vector2(0.0f, -30.0f), true, _graphicsDevice, _contentManager);

            // Prepare the cannon
            CannonBody = CreateCannon(CannonPosition, CannonScale, CannonWaitColor);
            CannonReadyCountdownTimer = CannonReadyTime;
            CannonReady = false;

            // Prepare the ground
            Ground = CreateGround(new Vector2(0.0f, -39.0f), GroundColor);

            // Prepare the barriers
            Barrier1 = CreateBarrier(new Vector2(Barrier1X, BarrierMinY), BarrierColor);
            Barrier2 = CreateBarrier(new Vector2(Barrier2X, BarrierMaxY), BarrierColor);

            //*********** Begin Focus Area 4 ***********//

            // Prepare the target


            //*********** End Focus Area 4 ***********//

        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            physics.Step();

            UpdateCannon(time);

            UpdateCannonBalls(time);

            UpdateBarriers(time);

            DoInput(time);
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            physics.Draw();

            _spriteBatch.Begin();
            Vector2 pos = new Vector2(5.0f, TextY);
            _spriteBatch.DrawString(_font, CannonHelpText, pos, Color.White);
            pos.X = 1080.0f;
            _spriteBatch.DrawString(_font, TargetHelpText, pos, Color.White);
            _spriteBatch.End();
        }

        /// <summary>
        /// Process keyboard input
        /// </summary>
        private void DoInput(GameTime time)
        {
            CurrentKeyboardState = Keyboard.GetState();

            // Rotate cannon left
            if (CurrentKeyboardState.IsKeyDown(Keys.Left))
            {
                if (CannonBody != null)
                {
                    CannonAngle += 3.14f * 0.5f * (float)time.ElapsedGameTime.TotalSeconds;
                    if(CannonAngle > 1.5f)
                    {
                        CannonAngle = 1.5f;
                    }
                    CannonBody.SetTransform(CannonPosition, CannonAngle);
                }
            }

            // Rotate cannon right
            if (CurrentKeyboardState.IsKeyDown(Keys.Right))
            {
                if (CannonBody != null)
                {
                    CannonAngle -= 3.14f * 0.5f * (float)time.ElapsedGameTime.TotalSeconds;
                    if(CannonAngle < -0.785f)
                    {
                        CannonAngle = -0.785f;
                    }
                    CannonBody.SetTransform(CannonPosition, CannonAngle);
                }
            }

            // Fire cannon ball
            if (CurrentKeyboardState.IsKeyDown(Keys.Space))
            {
                if (CannonReady)
                {
                    // Place the cannon ball in front of the cannon
                    Vector3 cannonFrontPosition = new Vector3(1.5f * CannonScale + CanoonBallSize, 0.0f, 0.0f);
                    Matrix ballMatrix = Matrix.CreateTranslation(cannonFrontPosition) * Matrix.CreateRotationZ(CannonAngle) * Matrix.CreateTranslation(new Vector3(CannonPosition.X, CannonPosition.Y, 0.0f));
                    Vector3 ballLaunchPosition = ballMatrix.Translation;

                    Body cannonBall = CreateCannonBall(new Vector2(ballLaunchPosition.X, ballLaunchPosition.Y), CanoonBallSize, CannonBallColor);
                    CannonBalls.Add(cannonBall);

                    Matrix impulseMatrix = Matrix.CreateTranslation(new Vector3(1.0f, 0.0f, 0.0f)) * Matrix.CreateRotationZ(CannonAngle);
                    Vector3 impulseDirection = impulseMatrix.Translation;
                    Vector2 impulseDir = new Vector2(impulseDirection.X, impulseDirection.Y);
                    impulseDir.Normalize();

                    physics.ApplyImpulse(cannonBall, impulseDir, CannonBallImpulse);

                    // Set the cannon to no longer be ready
                    CannonReady = false;
                    CannonReadyCountdownTimer = CannonReadyTime;
                    UpdateCannonColor(1.0f);
                }
            }

            OldKeyboardState = CurrentKeyboardState;
        }

        /// <summary>
        /// Create the cannon body
        /// </summary>
        private Body CreateCannon(Vector2 position, float scale, Color color)
        {
            BodyDef cannonBodyDef = new BodyDef();
            cannonBodyDef.position = position;
            Body cannonBody = physics.B2DWorld.CreateBody(cannonBodyDef);
            cannonBody.DebugColor = color;
            PolygonShape cannonShape = new PolygonShape();

            Vector2[] verts = new Vector2[]
            {
                new Vector2(1.5f * scale, 0.38f * scale),
                new Vector2(0.0f * scale, 0.5f * scale),
                new Vector2(-0.29f * scale, 0.41f * scale),
                new Vector2(-0.48f * scale, 0.15f * scale),
                new Vector2(-0.48f * scale, -0.15f * scale),
                new Vector2(-0.29f * scale, -0.41f * scale),
                new Vector2(0.0f * scale, -0.5f * scale),
                new Vector2(1.5f * scale, -0.38f * scale),
            };

            cannonShape.Set(verts, 8);
            cannonShape._centroid = Vector2.Zero;

            // shape.SetAsBox(new Vector2(-100.0f, 195.0f), new Vector2(100.0f, 195.0f));
            cannonBody.CreateFixture(cannonShape, 0.0f);
            return cannonBody;
        }

        /// <summary>
        /// Update the cannon each tick
        /// </summary>
        private void UpdateCannon(GameTime time)
        {
            // Update the cannon's readiness
            if (CannonReadyCountdownTimer > 0.0f)
            {
                //*********** Begin Focus Area 1 ***********//

                CannonReadyCountdownTimer -= time.ElapsedGameTime.TotalSeconds;

                //*********** End Focus Area 1 ***********//


                if (CannonReadyCountdownTimer <= 0.0f)
                {
                    UpdateCannonColor(0.0f);
                    CannonReady = true;
                }
                else
                {
                    float blend = CannonReadyCountdownTimer / CannonReadyTime;
                    UpdateCannonColor(blend);
                }
            }
        }
        
        /// <summary>
        /// Update the cannon's color to indicate its readiness
        /// </summary>
        /// <param name="blend">goes from 0.0f (for full ready color) to 1.0f (for full wait color)</param>
        private void UpdateCannonColor(float blend)
        {
            Vector3 color1 = CannonReadyColor.ToVector3();
            Vector3 color2 = CannonWaitColor.ToVector3();
            CannonBody.DebugColor = new Color((1.0f - blend) * color1.X + blend * color2.X,
                                              (1.0f - blend) * color1.Y + blend * color2.Y,
                                              (1.0f - blend) * color1.Z + blend * color2.Z);
        }

        /// <summary>
        /// Create the cannon ball body
        /// </summary>
        private Body CreateCannonBall(Vector2 position, float radius, Color color)
        {
            BodyDef circleBodyDef = new BodyDef();
            circleBodyDef.position = position;
            circleBodyDef.type = BodyType.Dynamic;

            Body circleBody = physics.B2DWorld.CreateBody(circleBodyDef);
            circleBody.DebugColor = color;
            circleBody.ResetMassData();

            CircleShape circleShape = new CircleShape();
            circleShape._radius = radius;

            FixtureDef circleFixtureDef = new FixtureDef();
            circleFixtureDef.shape = circleShape;
            circleFixtureDef.density = 1.0f;
            circleFixtureDef.restitution = 0.5f;

            circleBody.CreateFixture(circleFixtureDef);
            circleBody.ResetMassData();

            return circleBody;
        }

        /// <summary>
        /// Update the cannon balls each tick
        /// </summary>
        private void UpdateCannonBalls(GameTime time)
        {
            // Destroy all cannon balls that go outside the world
            int i = 0;
            while (i<CannonBalls.Count)
            {
                Vector2 pos = CannonBalls[i].GetPosition();
                if (pos.X > WorldLimits.X || pos.X < -WorldLimits.X || pos.Y > WorldLimits.Y || pos.Y < -WorldLimits.Y)
                {
                    Body ball = CannonBalls[i];
                    CannonBalls.RemoveAt(i);
                    physics.B2DWorld.DestroyBody(ball);
                }
                else
                {
                    ++i;
                }
            }
        }

        /// <summary>
        /// Create the ground body
        /// </summary>
        private Body CreateGround(Vector2 position, Color color)
        {
            Vector2[] verts = new Vector2[]
            {
                new Vector2(-80.0f, 3.0f),
                new Vector2(-80.0f, -3.0f),
                new Vector2(80.0f, -3.0f),
                new Vector2(80.0f, 3.0f),
            };

            return physics.CreateStaticQuad(position, verts, color);
        }

        /// <summary>
        /// Create a barrier body
        /// </summary>
        private Body CreateBarrier(Vector2 position, Color color)
        {
            Vector2[] verts = new Vector2[]
            {
                new Vector2(-3.0f, 8.0f),
                new Vector2(-3.0f, -8.0f),
                new Vector2(3.0f, -8.0f),
                new Vector2(3.0f, 8.0f),
            };

            return physics.CreateStaticQuad(position, verts, color);
        }

        /// <summary>
        /// Update the barriers each tick
        /// </summary>
        private void UpdateBarriers(GameTime time)
        {
            // Move barrier 1
            if(Barrier1MovingUp)
            {
                Vector2 pos = Barrier1.GetPosition();
                pos.Y += BarrierSpeed * (float)time.ElapsedGameTime.TotalSeconds;
                if(pos.Y > BarrierMaxY)
                {
                    pos.Y = BarrierMaxY;
                    Barrier1MovingUp = false;
                }

                Barrier1.SetTransform(pos, Barrier1.GetAngle());
            }
            else
            {
                Vector2 pos = Barrier1.GetPosition();
                pos.Y -= BarrierSpeed * (float)time.ElapsedGameTime.TotalSeconds;
                if (pos.Y < BarrierMinY)
                {
                    pos.Y = BarrierMinY;
                    Barrier1MovingUp = true;
                }

                Barrier1.SetTransform(pos, Barrier1.GetAngle());
            }

            // Move barrier 2
            if (Barrier2MovingUp)
            {
                Vector2 pos = Barrier2.GetPosition();
                pos.Y += BarrierSpeed * (float)time.ElapsedGameTime.TotalSeconds;
                if (pos.Y > BarrierMaxY)
                {
                    pos.Y = BarrierMaxY;
                    Barrier2MovingUp = false;
                }

                Barrier2.SetTransform(pos, Barrier2.GetAngle());
            }
            else
            {
                Vector2 pos = Barrier2.GetPosition();
                pos.Y -= BarrierSpeed * (float)time.ElapsedGameTime.TotalSeconds;
                if (pos.Y < BarrierMinY)
                {
                    pos.Y = BarrierMinY;
                    Barrier2MovingUp = true;
                }

                Barrier2.SetTransform(pos, Barrier2.GetAngle());
            }
        }

        /// <summary>
        /// Create a target body
        /// </summary>
        private Body CreateTarget(float positionX, float positionY, float scale, Color color)
        {
            Vector2 position = new Vector2(positionX, positionY);

            Body target = physics.CreateHexagon(position, scale, color);
            target.SetTransform(position, 1.57f);

            // Setting the target to sleep from the start allows is to sit on the screen
            // until it is hit by the cannon ball
            target.SetAwake(false);

            return target;
        }
    }
}
