using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Timers;
using System.Diagnostics;
using Box2D.XNA;

namespace GameDev
{
    #region Box2D Contact Listener
    // A class to detect when Box2D collisions happen
    public class MyContactListener : IContactListener
    {
        public void BeginContact(Contact contact) 
        {
            Fixture f1 = contact.GetFixtureA();
            Fixture f2 = contact.GetFixtureB();
            string s1 = (string)f1.GetBody().GetUserData();
            string s2 = (string)f2.GetBody().GetUserData();
            
            if (s2 == "circle" && s1 == "ground")
            {
                physics_vs_primer.OnCircleToGround(contact);
            }
        }
        public void EndContact(Contact contact) { }
        public void PreSolve(Contact contact, ref Manifold oldManifold) { }
        public void PostSolve(Contact contact, ref ContactImpulse impulse) { }
    }
    #endregion

    class physics_vs_primer : Module
    {


        //*********** Begin Focus Area 1 ***********//
        // A Callback function that gets called whenever a circle touches the ground
        public static void OnCircleToGround(Contact contact)
        {
            ShowMessage = true;
            if (FailMessage == "")
            {
                FailMessage = "Oh no! A circle touched the ground...try again!";
            }
        }
        //*********** End Focus Area 1 ***********//


        #region Private Variables
        // The physicsAPI Object
        private PhysicsAPI physics = new PhysicsAPI();
        // For rendering sprites and fonts
        private SpriteBatch _spriteBatch;
        // The font object
        private SpriteFont _font;
        #endregion

        #region Static Variables
        // A message to let the user know that they've failed the test case
        private static string FailMessage = "";
        // Whether or not to show that message
        private static bool ShowMessage = false;
        #endregion

        #region Overrides

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            // Call the parent version
            base.LoadContent();
            // Lets initialize this SpriteBatch, so we can use it later
            _spriteBatch = new SpriteBatch(_graphicsDevice);
            // Load up the font resource
            _font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");
            // Init the module logic
            Init();
            
        }
        
        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            physics.Step();
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            physics.Draw();
            _spriteBatch.Begin();
            if (ShowMessage)
            {
                _spriteBatch.DrawString(_font, FailMessage, new Vector2(_graphicsDevice.Viewport.Width * 0.5f - FailMessage.Length * 5.0f, _graphicsDevice.Viewport.Height * 0.5f), Color.DarkRed);
            }
            _spriteBatch.DrawString(_font, "Try and keep the balls from touching the ground by building a stronger structure", new Vector2(0.0f, 0.0f), Color.White);
            _spriteBatch.End();
        }

        #endregion

        //*********** Begin Focus Area 2 ***********//
        // Creates the Physics world, a ground, and also calls external functions CreateStructure and SpawnCircles
        private void Init()
        {
            physics.Init(new Vector2(0.0f, -30.0f), true, _graphicsDevice, _contentManager);
            physics.B2DWorld.ContactListener = new MyContactListener();
            physics.CreateGround(12, 24.0f, -11.0f, 2.0f, 2.0f, false);

            CreateStructure();

            SpawnCircles();
        }
        //*********** End Focus Area 2 ***********//

       
        // This is a simple function that spawns circles
        private void SpawnCircles()
        {
            float largeBall = 4.0f;
            float medBall = 2.5f;
            float smallBall = 1.5f;
            physics.CreateCircle(10.0f, 34.0f, medBall, Color.Red);
            physics.CreateCircle(-3.0f, 8.0f, smallBall, Color.Green);
            physics.CreateCircle(-5.0f, 16.0f, largeBall, Color.Yellow);
            physics.CreateCircle(3.0f, 32.0f, medBall, Color.Blue);
            physics.CreateCircle(-9.0f, 3.0f, smallBall, Color.Green);
            physics.CreateCircle(5.0f, 32.0f, medBall, Color.Blue);
          
        }
        // Creates a structure to prevent the circles from touching the ground
        private void CreateStructure()
        {
            //*********** Begin Focus Area 3***********//
            physics.CreateBox(0.0f, -30.0f, 2.0f, 8.0f, Color.Black);
            physics.CreateBox(0.0f, -25.0f, 24.0f, 1.0f, Color.White);
            //*********** End Focus Area 3 ***********//


        }
    }
}
