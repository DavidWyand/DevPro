using GameDev;
using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;

namespace GameDev
{
    class player_controller : Module
    {
        private Sprite _background;

        private Sprite _shipA;
        private Sprite _shipB;
        private Sprite _shipC;
        private SpriteTexture _shipTextureA;
        private SpriteTexture _shipTextureB;
        private SpriteTexture _shipTextureC;

        private SpriteManager _spriteManager;
        
        private Vector2 _shipAVelocity;
        private Vector2 _shipBVelocity;
        private Vector2 _shipCVelocity;

        private float _shipASpeed = 200f;
        private float _shipBSpeed = 200f;
        private float _shipCSpeed = 200f;

        private float _shipBHeading = 0f;
        private float _shipCHeading = 0f;        

        private KeyboardState _oldKeyboardState;
        private MouseState _oldMouseState;

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            _background = new Sprite(0);
            _shipA = new Sprite(1);
            _shipB = new Sprite(2);
            _shipC = new Sprite(3);

            _shipAVelocity = new Vector2(0, 0);
            _shipBVelocity = new Vector2(0, 0);
            _shipCVelocity = new Vector2(0, 0);
            
            _spriteManager = new SpriteManager();
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {

            OrthoCamera cam = new OrthoCamera();
            cam.Bounds = _graphicsDevice.Viewport.Bounds;
            DefaultCamera = cam;

            _graphicsDevice.BlendState = BlendState.AlphaBlend;            

            //Load the background
            SpriteTexture backgroundTexture = new SpriteTexture("Graphics\\SpaceBackground");
            backgroundTexture.LoadContent(_contentManager);
            _background.SetSpriteTexture(backgroundTexture);
            _background.SetSize(backgroundTexture.ImageWidth, backgroundTexture.ImageHeight);
            _background.SetFlipVertical(true);
            _background.SetPosition(_graphicsDevice.Viewport.Bounds.Width / 2, _graphicsDevice.Viewport.Bounds.Height / 2);
            _spriteManager.AddSprite(_background);

            
            _shipTextureA = new SpriteTexture("Graphics\\ShipA");
            _shipTextureA.LoadContent(_contentManager);
            _shipA.SetSpriteTexture(_shipTextureA);
            _shipA.SetSize(_shipTextureA.ImageWidth, _shipTextureA.ImageHeight);
            _shipA.SetFlipVertical(true);
            _shipA.SetPosition((_graphicsDevice.Viewport.Bounds.Width / 2) - 200f, _graphicsDevice.Viewport.Bounds.Height / 2);
            _spriteManager.AddSprite(_shipA);

            _shipTextureB = new SpriteTexture("Graphics\\ShipB");
            _shipTextureB.LoadContent(_contentManager);
            _shipB.SetSpriteTexture(_shipTextureB);
            _shipB.SetSize(_shipTextureB.ImageWidth, _shipTextureB.ImageHeight);
            _shipB.SetFlipVertical(true);
            _shipB.SetPosition(_graphicsDevice.Viewport.Bounds.Width / 2, _graphicsDevice.Viewport.Bounds.Height / 2);
            _spriteManager.AddSprite(_shipB);

            _shipTextureC = new SpriteTexture("Graphics\\ShipC");
            _shipTextureC.LoadContent(_contentManager);            
            _shipC.SetSpriteTexture(_shipTextureC);
            _shipC.SetSize(_shipTextureC.ImageWidth, _shipTextureC.ImageHeight);
            _shipC.SetFlipVertical(true);
            _shipC.SetPosition((_graphicsDevice.Viewport.Bounds.Width / 2) + 200f, _graphicsDevice.Viewport.Bounds.Height / 2);
            _spriteManager.AddSprite(_shipC);
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            _shipA.SetPosition(_shipA.Position.X + _shipAVelocity.X * deltaSeconds, _shipA.Position.Y + _shipAVelocity.Y * deltaSeconds);            

            _shipB.SetPosition(_shipB.Position.X + _shipBVelocity.X * deltaSeconds, _shipB.Position.Y + _shipBVelocity.Y * deltaSeconds);
            _shipB.SetRotation(_shipBHeading);

            _shipC.SetPosition(_shipC.Position.X + _shipCVelocity.X * deltaSeconds, _shipC.Position.Y + _shipCVelocity.Y * deltaSeconds);
            _shipC.SetRotation(_shipCHeading);
        }

        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {
            //*********** Begin Focus Area 1 ***********//

            //*********** End Focus Area 1 ***********//


            //*********** Begin Focus Area 2 ***********//

            //*********** End Focus Area 2 ***********//


            //*********** Begin Focus Area 3 ***********//

            //*********** End Focus Area 3 ***********//

          

            _oldKeyboardState = keyboardState;
            _oldMouseState = mouseState;
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);
        }
        

    }
}
