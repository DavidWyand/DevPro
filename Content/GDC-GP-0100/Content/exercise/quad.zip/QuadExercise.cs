using GameDev.Utilities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class QuadExercise : Module
    {
        // Upper left coordinate for quad
        private Vector3 _upperLeft;

        // Lower left coordinate for quad
        private Vector3 _lowerLeft;

        // Upper right coordinate for quad
        private Vector3 _upperRight;

        // Lower right coordinate for quad
        private Vector3 _lowerRight;

        // Quad vertices and indices
        private VertexPositionColor[] _vertices;
        private short[] _indices = new short[6];

        // Basic XNA effect used in the render pass
        private BasicEffect _basicEffect;

        // Width of quad
        private float _width = 5f;

        // Height of quad
        private float _height = 5f;

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            _graphicsDevice.BlendState = BlendState.AlphaBlend;

            // Build the basic effect
            _basicEffect = new BasicEffect(_graphicsDevice);
            _basicEffect.VertexColorEnabled = true;


            // Set the index buffer for each vertex, using clockwise winding
            _indices[0] = 0;
            _indices[1] = 1;
            _indices[2] = 2;
            _indices[3] = 2;
            _indices[4] = 1;
            _indices[5] = 3;

            //*********** Begin Focus Area 1 ***********//
            
            // Calculate the half width and half height of the quad
            float halfWidth = 0.0f;
            float halfHeight = 0.0f;

            //*********** End Focus Area 1 ***********//


            //*********** Begin Focus Area 2 ***********//
            
            // Calculate the quad corners
            
            //*********** End Focus Area 2 ***********//


            //*********** Begin Focus Area 3 ***********//
            
            // Allocate memory for the vertices

            //*********** End Focus Area 3 ***********//


            //*********** Begin Focus Area 4 ***********//
            
            // Set the color and position of the vertices     
            
            //*********** End Focus Area 4 ***********//

        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            //*********** Begin Focus Area 5 ***********//
            
            //DrawIndexedPrimitive(_vertices, _indices, _basicEffect);
            
            //*********** End Focus Area 5 ***********//

        }        
    }
}
