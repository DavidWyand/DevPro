using GameDev.Utilities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System;

namespace GameDev.RotationExercise
{
    class RotationExercise : Module
    {
//*********** Begin Focus Area 1 **************// 

        // Background sprite properties
        private Quad _backgroundQuad;
        private Texture2D _backgroundTexture;
        private Matrix _backgroundTransform;

        // Corona sprite properties
        private Texture2D _coronaSprite;
        private Quad _coronaQuad;
        private Matrix _coronaTransform;
        private Vector3 _coronaDistance = new Vector3(0, 0, 0);
        private float _coronaRotation = 0f;

        // Mars sprite properties
        private Texture2D _marsSprite;
        private Quad _marsQuad;
        private float _marsRotation = 0f;
        private Matrix _marsTransform;
        private Vector3 _marsDistance = new Vector3(15.0f, 0, 0);

        // Astronaut sprite properties
        private Texture2D _astronautSprite;
        private Quad _astronautQuad;
        private float _astronautRotation = 0f;
        private Matrix _astronautTransform;
        private Vector3 _astronautDistance = new Vector3(7.0f, 0, 0);

        // 3D Sun properties
        private Model _sunModel;
        private Matrix _sunTransform;
        private float _sunRotation = 0.0f;

        // 3D Earth properties
        private Model _earthModel;
        private Matrix _earthTransform;
        private Vector3 _earthDistance = new Vector3(15, 0, 0);
        private float _earthRotation = 0.0f;
        private float _rotationAroundSun = 0.0f;
        
//*********** End Focus Area 1 **************// 

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            _exerciseRenderMode = RenderMode.RenderBoth;

            _backgroundQuad = new Quad(new Vector3(0.0f, 0.0f, 0.0f), 100.0f, 56.0f);
            _coronaQuad = new Quad(new Vector3(0, 0, 0), 23.0f, 23.0f);
            _marsQuad = new Quad(new Vector3(0, 0, 0), 5.0f, 5.0f);
            _astronautQuad = new Quad(new Vector3(0, 0, 0), 2.6f, 3.4f);
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();

            _backgroundTexture = _contentManager.Load<Texture2D>("Graphics\\Space_Background");
            _backgroundQuad.SetTexture(_backgroundTexture);

            _coronaSprite = _contentManager.Load<Texture2D>("Graphics\\Solor_Corona");
            _coronaQuad.SetTexture(_coronaSprite);

            _marsSprite = _contentManager.Load<Texture2D>("Graphics\\Mars");
            _marsQuad.SetTexture(_marsSprite);

            _astronautSprite = _contentManager.Load<Texture2D>("Graphics\\astronaut");
            _astronautQuad.SetTexture(_astronautSprite);

            _earthModel = _contentManager.Load<Model>("Graphics\\Earth");
            _sunModel = _contentManager.Load<Model>("Graphics\\Sun");
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            _backgroundTransform = Matrix.CreateTranslation(new Vector3(0, 0, -15.0f));

            //*********** Begin Focus Area 2 ***********//

            // Calculate 2D object rotation values
            _coronaRotation += deltaSeconds + 0.01f;
            _astronautRotation += deltaSeconds + 0.02f;
            _marsRotation += deltaSeconds + 0.001f;

            // Calculate 3D object rotation values
            _sunRotation += deltaSeconds + 0.02f;
            _rotationAroundSun += deltaSeconds + 0.01f;
            _earthRotation += deltaSeconds + 0.01f;            

            //*********** End Focus Area 2 ***********//


            //*********** Begin Focus Area 3 ***********//

            // Corona manipulation            
            _coronaTransform = Matrix.CreateTranslation(_coronaDistance);

            //*********** End Focus Area 3 ***********//


            //*********** Begin Focus Area 4 ***********//

            // Mars manipulation
            Vector3 marsPosition = _coronaTransform.Translation + _marsDistance;
            _marsTransform = Matrix.CreateTranslation(marsPosition);
            
            //*********** End Focus Area 4 ***********//


            //*********** Begin Focus Area 5 ***********//

            // Sun manipulation
            _sunTransform = Matrix.CreateTranslation(Vector3.Zero);

            //*********** End Focus Area 5 ***********//


            //*********** Begin Focus Area 6 ***********//

            // Earth manipulation
            Vector3 earthPosition = _sunTransform.Translation + _earthDistance;
            _earthTransform = Matrix.CreateTranslation(earthPosition);

            //*********** End Focus Area 6 ***********//


            //*********** Begin Focus Area 7 ***********//

            // Astronaut manipulation
            Vector3 astronautPosition = _earthTransform.Translation + _astronautDistance;
            _astronautTransform = Matrix.CreateTranslation(astronautPosition);

            //*********** End Focus Area 7 ***********//
          
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            // Render 3D models
            if (_exerciseRenderMode == RenderMode.Render3D || _exerciseRenderMode == RenderMode.RenderBoth)
            {
                // Draw the Sun
                DrawModel(_sunModel, _sunTransform);

                // Draw the Earth
                DrawModel(_earthModel, _earthTransform);
            }

            // Render 2D sprites
            if (_exerciseRenderMode == RenderMode.Render2D || _exerciseRenderMode == RenderMode.RenderBoth)
            {
                // Draw the space backgroun
                DrawTexturedQuad(_backgroundQuad, _backgroundTransform);

                // Change the draw order depending on which quad is closer to the camera as
                // we need to take into account their transparent textures.  Mars and the sun's
                // corona are at the same Z position, so we only need to test against one of them.
                if (_astronautTransform.Translation.Z < _coronaTransform.Translation.Z)
                {
                    // Draw the astronaut orbiting the planet sprite
                    DrawTexturedQuad(_astronautQuad, _astronautTransform);

                    // Draw the corona sprite
                    DrawTexturedQuad(_coronaQuad, _coronaTransform);

                    // Draw the mars sprite
                    DrawTexturedQuad(_marsQuad, _marsTransform);
                }
                else
                {
                    // Draw the corona sprite
                    DrawTexturedQuad(_coronaQuad, _coronaTransform);

                    // Draw the mars sprite
                    DrawTexturedQuad(_marsQuad, _marsTransform);

                    // Draw the astronaut orbiting the planet sprite
                    DrawTexturedQuad(_astronautQuad, _astronautTransform);
                }
            }
        }
    }
}
