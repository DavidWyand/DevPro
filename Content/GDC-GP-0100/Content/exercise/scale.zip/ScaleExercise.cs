using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev
{
    class ScaleExercise : Module
    {
        // The left quad to render
        private Quad _leftQuad;
        private Texture2D _leftTexture;

        // The left quad's transform matrix
        private Matrix _leftQuadTransform;

        // The middle quad to render
        private Quad _middleQuad;
        private Texture2D _middleTexture;

        // The middle quad's transform matrix
        private Matrix _middleQuadTransform;

        // The right quad to render
        private Quad _rightQuad;
        private Texture2D _rightTexture;

        // The current scale of the right quad
        private float _rightQuadScale;

        // The amount to scale the right quad each second
        private float _rightQuadScalePerSecond;

        // Matrix to hold the final transform for the quad
        private Matrix _rightQuadTransform;

        // Matrix to hold the translation of the right quad
        private Matrix _rightQuadTranslation;

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            //*********** Begin Focus Area 1 ***********//

            // Build the left quad
            _leftQuad = new Quad(new Vector3(0, 0, 0), 4.0f, 4.0f);
            _leftQuadTransform = Matrix.Identity;
            _leftQuadTransform *= Matrix.CreateTranslation(new Vector3(-15.0f, 0.0f, 0.0f));

            //*********** End Focus Area 1 ***********//

          
            // Build the middle quad
            _middleQuad = new Quad(new Vector3(0, 0, 0), 4.0f, 4.0f);
            _middleQuadTransform = Matrix.Identity;

            // Build the right quad
            _rightQuad = new Quad(new Vector3(0, 0, 0), 4.0f, 4.0f);
            _rightQuadTranslation = Matrix.CreateTranslation(new Vector3(15.0f, 0.0f, 0.0f));

            // Initialize the vector that holds the starting position of the rendered quad
            _rightQuadScale = 1.0f;

            // Initialize the vector that holds the amount to offset the rendered quad every step
            _rightQuadScalePerSecond = 2.0f;
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            _graphicsDevice.BlendState = BlendState.AlphaBlend;

            // Load in the texture used for the left quad
            _leftTexture = _contentManager.Load<Texture2D>("Graphics\\football");
            _leftQuad.SetTexture(_leftTexture);

            // Load in the texture used for the middle quad
            _middleTexture = _contentManager.Load<Texture2D>("Graphics\\football");
            _middleQuad.SetTexture(_middleTexture);

            // Load in the texture used for the right quad
            _rightTexture = _contentManager.Load<Texture2D>("Graphics\\football");
            _rightQuad.SetTexture(_rightTexture);
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            // Offset the rendered quad's position
            _rightQuadScale += _rightQuadScalePerSecond * deltaSeconds;

            // If the right quad's scale becomes too large, reverse the direction of
            // the scale
            if (_rightQuadScale > 4.0f)
            {
                _rightQuadScale = 4.0f;
                _rightQuadScalePerSecond *= -1.0f;
            }

            // If the right quad's scale becomes too small, reverse the direction of
            // the scale
            if (_rightQuadScale < 0.25f)
            {
                _rightQuadScale = 0.25f;
                _rightQuadScalePerSecond *= -1.0f;
            }

            //*********** Begin Focus Area 2 ***********//
            
            // Create the quad's transform matrix
            _rightQuadTransform = Matrix.Identity;
            _rightQuadTransform *= _rightQuadTranslation;

            //*********** End Focus Area 2 ***********//

        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            // Render the quads
            DrawTexturedQuad(_leftQuad, _leftQuadTransform);
            DrawTexturedQuad(_middleQuad, _middleQuadTransform);
            DrawTexturedQuad(_rightQuad, _rightQuadTransform);
        }
    }
}
