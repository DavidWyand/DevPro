using GameDev;
using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class SelectionStatementsExercise : Module
    {
        // sprite manager used to render our sprite
        private SpriteManager _spriteManager = new SpriteManager();

        //sprite and sprite texture for our ship
        private Sprite _ship = new Sprite();
        private SpriteTexture _shipTexture = new SpriteTexture("Graphics\\enemyShip1");

        //ship speed and direction
        private float _shipSpeed;
        private float _shipDirection;

        // bounds the patrol action and the engage action
        private float _patrolArea;
        private float _warpArea;

        // Current Enemy Ship Action
        private string _currentAction = "";

        // keyboardstate for storing the previous keyboard state to only perform actions once per key press
        private KeyboardState _oldKeyboardState;

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            //add the ship to the sprite manager and set its size
            _spriteManager.AddSprite(_ship);
            _ship.SetSize(16, 8);

            // Set the boundary of the ship's movement while patrolling
            _patrolArea = 20.0f;
            _warpArea = -42.0f;

            // Set the default movement speed and direction of the ship
            _shipSpeed = 10.0f;
            _shipDirection = _shipSpeed * 1.0f;
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>        
        public override void LoadContent()
        {
            _shipTexture.LoadContent(_contentManager);

            _ship.SetSpriteTexture(_shipTexture);
        }

        /// <summary>
        /// Handle input reaction here
        /// </summary>
        /// <param name="keyboardState">Main keyboard state in the game</param>
        /// <param name="mouseState">Main mouse state in the game</param>
        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {            
            //*********** Begin Focus Area 1 ***********//
            //Check if the P Key is Down
            //keyboardState.IsKeyDown(Keys.P)

            //Check if the P Key was Up previously
            //_oldKeyboardState.IsKeyUp(Keys.P)

            //Check if the C Key is Down
            //keyboardState.IsKeyDown(Keys.C)
            
            //Check if the C Key was Up previously
            //_oldKeyboardState.IsKeyUp(Keys.C)

            //Check if the E Key is Down
            //keyboardState.IsKeyDown(Keys.E)
            
            //Check if the E Key was Up previously
            //_oldKeyboardState.IsKeyUp(Keys.E)

            //*********** End Focus Area 1 ***********//
  
            

            _oldKeyboardState = keyboardState;
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;
                        
            //*********** Begin Focus Area 2 ***********//

            //*********** End Focus Area 2 ***********//

          
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);
        }
    }
}
