using GameDev.Utilities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class TextureExercise : Module
    {
        // Pre-built quads the textures will be rendered on
        private Quad _backgroundQuad;

        //*********** Begin Focus Area 1 ***********//

        // Declare quads for each tile that will be rendered

        //*********** End Focus Area 1 ***********//



        // Standard XNA texture that will be rendered
        private Texture2D _backgroundTexture;
        
        //*********** Begin Focus Area 2 ***********//

        // Declare Texture2Ds for each tile that will be rendered

        //*********** End Focus Area 2 ***********//

          

        // Texture coordinates for the quad
        private Vector2 _textureUpperLeft = new Vector2(0.0f, 0.0f);
        private Vector2 _textureUpperRight = new Vector2(1.0f, 0.0f);
        private Vector2 _textureLowerLeft = new Vector2(0.0f, 1.0f);
        private Vector2 _textureLowerRight = new Vector2(1.0f, 1.0f);

        //*********** Begin Focus Area 3 ***********//

        // Declare the Vector2 properties that will represent the texture coordinates for the tile quads

        //*********** End Focus Area 3 ***********//



        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            // Build the background quad
            _backgroundQuad = new Quad(new Vector3(0.0f, 0.0f, 0.0f), 75.0f, 42.0f);

            //*********** Begin Focus Area 4 ***********//

            // Build the three tile quads

            //*********** End Focus Area 4 ***********//


            // Fill the verticies for the background quad
            _backgroundQuad.FillVertices(_textureUpperLeft, _textureUpperRight, _textureLowerLeft, _textureLowerRight);

            //*********** Begin Focus Area 5 ***********//

            // Fill the vertices for the three tile quads

            //*********** End Focus Area 5 ***********//


        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {            
            // Load a texture using XNA's content manager
            _backgroundTexture = _contentManager.Load<Texture2D>("Graphics\\skyBackground");
            _backgroundQuad.SetTexture(_backgroundTexture);

            //*********** Begin Focus Area 6 ***********//

            // Load the textures for the tiles

            //*********** End Focus Area 6 ***********//

        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            // Draw the background
            DrawTexturedQuad(_backgroundQuad, Matrix.Identity);

            //*********** Begin Focus Area 7 ***********//

            // Draw the tiles using DrawTextureQuad

            //*********** End Focus Area 7 ***********//

          
        }       
    }
}
