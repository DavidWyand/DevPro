using GameDev.Utilities;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System;

namespace GameDev.Exercises
{
    class TranslationExercise : Module
    {
        // Ship properties
        private Texture2D _shipTexture;
        private Matrix _shipTransform = Matrix.Identity;
        private Quad _shipQuad;
        private float _shipTranslation;
        private float _shipTranslatePerSecond;

        // Astronaut properties
        private Texture2D _astronautTexture;
        private Matrix _astronautTransform = Matrix.Identity;
        private Quad _astronautQuad;
        private Vector3 _astronautOffset = new Vector3(10.0f, 0, 0);

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            _shipQuad = new Quad(new Vector3(0, 0, 0), 10.0f, 5.0f);
            _astronautQuad = new Quad(new Vector3(0, 0, 0), 2.5f, 3.5f);

            _shipTranslation = 1.0f;
            _shipTranslatePerSecond = 4f;
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            _graphicsDevice.BlendState = BlendState.AlphaBlend;

            _shipTexture = _contentManager.Load<Texture2D>("Graphics\\playerShip");
            _shipQuad.SetTexture(_shipTexture);

            _astronautTexture = _contentManager.Load<Texture2D>("Graphics\\astronaut");
            _astronautQuad.SetTexture(_astronautTexture);
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            //*********** Begin Focus Area 1 ***********//

            // Set the _shipTranslation value based on deltaSeconds and _shipTranslatePerSecond

            //*********** End Focus Area 1 ***********//



            //*********** Begin Focus Area 2 ***********//
            // If the _shipTranslation is too high set it to the max and
            // multiply _shipTranslatePerSecond by an inverse value
            if (_shipTranslation > 23.0f)
            {                
                
            }

            // If the _shipTranslation is too low set it to the min and
            // multiply _shipTranslatePerSecond by an inverse value
            if (_shipTranslation < 0.25f)
            {                
                
            }
            //*********** End Focus Area 2 ***********//


            //*********** Begin Focus Area 3 ***********//
            
            // Create the translation matrix for the ship transform

            //*********** End Focus Area 3 ***********//


            //*********** Begin Focus Area 4 ***********//
             
            // Create a Vector3 base on the ship transform and astronaut offset

            // Create the translation matrix for the astronaut transform
 
            //*********** End Focus Area 4 ***********//

        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            // Draw the ship quad using its transform
            DrawTexturedQuad(_shipQuad, _shipTransform);

            // Draw the astronaut quad using its transform
            DrawTexturedQuad(_astronautQuad, _astronautTransform);
        }        
    }
}
