using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using GameDev.Utilities;

namespace GameDev
{
    class Horse
    {
        Sprite _horse;
        float _horseCollisionRadius = 0.0f;
        Vector3 _horseVelocity = new Vector3(0.0f, 0.0f, 0.0f);

        SpriteTexture _horseRun;
        SpriteTexture _horseStand;
        bool _forceStand = true;

        Vector3 _acceleration = new Vector3(0.0f, 0.0f, 0.0f);
        Vector3 _intertia = new Vector3(0.0f, 0.0f, 0.0f);
        Vector3 _friction = new Vector3(0.0f, 0.0f, 0.0f);


        bool _walking = false;
        Vector3 _Walk = new Vector3(0.0f, 0.0f, 0.0f);
        float _walkTime = 0.0f;
        float _walkDuration = 10.0f;
        float _walkSpeed = 0.0f;

        bool _jumping = false;
        Vector3 _Jump = new Vector3(0.0f, 0.0f, 0.0f);
        float _JumpTime = 0.0f;
        float _JumpDuration = 10.0f;
        bool _JumpDisable = false;
        float _JumpSpeed = 4.8f;

        SpriteManager _spriteManager = null;
        Collision_LineSegment[] _collisionArray = null;

        public float JumpSpeed
        {
            set { _JumpSpeed = value; }
            get { return _JumpSpeed; }
        }


        public void Init( ContentManager contentManager, SpriteManager spriteManager,  Collision_LineSegment[] collisionArray )
        {
            _horseCollisionRadius = 40.0f;
            _horseRun = new SpriteTexture("Graphics\\horseRun");
            _horseRun.SetCells(192, 144);
            _horseRun.LoadContent(contentManager);
            _horseStand = new SpriteTexture("Graphics\\horse");
            _horseStand.LoadContent(contentManager);
            _horse = new Sprite(1);
            _horse.SetSize(100.0f, 100.0f);
            _horse.SetPosition(30.0f - 400.0f, 350.0f - 240.0f);
            _horse.SetSpriteTexture(_horseStand);
            spriteManager.AddSprite(_horse);
            _spriteManager = spriteManager;
            _collisionArray = collisionArray;
        }


        public void Update( GameTime time )
        {
            

            float totalTime = (float)(time.TotalGameTime.TotalMilliseconds);
            float timeStep = (float)(time.ElapsedGameTime.TotalSeconds);

            float lerpValue = MathHelper.Lerp(300, 75.0f, Math.Abs(_horseVelocity.X) / 3.5f);

            if (_jumping)
            {
                lerpValue = 50.0f;
            }

            _horseRun.SetCell((int)((DateTime.Now.Millisecond / lerpValue) % 6.0f));
            _spriteManager.UpdateSprites(time);


            //gravity
            Vector3 gravityForce = Vector3.Multiply(new Vector3(0.0f, -9.8f, 0.0f), timeStep);
            Vector3 totalForce = new Vector3();

            totalForce += gravityForce;


            if (_jumping)
            {
                if (_JumpTime < 0.01f)
                {
                    _JumpTime = totalTime;
                }

                float jumpCurrentTime = totalTime - _JumpTime;
                if (jumpCurrentTime < _JumpDuration)
                {
                    _Jump.Y = (float)(_Jump.Y * (1.0 - (jumpCurrentTime / _JumpDuration)));
                    totalForce += _Jump;
                }else
                {
                    DisableJump();
                }
            }

            if (_walking)
            {
                if (_walkTime < 0.01f)
                {
                    _walkTime = totalTime;
                }

                float impulseCurrentTime = totalTime - _walkTime;
                if (impulseCurrentTime < _walkDuration)
                {
                    _Walk.X = (float)(_Walk.X * (1.0 - (impulseCurrentTime / _walkDuration)));
                    totalForce += _Walk;
                }
                else
                {
                    _walking = false;
                }
            }

            float newX = _horse.Position.X + totalForce.X;
            float newY = _horse.Position.Y + totalForce.Y;

            _forceStand = false;
            if (_horseVelocity.X > -0.34f && _horseVelocity.X < 0.34f)
            {
                if (_horseVelocity.X != 0)
                {
                    _horse.SetSpriteTexture(_horseStand);
                }

                _forceStand = true;
            }
            else
            {
                _horse.SetSpriteTexture(_horseRun);
            }


            _walkSpeed = 0.1f;

            if (_forceStand)
            {
                _walkSpeed = 0.35f;
            }

            if (_horseVelocity.X < -0.01f)
            {
                _horse.SetFlipHorizontal(true);
            }

            if (_horseVelocity.X > 0.01f)
            {
                _horse.SetFlipHorizontal(false);
            }

            Vector3 newHorsePosition = new Vector3(newX, newY, 0.0f);
            Vector3 oldHorsePosition = _horse.Position;

            foreach( Collision_LineSegment lineSegment in _collisionArray )
            {
                if( lineSegment.VsSphere(newHorsePosition,_horseCollisionRadius))
                {
                    if (newHorsePosition.Y - 30.0f > lineSegment._start.Y)
                    {
                        if (totalForce.Y <= 0 )//only collide if we are falling down. Allows us to jump up through platforms.
                        {
                            
                            _jumping = false;
                            newHorsePosition.Y = _horse.Position.Y;//set ourselves back to before we collided.
                            totalForce.Y = _acceleration.Y;
                            _horseVelocity.Y = 0.0f;
                            _horseVelocity.X -= (_horseVelocity.X / 2.0f * timeStep);
                            totalForce -= gravityForce;
                            totalForce.Y = 0.0f;

                            if (_forceStand)
                            {
                                _horseVelocity.X = 0.0f;
                            }
                        }
                    }
                }
            }
            
            float finalX = _horseVelocity.X + newHorsePosition.X + totalForce.X;
            float finalY = _horseVelocity.Y + newHorsePosition.Y + totalForce.Y;

            if (finalX > 420)
                finalX = -420;

            if (finalX < -420)
                finalX = 420;

            if (finalY < -420)
                finalY = 420;

            _horse.SetPosition(finalX, finalY);

            _horseVelocity += (_acceleration + totalForce) / 2;
            _acceleration = totalForce;
        
        }

        public void DisableJump()
        {
            _JumpDisable = false;
        }

        public void Jump()
        {
          
            if (!_jumping && !_JumpDisable)
            {
                _Jump.Y = _JumpSpeed;
                _jumping = true;
                _JumpTime = 0.0f;
                _JumpDisable = true;
            }
          
        }

        public void MoveLeft()
        {
          
            if (!_jumping)
            {
                _Walk.X = -_walkSpeed;
                _walking = true;
                _walkTime = 0.0f;
            }
           
        }

        public void MoveRight()
        {
           
            if (!_jumping)
            {
                _Walk.X = _walkSpeed;
                _walking = true;
                _walkTime = 0.0f;
            }
        
        }

        public  void RenderDebug(GraphicsDevice graphicsDevice,Matrix viewProjection)
        {
            Color state;
            if (_jumping)
            {
                state = Color.Red;
            }
            else
            {
                state = Color.Blue;
            }

           // DebugDraw.DrawCircle(graphicsDevice, viewProjection, new Vector3(_horse.Position.X, _horse.Position.Y, 0.0f), _horseCollisionRadius, Vector3.UnitY, Vector3.UnitZ, state);

            //DebugDraw.DrawLine(graphicsDevice, viewProjection, _horse.Position, _horse.Position + (_horseVelocity * 10.0f), Color.Red);
        }
    }
}
