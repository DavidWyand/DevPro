using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;
using GameDev.Utilities;

namespace GameDev
{
    class using_objects : Module
    {
        SpriteManager _spriteManager;
        Sprite _background;
        

        Collision_LineSegment _Ground;
        Collision_LineSegment _Ground2;
        Collision_LineSegment _Ground3;
        Collision_LineSegment _Platform;
        Collision_LineSegment[] _collisionArray = new Collision_LineSegment[4];

        //*********** Begin Focus Area 1 ***********//
        Horse MyHorse = null;
        Horse MyHorse2 = null;//This line is for a later step. Ignore for now.
        //*********** End Focus Area 1 ***********//

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            _spriteManager = new SpriteManager();

            //*********** Begin Focus Area 5 ***********//
        
            //*********** End Focus Area 5 ***********//

        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            OrthoCamera cam = new OrthoCamera();
            cam.Left = -400;
            cam.Right = 400;
            cam.Top = 240;
            cam.Bottom = -240;

            DefaultCamera = cam;

            DebugDraw.Initialize(_graphicsDevice, _contentManager);

            // Setup some render states
            SetupRenderState();

            SpriteTexture backgroundTexture = new SpriteTexture("Graphics\\bg");
            backgroundTexture.LoadContent(_contentManager);

            _background = new Sprite(0);
            _background.SetSpriteTexture(backgroundTexture);
            _background.SetPosition(0, 0);
            _background.SetSize(800, 480);
            _spriteManager.AddSprite(_background);


            _Ground = new Collision_LineSegment(new Vector3(215.0f - 400.0f, 152.0f - 240.0f, 0.0f), new Vector3(1.0f, 0.0f, 0.0f), new Vector3(0.0f, 1.0f, 0.0f), 430);
            _Ground2 = new Collision_LineSegment(new Vector3(635.0f - 400.0f, 270.0f - 240.0f, 0.0f), new Vector3(1.0f, 0.0f, 0.0f), new Vector3(0.0f, 1.0f, 0.0f), 400);
            _Ground3 = new Collision_LineSegment(new Vector3(675.0f - 400.0f, 153.0f - 240.0f, 0.0f), new Vector3(1.0f, 0.0f, 0.0f), new Vector3(0.0f, 1.0f, 0.0f), 268);
            _Platform = new Collision_LineSegment(new Vector3(260.0f - 400.0f, 252.0f - 240.0f, 0.0f), new Vector3(1.0f, 0.0f, 0.0f), new Vector3(0.0f, 1.0f, 0.0f), 100);

            _collisionArray[0] = _Ground;
            _collisionArray[1] = _Ground2;
            _collisionArray[2] = _Ground3;
            _collisionArray[3] = _Platform;

            if (MyHorse != null)
            {
                MyHorse.Init(_contentManager, _spriteManager, _collisionArray);
            }
         
            if(MyHorse2 != null )
            {
                MyHorse2.Init(_contentManager, _spriteManager, _collisionArray);
            }
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            if (MyHorse != null)
            {
                MyHorse.Update(time);
            }

            if (MyHorse2 != null)
            {
                MyHorse2.Update(time);
            }
        }


        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {

            if (keyboardState.IsKeyDown(Keys.Space))
            {
                //*********** Begin Focus Area 2 ***********//               

                //*********** End Focus Area 2 ***********//
               
            }

            if (keyboardState.IsKeyDown(Keys.Left))
            {
                //*********** Begin Focus Area 3 ***********//    

                //*********** End Focus Area 3 ***********//
    
            }

            if (keyboardState.IsKeyDown(Keys.Right))
            {
                //*********** Begin Focus Area 4 ***********//    

               //*********** End Focus Area 4 ***********// 

            }

        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
           
            Matrix viewProjection = DefaultCamera.View * DefaultCamera.Projection;
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);

            if (MyHorse != null)
            {
                MyHorse.RenderDebug(_graphicsDevice, viewProjection);
            }

            if (MyHorse2 != null)
            {
                MyHorse2.RenderDebug(_graphicsDevice, viewProjection);
            }

            //DebugDraw.DrawLine(_graphicsDevice, viewProjection, _Ground._start, _Ground._end, Color.Red);
            //DebugDraw.DrawLine(_graphicsDevice, viewProjection, _Ground2._start, _Ground2._end, Color.Red);
            //DebugDraw.DrawLine(_graphicsDevice, viewProjection, _Ground3._start, _Ground3._end, Color.Red);
            //DebugDraw.DrawLine(_graphicsDevice, viewProjection, _Platform._start, _Platform._end, Color.Red);

        }

    }
}
