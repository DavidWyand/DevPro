using GameDev;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;
using GameDev.Utilities;

namespace GameDev
{
    class variables : Module
    {
        // XNA/MonoGame sprite objects for rendering text
        SpriteBatch _spriteBatch;
        SpriteFont _font;        
        
        // Main SpriteManager which updates and renders all Sprite objects
        SpriteManager _spriteManager = new SpriteManager();
        float _textureRatio = 17f;

        // Simple time tracking variable
        private float _currentTime = 0.0f;

        //*********** Begin Focus Area 1 ***********//

        //*********** End Focus Area 1 ***********//
          

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            //*********** Begin Focus Area 2 ***********//
            CreateBackground();

            if (true)
            {
                CreateShips();
            }
            else
            {
                CreateBubbles();
            }
            //*********** End Focus Area 2 ***********//


            _spriteBatch = new SpriteBatch(_graphicsDevice);
            _font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Update all sprites
            _spriteManager.UpdateSprites(time);

            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            _currentTime += deltaSeconds;

            if (_currentTime >= 10)
            {
                _currentTime = 0.0f;

                //*********** Begin Focus Area 3 ***********//

                //*********** End Focus Area 3 ***********//

          
            }
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            base.Render();

            // Render all sprites
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);

            // Render game text/UI
            _spriteBatch.Begin();

            //*********** Begin Focus Area 4 ***********//
            _spriteBatch.DrawString(_font, "Total Bubbles: ", new Vector2(0.0f, 0.0f), Color.White);
            //*********** End Focus Area 4 ***********//

          
            
            _spriteBatch.End();
        }
        
        public void CreateBackground(string texturePath = "")
        {
            if (texturePath != "")
            {
                // Build the background            
                var background = new Sprite();
                var texture = new SpriteTexture(texturePath);
                texture.LoadContent(_contentManager);
                background.SetSpriteTexture(texture);
                background.SetSize(texture.ImageWidth / _textureRatio, texture.ImageHeight / _textureRatio);

                _spriteManager.AddSprite(background);
            }
        }

        public void CreateShips(int count = 0)
        {
            Random rand = new Random();

            for (int i = 0; i < count; i++)
            {
                var y = (float)rand.Next(-20, 20);
                var x = (float)rand.Next(-100, -50);

                var sprite = new Sprite();
                var texture = new SpriteTexture("Graphics\\Ship1");

                texture.LoadContent(_contentManager);
                sprite.SetSpriteTexture(texture);
                _spriteManager.AddSprite(sprite);

                sprite.SetSize(texture.ImageWidth / _textureRatio, texture.ImageHeight / _textureRatio);
                sprite.SetPosition(x, y);
                sprite.MoveTo(new Vector2(50, y), 5000, MotionAction.EndAction.Restart);
            }
        }

        public void CreateBubbles(int count = 0, float size = 5.5f)
        {
            Random rand = new Random();

            for (int i = 0; i < count; i++)
            {
                var y = (float)rand.Next(-40, -20);
                var x = (float)rand.Next(-40, 40);

                var sprite = new Sprite();
                var texture = new SpriteTexture("Graphics\\bubblePopper_bubbleGreen");
                texture.LoadContent(_contentManager);
                sprite.SetSpriteTexture(texture);
                _spriteManager.AddSprite(sprite);

                sprite.SetSize(size, size);
                sprite.SetPosition(x, y);
                sprite.MoveAmount(new Vector2(3.0f, 70), 10000, MotionAction.EndAction.Restart);
            }
        }
    }
}
