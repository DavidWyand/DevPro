using GameDev.Utilities;
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;

namespace GameDev.FinishedExercises
{
    class VectorExercise : Module
    {
        SpriteBatch _spriteBatch;
        SpriteFont _Font;

        float _angle = 0;
        Vector3 _vector = Vector3.UnitY * 100;

        private SpriteManager _spriteManager = new SpriteManager();

        Sprite _background;
        SpriteTexture _backgroundTexture;

        Sprite _reticle;
        SpriteTexture _reticleTexture;
        
        Sprite _ship;
        SpriteTexture _shipTexture;

        Vector2 _mousePosition = Vector2.Zero;

        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            _graphicsDevice.BlendState = BlendState.AlphaBlend;

            DebugDraw.Initialize(_graphicsDevice, _contentManager);
            _spriteBatch = new SpriteBatch(_graphicsDevice);
            _Font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");

            _spriteManager = new SpriteManager();

            // Build the background                        
            _backgroundTexture = new SpriteTexture("Graphics\\AsteroidBackground");
            _backgroundTexture.LoadContent(_contentManager);

            _background = new Sprite();
            _background.SetSpriteTexture(_backgroundTexture);
            _background.SetSize(75, 42);

            _spriteManager.AddSprite(_background);

            // Build ship
            _shipTexture = new SpriteTexture("Graphics\\ship");
            _shipTexture.LoadContent(_contentManager);

            _ship = new Sprite(1);
            _ship.SetSpriteTexture(_shipTexture);
            _ship.SetFlipHorizontal(true);
            _ship.SetSize(3.7f, 3.7f);
            
            _spriteManager.AddSprite(_ship);

            // Build reticle
            _reticleTexture = new SpriteTexture("Graphics\\reticle");
            _reticleTexture.LoadContent(_contentManager);

            _reticle = new Sprite(1);
            _reticle.SetSpriteTexture(_reticleTexture);
            _reticle.SetSize(5f, 5f);
            _reticle.SetTint(Color.Red);

            _spriteManager.AddSprite(_reticle);            
        }        

        public void DrawVector(Vector3 origin, Vector3 vector, Color color)
        {
            Matrix viewProjection = DefaultCamera.View * DefaultCamera.Projection;
            DebugDraw.DrawVector(_graphicsDevice, viewProjection, origin, vector, color, Vector3.UnitZ);
        }

        public void DrawLine(Vector3 start, Vector3 end, Color color)
        {
            Matrix viewProjection = DefaultCamera.View * DefaultCamera.Projection;
            DebugDraw.DrawLine(_graphicsDevice, viewProjection, start, end, color);
        }

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            // Extract the amount of time that has passed since the last update
            TimeSpan deltaTime = time.ElapsedGameTime;
            float deltaSeconds = (float)deltaTime.TotalSeconds;

            _angle += MathHelper.Pi * 2 / 1200;

            if (_angle > MathHelper.Pi * 2)
                _angle -= MathHelper.Pi * 2;

            Matrix m = Matrix.CreateRotationZ(_angle);
            m = Matrix.CreateRotationZ(_angle);
            _vector = Vector3.Transform(Vector3.UnitY, m) * 10;            

            // Update all sprites
            _spriteManager.UpdateSprites(time);
        }

        public void RenderPrimitives()
        {
            
            //*********** Begin Focus Area 1 ***********//

            //*********** End Focus Area 1 ***********//


            DrawVector(new Vector3(0, -10, 0), new Vector3(0, 20, 0), Color.Green);            
            DrawLine(new Vector3(-10, 0, 0), new Vector3(10, 0, 0), Color.Red);            

            //*********** Begin Focus Area 2 ***********//
            float dot = 0.0f;
            float angle = 0.0f;
            //*********** End Focus Area 2 ***********//


            _spriteBatch.Begin();
            _spriteBatch.DrawString(_Font, "Rot: " + MathHelper.ToDegrees(_angle), new Vector2(625, 80), Color.Black);
            _spriteBatch.DrawString(_Font, "Dot: " + dot, new Vector2(625, 100), Color.Black);
            _spriteBatch.DrawString(_Font, "Angle: " + MathHelper.ToDegrees(angle), new Vector2(625, 120), Color.Black);
            _spriteBatch.DrawString(_Font, "1.0f", new Vector2(625, 150), Color.Black);
            _spriteBatch.DrawString(_Font, "-1.0f", new Vector2(615, 540), Color.Black);
            _spriteBatch.DrawString(_Font, "0.0f", new Vector2(410, 345), Color.Black);
            _spriteBatch.DrawString(_Font, "0.0f", new Vector2(830, 345), Color.Black);

            _spriteBatch.End();
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            //*********** Begin Focus Area 3 ***********//
            RenderPrimitives();
            //RenderSprite();
            //*********** End Focus Area 3 ***********//
            
        }

        void RenderSprite()
        {
            // Render all sprites
            _spriteManager.RenderSprites(_graphicsDevice, DefaultCamera);
        }

        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {
            _reticle.SetPosition((mouseState.Position.X - (_graphicsDevice.Viewport.Width / 2)) / 17f, -(mouseState.Position.Y - (_graphicsDevice.Viewport.Height / 2)) / 17f);

            //*********** Begin Focus Area 4 ***********//

            //*********** End Focus Area 4 ***********//

        }
    }
}
