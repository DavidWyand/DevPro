using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class BubbleObjectManager
    {
        private List<BubbleObject> _objectList = new List<BubbleObject>();

        public void AddObject(BubbleObject obj)
        {
            _objectList.Add(obj);
        }

        public void RemoveObject(BubbleObject obj)
        {
            _objectList.Remove(obj);
        }

        public int Count()
        {
            return _objectList.Count();
        }

        public BubbleObject GetObject(int index)
        {
            return _objectList[index];
        }

        public void MarkAllForDeletion()
        {
            foreach(BubbleObject bubble in _objectList)
            {
                bubble.MarkForDeletion();
            }
        }

        private static bool CheckObjectForDeletion(BubbleObject obj)
        {
            return obj.DeleteObject;
        }

        public void CleanUp()
        {
            _objectList.RemoveAll(CheckObjectForDeletion);
        }
    }
}
