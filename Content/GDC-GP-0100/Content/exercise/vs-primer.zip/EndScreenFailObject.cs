using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class EndScreenFailObject : SceneObject
    {
        private const float _graphicObjectYOffset = -150.0f;
        private const float _scoreObjectYOffset = 120.0f;
        private const float _scoreXOffset = 80.0f;
        private const float _scoreYOffset = 87.0f;
        private const float _pressObjectYOffset = 270.0f;

        private SpriteFont _font;

        private string _scoreText = "";

        private SceneObject _graphicsObject;

        private SceneObject _scoreObject;

        private SceneObject _pressObject;

        public EndScreenFailObject(GraphicsDevice graphics, ContentManager content, Effect pointSpriteEffect,  SpriteFont font, int score)
        {
            _font = font;

            PointSprite graphicsSprite = new PointSprite(graphics, pointSpriteEffect, GameTextures.EndFailedOverlayTexture);
            graphicsSprite.Size = new Vector2(512.0f * 0.5f, 512.0f * 0.5f);
            _graphicsObject = new SceneObject(graphicsSprite);
            _graphicsObject.WorldMatrix = Matrix.CreateTranslation(new Vector3(0.0f, 0.0f, GamePlayState.ZPositionMidground));

            PointSprite scoreSprite = new PointSprite(graphics, pointSpriteEffect, GameTextures.EndFailedScoreTexture);
            scoreSprite.Size = new Vector2(1024.0f * 0.5f, 256.0f * 0.5f);
            _scoreObject = new SceneObject(scoreSprite);
            _scoreObject.WorldMatrix = Matrix.CreateTranslation(new Vector3(0.0f, 0.0f, GamePlayState.ZPositionMidground));

            PointSprite pressSprite = new PointSprite(graphics, pointSpriteEffect, GameTextures.EndFailedPressMouseTexture);
            pressSprite.Size = new Vector2(1024.0f * 0.5f, 256.0f * 0.5f);
            _pressObject = new SceneObject(pressSprite);
            _pressObject.WorldMatrix = Matrix.CreateTranslation(new Vector3(0.0f, 0.0f, GamePlayState.ZPositionMidground));

            _scoreText = score.ToString();
        }

        public override void Render(GraphicsDevice graphics, Camera camera)
        {
            base.Render(graphics, camera);

            _graphicsObject.Position = new Vector3(Position.X, Position.Y + _graphicObjectYOffset, Position.Z);
            _graphicsObject.Render(graphics, camera);

            _scoreObject.Position = new Vector3(Position.X, Position.Y + _scoreObjectYOffset, Position.Z);
            _scoreObject.Render(graphics, camera);

            _pressObject.Position = new Vector3(Position.X, Position.Y + _pressObjectYOffset, Position.Z);
            _pressObject.Render(graphics, camera);
        }

        public override void RenderText(GraphicsDevice graphicsDevice, SpriteBatch spriteBatch)
        {
            // Draw score text
            float posX = Position.X + _scoreXOffset;
            float posY = Position.Y + _scoreYOffset;

            DrawShadowedText(spriteBatch, _font, _scoreText, posX, posY);
        }
    }
}
