using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace GameDev.Exercises
{
    class GameSounds
    {
        static public SoundEffect TitleMusic;
        static public SoundEffect SuccessMusic;
        static public SoundEffect FailMusic;

        static public SoundEffect BubblePopSound;
        static public SoundEffect NewWordSound;
        static public SoundEffect MouseClickSound;

        static public SoundEffect ScoreUpSound;
        static public SoundEffect ScoreDownSound;

        public void Init(ContentManager content)
        {
            TitleMusic = content.Load<SoundEffect>("Sound\\PL_TitleAudio");
            SuccessMusic = content.Load<SoundEffect>("Sound\\TD_WinMusic");
            FailMusic = content.Load<SoundEffect>("Sound\\TD_LoseMusic");

            BubblePopSound = content.Load<SoundEffect>("Sound\\PL_Hit");
            NewWordSound = content.Load<SoundEffect>("Sound\\TD_TowerUpgrade");
            MouseClickSound = content.Load<SoundEffect>("Sound\\Button_Click_01_Rev1");

            ScoreUpSound = content.Load<SoundEffect>("Sound\\Score_Counting_Up_09_Rev1");
            ScoreDownSound = content.Load<SoundEffect>("Sound\\PL_Vanish");
        }
    }
}
