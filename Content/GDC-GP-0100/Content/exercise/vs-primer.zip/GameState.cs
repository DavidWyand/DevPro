using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    /// <summary>
    /// The base class from which all other game states inherit
    /// </summary>
    class GameState
    {
        // The GameStateManager that owns this game state
        private GameStateManager _manager;

        public GameStateManager Manager
        {
            get { return _manager; }
        }

        /// <summary>
        /// Get the name of this game state that may be referenced by other states
        /// </summary>
        /// <returns>The name of this state</returns>
        public virtual string GetName()
        {
            return "";
        }

        /// <summary>
        /// Called when the game state has been registered with a game state manager
        /// </summary>
        /// <param name="manager">The game state manager</param>
        public virtual void OnRegistered(GameStateManager gameManager)
        {
            _manager = gameManager;
        }

        /// <summary>
        /// Called when the game state has been unregistered with a game state manager
        /// </summary>
        public virtual void OnUnregistered()
        {
            _manager = null;
        }

        /// <summary>
        /// Called when this game state is first entered.  Allows for set up.
        /// </summary>
        public virtual void OnEnter()
        {

        }

        /// <summary>
        /// Called when leaving this game state.  Allows for clean up.
        /// </summary>
        public virtual void OnLeave()
        {

        }

        /// <summary>
        /// Called to update this state each game tick when this is the current state.
        /// </summary>
        /// <param name="time">This tick's GameTime</param>
        public virtual void Update(GameTime time)
        {

        }

        /// <summary>
        /// Called when there is a change in the mouse button state
        /// </summary>
        /// <param name="mouseLeftClicked">Indicates if the left mouse button has been pressed (true) or released (false)</param>
        /// <param name="mousePosition">The mouse position on the screen at the time of the button press or release</param>
        public virtual void UpdateInput(bool mouseLeftClicked, Vector2 mousePosition)
        {

        }
    }
}
