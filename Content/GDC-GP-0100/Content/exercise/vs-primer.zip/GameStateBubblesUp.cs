using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace GameDev.Exercises
{
    /// <summary>
    /// "BubblesUp" game state
    /// </summary>
    class GameStateBubblesUp : GameState
    {
        enum BubblesState
        {
            DisplayInstructions,
            NewWord,
            BubblesUp,
            WaitForBubbles,
            WordDone
        }

        private SpriteFont _font;
        private SpriteFont _fontSmall;
        private float _midgroundZPosition;
        private float _bubbleZPosition;

        private BubbleObjectManager _bubbleManager = new BubbleObjectManager();

        private Random _rndGen = new Random();

        private InstructionScreenObject _instructionScreenObject = null;
        private float _instructionsCountdown;

        private bool[] _bubbleChannelsFilled;

        private int[] _bubbleChannelsCorrect;

        private Octree _octree;
        private float _bubbleChannelWidth;

        private string _correctAnswerText;
        private List<string> _incorrectAnswerTextList = new List<string>();

        private int _numberOfRowsPresented;
        private float _timeToNextBubble;

        private BubblesState _currentState;

        private bool _audioEnabled = true;

        private SoundEffectInstance[] _bubblePopSound = new SoundEffectInstance[3];
        private int _nextBubblePopSound = 0;
        private SoundEffectInstance[] _scoreUpSound = new SoundEffectInstance[3];
        private int _nextScoreUpSound = 0;
        private SoundEffectInstance[] _scoreDownSound = new SoundEffectInstance[3];
        private int _nextScoreDownSound = 0;

        public GameStateBubblesUp(SpriteFont font, SpriteFont fontSmall)
        {
            _font = font;
            _fontSmall = fontSmall;
            _midgroundZPosition = GamePlayState.ZPositionMidground;
            _bubbleZPosition = GamePlayState.ZPositionBubble;

            _octree = new Octree(new BoundingBox(new Vector3(0.0f, 0.0f, 0.0f), new Vector3(2000.0f, 2000.0f, 2000.0f)), 2);

            _bubbleChannelWidth = GamePlayState.TroughWidth / (float)GamePlayState.NumberOfBubbleChannels;

            _bubbleChannelsFilled = new bool[GamePlayState.NumberOfBubbleChannels];
            _bubbleChannelsCorrect = new int[GamePlayState.NumberOfCorrectWordsPerRow];

            try
            {
                for (int i = 0; i < 3; ++i)
                {
                    _bubblePopSound[i] = GameSounds.BubblePopSound.CreateInstance();
                    _scoreUpSound[i] = GameSounds.ScoreUpSound.CreateInstance();
                    _scoreDownSound[i] = GameSounds.ScoreDownSound.CreateInstance();
                }
            }
            catch
            {
                _audioEnabled = false;
            }
        }

        public override string GetName()
        {
            return "BubblesUp";
        }

        public override void OnEnter()
        {
            _currentState = BubblesState.DisplayInstructions;
        }

        public override void OnLeave()
        {
            _bubbleManager.MarkAllForDeletion();
            _bubbleManager.CleanUp();

            if (_instructionScreenObject != null)
            {
                Manager.SceneObjectManager.RemoveObject(_instructionScreenObject);
                _instructionScreenObject = null;
            }
        }

        public override void Update(GameTime time)
        {
            float msDelta = (float)time.ElapsedGameTime.TotalMilliseconds;

            switch(_currentState)
            {
                case BubblesState.DisplayInstructions:
                    DisplayInstructions(msDelta);
                    break;

                case BubblesState.NewWord:
                    NewWord();
                    break;

                case BubblesState.BubblesUp:
                    BubblesUp(msDelta);
                    break;

                case BubblesState.WaitForBubbles:
                    WaitForBubbles();
                    break;

                case BubblesState.WordDone:
                    WordDone();
                    break;
            }

            _bubbleManager.CleanUp();
        }

        public override void UpdateInput(bool mouseLeftClicked, Vector2 mousePosition)
        {
            // Check if the instructions are being displayed
            if (_currentState == BubblesState.DisplayInstructions && _instructionScreenObject != null && mouseLeftClicked && _instructionsCountdown <= 0.0f)
            {
                // Move on from instructions
                Manager.SceneObjectManager.RemoveObject(_instructionScreenObject);
                _instructionScreenObject = null;

                // Move onto the next word
                _currentState = BubblesState.NewWord;

                return;
            }

            // From this point, only handle mouse input when the bubbles are displayed
            if (_currentState != BubblesState.BubblesUp && _currentState !=  BubblesState.WaitForBubbles)
            {
                return;
            }

            // Calculate the ray from the mouse position into the world
            Vector3 rayPos = new Vector3(mousePosition.X, mousePosition.Y, 100.0f);
            Ray testRay = new Ray(rayPos, new Vector3(0.0f, 0.0f, -1.0f));

            // Find all objects hit by the mouse pointer's ray
            GameObject[] hitObjects = _octree.Test(testRay);

            if (hitObjects.Length > 0)
            {
                BubbleObject bubble = hitObjects[0] as BubbleObject;
                if (bubble != null)
                {
                    // Popping sound
                    PlayBubblePop();

                    // Build the popping bubble
                    CreateBubblePopped(bubble.Position);

                    if (bubble.IsCorrect)
                    {
                        // Correct answer has been selected
                        ScoreCorrectObject scoreObj = new ScoreCorrectObject(_font, GamePlayState.CorrectScore);
                        scoreObj.Position = bubble.Position;
                        Manager.SceneObjectManager.AddObject(scoreObj);

                        GamePlayState.CurrentScore += GamePlayState.CorrectScore;

                        // Score up sound
                        if(_audioEnabled)
                        {
                            _scoreUpSound[_nextScoreUpSound].Play();
                            ++_nextScoreUpSound;
                            if (_nextScoreUpSound >= 3)
                            {
                                _nextScoreUpSound = 0;
                            }
                        }
                    }
                    else
                    {
                        // Incorrect answer has been selected
                        ScoreIncorrectObject scoreObj = new ScoreIncorrectObject(_font, GamePlayState.IncorrectScore);
                        scoreObj.Position = bubble.Position;
                        Manager.SceneObjectManager.AddObject(scoreObj);

                        GamePlayState.CurrentScore += GamePlayState.IncorrectScore;

                        // Score down sound
                        if(_audioEnabled)
                        {
                            _scoreDownSound[_nextScoreDownSound].Volume = 0.5f;
                            _scoreDownSound[_nextScoreDownSound].Play();
                            ++_nextScoreDownSound;
                            if (_nextScoreDownSound >= 3)
                            {
                                _nextScoreDownSound = 0;
                            }
                        }
                    }

                    // Update score text
                    CurrentScoreObject score = Manager.SceneObjectManager.FindObjectByName("Score") as CurrentScoreObject;
                    if(score != null)
                    {
                        score.SetScore(GamePlayState.CurrentScore);
                    }

                    // Don't need the bubble any more
                    bubble.MarkForDeletion();
                }
            }
        }

        private void PlayBubblePop()
        {
            if(!_audioEnabled)
            {
                return;
            }

            _bubblePopSound[_nextBubblePopSound].Play();
            ++_nextBubblePopSound;
            if (_nextBubblePopSound >= 3)
            {
                _nextBubblePopSound = 0;
            }
        }

        private void DisplayInstructions(float msDelta)
        {
            if (_instructionScreenObject != null)
            {
                if (_instructionsCountdown > 0.0f)
                {
                    _instructionsCountdown -= msDelta;
                }
            }
            else
            {
                // Create the instructions screen
                _instructionScreenObject = new InstructionScreenObject(Manager.GraphicsDevice, Manager.ContentManager, Manager.PointSpriteEffect, _font, GamePlayState.WordList[GamePlayState.CurrentWord]);
                _instructionScreenObject.Position = new Vector3(Manager.GraphicsDevice.Viewport.Width * 0.5f, Manager.GraphicsDevice.Viewport.Height * 0.5f, _midgroundZPosition);
                Manager.SceneObjectManager.AddObject(_instructionScreenObject);

                // Count down until we allow a mouse click.  This prevents an accidental click when the player
                // is trying to click on bubbles.
                _instructionsCountdown = 500.0f;

                // Hide the header
                SceneObject header = Manager.SceneObjectManager.FindObjectByName("Header");
                if(header != null)
                {
                    header.Visible = false;
                }
            }
        }

        private void NewWord()
        {
            // Clear out the flags for the line of bubbles
            ClearBubbleChannels();

            // Calculate the channels that will hold the correct words
            FillCorrectChannels();

            // Get the correct word
            _correctAnswerText = GamePlayState.WordList[GamePlayState.CurrentWord];

            // Populate the header
            CurrentWordObject header = Manager.SceneObjectManager.FindObjectByName("Header") as CurrentWordObject;
            if(header != null)
            {
                header.SetWord(_correctAnswerText);
                header.Visible = true;
            }

            // Populate the incorrect word list
            _incorrectAnswerTextList.Clear();
            for (int i = 0; i < GamePlayState.TotalWords; ++i)
            {
                if (i != GamePlayState.CurrentWord)
                {
                    _incorrectAnswerTextList.Add(GamePlayState.WordList[i]);
                }
            }

            _numberOfRowsPresented = 0;

            _timeToNextBubble = 0.0f;

            _currentState = BubblesState.BubblesUp;
        }

        private void BubblesUp(float msDelta)
        {
            _timeToNextBubble -= msDelta;
            if (_timeToNextBubble <= 0.0f)
            {
                // Spawn a new bubble
                int channel = GetRandomUnfilledBubbleChannel();
                _bubbleChannelsFilled[channel] = true;
                string text = _correctAnswerText;
                bool bubbleIsCorrect = true;
                if (!IsCorrectChannel(channel))
                {
                    int index = _rndGen.Next(_incorrectAnswerTextList.Count());
                    text = _incorrectAnswerTextList[index];
                    bubbleIsCorrect = false;
                }
                CreateBubble(text, channel, bubbleIsCorrect);

                // Are all channels filled?
                if (AreBubbleChannelsFilled())
                {
                    // Have we presented enough rows for this word?
                    ++_numberOfRowsPresented;
                    if (_numberOfRowsPresented >= GamePlayState.NumberOfRowsPerWord)
                    {
                        // Done with this word so move to the wait state
                        _currentState = BubblesState.WaitForBubbles;
                    }
                    else
                    {
                        // Start a new row
                        ClearBubbleChannels();

                        // Calculate the channels that will hold the correct words
                        FillCorrectChannels();

                        _timeToNextBubble = 1000.0f;
                    }

                }
                else
                {
                    _timeToNextBubble = 250.0f;
                }
            }

            // Check any bubbles that have gone too high
            bool correctBubblePopped = HandleBubblesThatAreTooHigh();
            if (correctBubblePopped)
            {
                // A correct bubble reached the top, which ends the game.
                Manager.RequestChangeToState("EndFail");
            }
        }

        private void WaitForBubbles()
        {
            // Check any bubbles that have gone too high
            bool correctBubblePopped = HandleBubblesThatAreTooHigh();
            if (correctBubblePopped)
            {
                // A correct bubble reached the top, which ends the game.
                Manager.RequestChangeToState("EndFail");
            }
            else
            {
                // Are there any bubbles left?
                if (_bubbleManager.Count() <= 0)
                {
                    // No more bubbles for this row, so move on
                    _currentState = BubblesState.WordDone;
                }
            }

        }

        private void WordDone()
        {
            GamePlayState.CurrentWord++;

            if (GamePlayState.CurrentWord >= GamePlayState.TotalWords)
            {
                // The game is over.
                Manager.RequestChangeToState("EndSuccess");
            }
            else
            {
                // Go to the next word
                _currentState = BubblesState.DisplayInstructions;
            }

        }

        private void CreateBubble(string text, int bubbleChannel, bool isCorrect)
        {
            Texture2D bubbleTexture = GameTextures.BubbleBlueObjectTexture;
            switch(_rndGen.Next(3))
            {
                case 0:
                    bubbleTexture = GameTextures.BubbleBlueObjectTexture;
                    break;

                case 1:
                    bubbleTexture = GameTextures.BubbleGreenObjectTexture;
                    break;

                case 2:
                    bubbleTexture = GameTextures.BubbleRedObjectTexture;
                    break;
            }

            PointSprite bubbleSprite = new PointSprite(Manager.GraphicsDevice, Manager.PointSpriteEffect, bubbleTexture);
            bubbleSprite.Size = new Vector2(GamePlayState.BubbleSize, GamePlayState.BubbleSize);

            BubbleObject bubble = new BubbleObject(isCorrect, bubbleSprite);

            // Adjust the bounding sphere to just the bubble and not the whole sprite
            bubble.BoundingSphere = new BoundingSphere(Vector3.Zero, GamePlayState.BubbleSize);

            // Place the bubble within the bounds of its channel, allowing for some random positioning
            float posX = (Manager.GraphicsDevice.Viewport.Bounds.Width - GamePlayState.TroughWidth) * 0.5f + bubbleChannel * _bubbleChannelWidth + _bubbleChannelWidth * 0.5f;
            float extraSpace = _bubbleChannelWidth - (GamePlayState.BubbleSize * 2.0f);
            if (extraSpace > 0.0f)
            {

            }

            bubble.WorldMatrix = Matrix.CreateTranslation(new Vector3(posX, GamePlayState.BubbleSpawnYPosition, _bubbleZPosition));

            bubble.SetText(text, _fontSmall);

            bubble.AddForce(new Vector3(0.0f, -8000.0f, 0.0f));

            _bubbleManager.AddObject(bubble);
            Manager.SceneObjectManager.AddObject(bubble);

            _octree.AddObject(bubble);
        }

        private void CreateBubblePopped(Vector3 position)
        {
            float size = GamePlayState.BubbleSize * 2.0f;

            // Build the popping sprite
            TextureAnimated texture = new TextureAnimated(4, 1, 0, 4, 30, GameTextures.BubblePopTexture, TextureAnimated.AnimMode.StopAtEnd);
            SpriteObject sprite = new SpriteObject(texture, new Vector2(size, size));
            sprite.Position = position;
            Manager.SceneObjectManager.AddObject(sprite);
        }

        private void ClearBubbleChannels()
        {
            for (int i = 0; i < GamePlayState.NumberOfBubbleChannels; ++i)
            {
                _bubbleChannelsFilled[i] = false;
            }

            for (int i = 0; i < GamePlayState.NumberOfCorrectWordsPerRow; ++i)
            {
                _bubbleChannelsCorrect[i] = -1;
            }
        }

        private void FillCorrectChannels()
        {
            // Fill a list of channel numbers.  We'll remove from this list each
            // time one is chosen to be correct.
            List<int> channels = new List<int>();
            for (int i = 0; i < GamePlayState.NumberOfBubbleChannels; ++i )
            {
                channels.Add(i);
            }

            for (int i = 0; i < GamePlayState.NumberOfCorrectWordsPerRow; ++i)
            {
                int channel = _rndGen.Next(channels.Count());
                _bubbleChannelsCorrect[i] = channels[channel];

                // Remove the selected channel from the list so we don't choose it again
                channels.RemoveAt(channel);
            }
        }

        private bool IsCorrectChannel(int channel)
        {
            for (int i = 0; i < GamePlayState.NumberOfCorrectWordsPerRow; ++i)
            {
                if (_bubbleChannelsCorrect[i] == channel)
                {
                    return true;
                }
            }

            return false;
        }

        private bool AreBubbleChannelsFilled()
        {
            int filledChannels = 0;
            for (int i = 0; i < GamePlayState.NumberOfBubbleChannels; ++i)
            {
                if (_bubbleChannelsFilled[i])
                {
                    ++filledChannels;
                }
            }

            return filledChannels >= GamePlayState.NumberOfBubbleChannels;
        }

        private int GetRandomUnfilledBubbleChannel()
        {
            int channel = _rndGen.Next(GamePlayState.NumberOfBubbleChannels);
            while (_bubbleChannelsFilled[channel])
            {
                channel = _rndGen.Next(GamePlayState.NumberOfBubbleChannels);
            }

            return channel;
        }

        private bool HandleBubblesThatAreTooHigh()
        {
            // Tracks if a bubble with the correct answer has gone too high
            bool correctBubbleHit = false;

            for (int i = 0; i < _bubbleManager.Count(); ++i)
            {
                BubbleObject bubble = _bubbleManager.GetObject(i);
                if (bubble.Position.Y <= GamePlayState.BubbleMaxHeight)
                {
                    // Create the popped bubble
                    CreateBubblePopped(bubble.Position);

                    // Play the soound
                    PlayBubblePop();

                    // This button has gone too high, so deal with it
                    if (bubble.IsCorrect)
                    {
                        // Track that this bubble had a correct answer
                        correctBubbleHit = true;
                    }

                    bubble.MarkForDeletion();
                }
            }

            return correctBubbleHit;
        }
    }
}
