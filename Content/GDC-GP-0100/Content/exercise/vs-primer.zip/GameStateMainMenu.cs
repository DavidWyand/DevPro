using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace GameDev.Exercises
{
    /// <summary>
    /// "MainMenu" game state
    /// </summary>
    class GameStateMainMenu : GameState
    {
        // Used for the background
        private SceneObject _titleOverlayObject;

        private bool _audioEnabled = true;

        private SoundEffectInstance _musicInstance;

        public override string GetName()
        {
            return "MainMenu";
        }

        public override void OnEnter()
        {
            // Start the music
            try
            {
                _musicInstance = GameSounds.TitleMusic.CreateInstance();
                _musicInstance.IsLooped = true;
                _musicInstance.Volume = 0.35f;
                _musicInstance.Play();
            }
            catch
            {
                _audioEnabled = false;
            }

            // Display the title
            PointSprite titleSprite = new PointSprite(Manager.GraphicsDevice, Manager.PointSpriteEffect, GameTextures.TitleOverlayTexture);
            titleSprite.Size = new Vector2(Manager.GraphicsDevice.Viewport.Bounds.Width * 0.5f, Manager.GraphicsDevice.Viewport.Bounds.Height * 0.5f);
            _titleOverlayObject = new SceneObject(titleSprite);
            _titleOverlayObject.WorldMatrix = Matrix.CreateTranslation(new Vector3(titleSprite.Size, GamePlayState.ZPositionBackground));

            Manager.SceneObjectManager.AddObject(_titleOverlayObject);
        }

        public override void OnLeave()
        {
            // Ask the scene manager to no longer display the intro screen
            Manager.SceneObjectManager.RemoveObject(_titleOverlayObject);
            _titleOverlayObject = null;

            // Stop the music
            if(_audioEnabled)
            {
                _musicInstance.Stop();
            }
        }

        public override void UpdateInput(bool mouseLeftClicked, Vector2 mousePosition)
        {
            base.UpdateInput(mouseLeftClicked, mousePosition);

            if(mouseLeftClicked)
            {
                // When the mouse button has been clicked move onto the next state
                Manager.RequestChangeToState("Begin");
            }
        }
    }
}
