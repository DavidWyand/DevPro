using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    /// <summary>
    /// "Startup" game state
    /// </summary>
    class GameStateStartup : GameState
    {
        // Used for the background
        private SceneObject _backgroundObject;
        private float       _backgroundZPos;

        public GameStateStartup()
        {
            _backgroundZPos = GamePlayState.ZPositionBackground;
        }

        public override string GetName()
        {
            return "Startup";
        }

        public override void OnEnter()
        {
            // Create the environment that will be used throughout the game
            CreateEnvironment();

            // Immediately request a change to the main menu
            Manager.RequestChangeToState("MainMenu");
        }

        private void CreateEnvironment()
        {
            // Add the background
            PointSprite backgroundSprite = new PointSprite(Manager.GraphicsDevice, Manager.PointSpriteEffect, GameTextures.BackgroundTexture);
            backgroundSprite.Size = new Vector2(Manager.GraphicsDevice.Viewport.Bounds.Width * 0.5f, Manager.GraphicsDevice.Viewport.Bounds.Height * 0.5f);
            _backgroundObject = new SceneObject(backgroundSprite);
            _backgroundObject.WorldMatrix = Matrix.CreateTranslation(new Vector3(backgroundSprite.Size, _backgroundZPos));

            Manager.SceneObjectManager.AddObject(_backgroundObject);
        }
    }
}
