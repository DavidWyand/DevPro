using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class SceneObject : GameObject
    {

        private string _name = "";

        public string Name
        {
            get { return _name; }
        }

        private bool _deleteMe = false;

        public bool DeleteObject
        {
            get { return _deleteMe; }
        }

        public SceneObject()
        {
        }

        public SceneObject(string name)
        {
            _name = name;
        }

        public SceneObject(RenderObject obj)
            : base(obj)
        {
            _name = "";
        }

        public SceneObject(string name, RenderObject obj)
            : base(obj)
        {
            _name = name;
        }

        public virtual void OnAddedToSceneManager(SceneObjectManager manager)
        {

        }

        public virtual void OnRemovedFromSceneManager(SceneObjectManager manager)
        {

        }

        public virtual void OnDelete()
        {
            // Remove us from any octrees
            List<Octree> octrees = new List<Octree>(_octrees.Keys);
            foreach(Octree o in octrees)
            {
                o.RemoveObject(this);
            }
        }

        public void MarkForDeletion()
        {
            _deleteMe = true;
        }

        public virtual void RenderText(GraphicsDevice graphicsDevice, SpriteBatch spriteBatch)
        {
        }

        protected virtual void DrawShadowedText(SpriteBatch spriteBatch, SpriteFont font, string text, float posX, float posY)
        {
            spriteBatch.DrawString(font, text, new Vector2(posX - 2, posY + 2), Color.DarkSlateGray);
            spriteBatch.DrawString(font, text, new Vector2(posX, posY), Color.White);
        }

        protected virtual void DrawCorrectScoreText(SpriteBatch spriteBatch, SpriteFont font, string text, float posX, float posY)
        {
            spriteBatch.DrawString(font, text, new Vector2(posX - 2, posY + 2), Color.DarkSlateGray);
            spriteBatch.DrawString(font, text, new Vector2(posX, posY), Color.LawnGreen);
        }

        protected virtual void DrawIncorrectScoreText(SpriteBatch spriteBatch, SpriteFont font, string text, float posX, float posY)
        {
            spriteBatch.DrawString(font, text, new Vector2(posX - 2, posY + 2), Color.DarkSlateGray);
            spriteBatch.DrawString(font, text, new Vector2(posX, posY), Color.Red);
        }
    }
}
