using GameDev.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace GameDev.Exercises
{
    class SceneObjectManager
    {
        private List<SceneObject> _objectList = new List<SceneObject>();

        private Dictionary<string, SceneObject> _namedObjectList = new Dictionary<string, SceneObject>();

        public void AddObject(SceneObject obj)
        {
            _objectList.Add(obj);

            obj.OnAddedToSceneManager(this);

            if(obj.Name.Length != 0)
            {
                _namedObjectList.Add(obj.Name, obj);
            }
        }

        public void RemoveObject(SceneObject obj)
        {
            _objectList.Remove(obj);

            if(obj.Name.Length != 0)
            {
                _namedObjectList.Remove(obj.Name);
            }

            obj.OnRemovedFromSceneManager(this);
        }

        public SceneObject FindObjectByName(string name)
        {
            SceneObject obj;
            _namedObjectList.TryGetValue(name, out obj);
            return obj;
        }

        public void CleanUp()
        {
            for (int i = _objectList.Count() - 1; i >= 0; --i )
            {
                if(_objectList[i].DeleteObject)
                {
                    SceneObject obj = _objectList[i];
                    _objectList.RemoveAt(i);

                    if (obj.Name.Length != 0)
                    {
                        _namedObjectList.Remove(obj.Name);
                    }

                    obj.OnRemovedFromSceneManager(this);
                    obj.OnDelete();
                }
            }
        }

        public void Update(GameTime time)
        {
            foreach(SceneObject obj in _objectList)
            {
                obj.Update(time);
            }
        }

        public void Render(GraphicsDevice graphics, Camera camera)
        {
            foreach (SceneObject obj in _objectList)
            {
                if(obj.Visible)
                {
                    obj.Render(graphics, camera);
                }
            }
        }

        public void RenderText(GraphicsDevice graphics, SpriteBatch spriteBatch)
        {
            foreach (SceneObject obj in _objectList)
            {
                if(obj.Visible)
                {
                    obj.RenderText(graphics, spriteBatch);
                }
            }
        }
    }
}
