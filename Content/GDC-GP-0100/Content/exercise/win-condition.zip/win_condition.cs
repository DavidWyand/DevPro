using GameDev.Utilities;
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;

namespace GameDev
{
    class win_condition : Module
    {
        float _ballRadius;
        float _ballSpeed;
        Vector3 _ballVelocity;
        PointSprite _ball;

        GameObject _paddle;
        GameObject[] _walls;
        GameObject[] _blocks;
        
        SpriteBatch _spriteBatch;
        SpriteFont _littleFont;
        SpriteFont _bigFont;

        string _winMessage = "WINNER!!";
        string _gameOverMessage = "GAME OVER";
        string _startMessage = "Click to Start";
        float _gameOverMessageHalfWidth = 0f;
        float _gameOverMessageHeight = 0f;
        float _winMessageHalfWidth = 0f;
        float _winMessageHeight = 0f;
        float _startMessageHalfWidth = 0f;
        float _startMessageHalfHeight = 0f;

        //*********** Begin Focus Area 3 ***********//

        //*********** End Focus Area 3 ***********//

        
        //*********** Begin Focus Area 7 ***********//

        //*********** End Focus Area 7 ***********//
    
    
        

        #region SetupCode
        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
            clearColor = Color.Black;
        }

        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            OrthoCamera cam = new OrthoCamera();
            cam.Bounds = _graphicsDevice.Viewport.Bounds;
            DefaultCamera = cam;

            // Setup some render states
            SetupRenderState();

            // Load font 
            _spriteBatch = new SpriteBatch(_graphicsDevice);
            _littleFont = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");
            _bigFont = _contentManager.Load<SpriteFont>("Fonts\\QuartzMS");

            // Calculate message sizes
            _gameOverMessageHalfWidth = _bigFont.MeasureString(_gameOverMessage).X / 2;
            _gameOverMessageHeight = _bigFont.MeasureString(_gameOverMessage).Y;
            _winMessageHalfWidth = _bigFont.MeasureString(_winMessage).X / 2;
            _winMessageHeight = _bigFont.MeasureString(_winMessage).Y;
            _startMessageHalfWidth = _littleFont.MeasureString(_startMessage).X / 2;
            _startMessageHalfHeight = _littleFont.MeasureString(_startMessage).Y / 2;

            Effect pointSpriteEffect = _contentManager.Load<Effect>("Shaders\\PointSprite.mgfxo");

            // Setup the Walls
            #region WallSetup
            float topMargin = 50;
            float halfWallThickness = 10;
            _walls = new GameObject[3];
            for( int i = 0; i < _walls.Length; i++ )
            {
                PointSprite wallSprite = new PointSprite(_graphicsDevice, pointSpriteEffect, null);
                wallSprite.Color = Color.Blue;
                _walls[i] = new GameObject();
                _walls[i].RenderObjects.Add(wallSprite);
            }
            _walls[0].Position = new Vector3(halfWallThickness, 360 + topMargin, 0);
            ((PointSprite)_walls[0].RenderObjects[0]).Size = new Vector2(halfWallThickness, 360);
            _walls[0].CollisionPrimitives.Add(new Collision_LineSegment(new Vector3(halfWallThickness, 0, 0), Vector3.UnitY, Vector3.UnitX, 0));

            _walls[1].Position = new Vector3(0, halfWallThickness + topMargin, 0);
            ((PointSprite)_walls[1].RenderObjects[0]).Size = new Vector2(1280, halfWallThickness);
            _walls[1].CollisionPrimitives.Add(new Collision_LineSegment(new Vector3(0, halfWallThickness, 0), Vector3.UnitX, Vector3.UnitY, 0));

            _walls[2].Position = new Vector3(_graphicsDevice.Viewport.Bounds.Right - halfWallThickness, 360 + topMargin, 0);
            ((PointSprite)_walls[2].RenderObjects[0]).Size = new Vector2(halfWallThickness, 360);
            _walls[2].CollisionPrimitives.Add(new Collision_LineSegment(new Vector3(-halfWallThickness, 0, 0), Vector3.UnitY, -Vector3.UnitX, 0));
            #endregion

            // Setup the Blocks
            #region BlockSetup
            int blocksPerRow = 28;
            int rows = 6;
            Color[] rowColors = new Color[rows];
            rowColors[0] = Color.Red;
            rowColors[1] = Color.Orange;
            rowColors[2] = Color.Yellow;
            rowColors[3] = Color.Green;
            rowColors[4] = Color.Blue;
            rowColors[5] = Color.Purple;

            _blocks = new GameObject[blocksPerRow * rows];
            int index = 0;
            float blockMargin = 80;
            float blockHeight = 10;
            float blockWidth = 42;
            float halfBlockWidth = blockWidth * 0.5f;
            float halfBlockHeight = blockHeight * 0.5f;
            float rowLeft = (halfWallThickness * 2) + 5 + halfBlockWidth;
            for (int y = rows - 1; y >= 0; y--)
            {
                for (int x = 0; x < blocksPerRow; x++)
                {
                    PointSprite blockSprite = new PointSprite(_graphicsDevice, pointSpriteEffect, null);
                    blockSprite.Color = rowColors[y];
                    blockSprite.Size = new Vector2(halfBlockWidth, halfBlockHeight);

                    GameObject block = new GameObject();
                    block.Position = new Vector3(rowLeft + (x * (blockWidth + 2)), topMargin + blockMargin + (y * blockHeight), 0);
                    block.RenderObjects.Add(blockSprite);

                    // Bottom collision
                    block.CollisionPrimitives.Add(new Collision_LineSegment(new Vector3(0, halfBlockHeight, 0), Vector3.UnitX, Vector3.UnitY, halfBlockWidth + 3));

                    // Top collision
                    block.CollisionPrimitives.Add(new Collision_LineSegment(new Vector3(0, -halfBlockHeight, 0), Vector3.UnitX, -Vector3.UnitY, halfBlockWidth + 3));
                    
                    // Left collision
                    block.CollisionPrimitives.Add(new Collision_LineSegment(new Vector3(-halfBlockWidth, 0, 0), Vector3.UnitY, -Vector3.UnitX, halfBlockHeight));

                    // Right collision
                    block.CollisionPrimitives.Add(new Collision_LineSegment(new Vector3(halfBlockWidth, 0, 0), Vector3.UnitY, Vector3.UnitX, halfBlockHeight));
                    _blocks[index++] = block;
                }
            }
            #endregion

            // Setup the player paddle
            _paddle = new GameObject();
            PointSprite paddleSprite = new PointSprite(_graphicsDevice, pointSpriteEffect, null);
            paddleSprite.Size = new Vector2(80, 10);
            _paddle.Position = new Vector3(640, 680, 0);
            Collision_LineSegment paddleCollision = new Collision_LineSegment(new Vector3(0, -paddleSprite.Size.Y, 0), Vector3.UnitX, -Vector3.UnitY, paddleSprite.Size.X);            
            _paddle.RenderObjects.Add(paddleSprite);
            _paddle.CollisionPrimitives.Add(paddleCollision);
            
            // Setup the Ball
            _ball = new PointSprite(_graphicsDevice, pointSpriteEffect, _contentManager.Load<Texture2D>("Graphics\\football"));
            _ballRadius = 10.0f;
            _ball.Size = new Vector2(_ballRadius, _ballRadius);

            ResetBall();
            ResetBlocks();         
        }

        void ResetBall()
        {
            _ballSpeed = 250;
            _ball.Position = new Vector3(340, 360, 0);
            _ballVelocity = Vector3.Normalize(new Vector3(1, 1, 0)) * _ballSpeed;       
        }          

        void ResetBlocks()
        {
            foreach (GameObject block in _blocks)
                block.Visible = true;
        }

        #endregion


        void StartGame()
        {
        //*********** Begin Focus Area 12 ***********//

            //*********** End Focus Area 12 ***********//

        }

        public override void UpdateInput(KeyboardState keyboardState, MouseState mouseState)
        {
            base.UpdateInput(keyboardState, mouseState);

            // Paddle update
            float wallThickness = ((PointSprite)_walls[0].RenderObjects[0]).Size.X * 2;
            float paddleWidth = ((PointSprite)_paddle.RenderObjects[0]).Size.X;
            //*********** Begin Focus Area 2 ***********//

            //*********** End Focus Area 2 ***********//

          



            //*********** Begin Focus Area 11 ***********//

            //*********** End Focus Area 11 ***********//

          
        }
       

        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            //*********** Begin Focus Area 4 ***********//

            //*********** End Focus Area 4 ***********//


            //*********** Begin Focus Area 8 ***********//

            //*********** End Focus Area 8 ***********//



            // Ball Update
            //*********** Begin Focus Area 10 ***********//

            //*********** End Focus Area 10 ***********//

          
            {
                Vector3 ballNewPosition = _ball.Position + (_ballVelocity * (float)time.ElapsedGameTime.TotalSeconds);

                //*********** Begin Focus Area 1 ***********//

                //*********** End Focus Area 1 ***********//

                _ball.Position = ballNewPosition;          
            }          
        }

        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            // Draw Walls
            foreach (GameObject wall in _walls)
            {
                wall.Render(_graphicsDevice, DefaultCamera);
            }

            // Draw Blocks
            foreach (GameObject block in _blocks)
            {
                block.Render(_graphicsDevice, DefaultCamera);
            }

            // Draw Ball
            _ball.Render(_graphicsDevice, DefaultCamera, Matrix.Identity);

            // Draw Paddle
            _paddle.Render(_graphicsDevice, DefaultCamera);

            
            // Draw Text
            _spriteBatch.Begin();
            //*********** Begin Focus Area 5 ***********//

            //*********** End Focus Area 5 ***********//

                                   
            
            //*********** Begin Focus Area 6 ***********//

            //*********** End Focus Area 6 ***********//



            //*********** Begin Focus Area 9 ***********//

            //*********** End Focus Area 9 ***********//

            _spriteBatch.End();

            SetupRenderState();
        }

        Collision_HitInfo CheckForCollision(Vector3 start, Vector3 end)
        {
            // Check paddle
            foreach (Collision_Primitive prim in _paddle.CollisionPrimitives)
            {
                if (prim.CheckSphere(start, end, _ballRadius, _paddle.WorldMatrix))
                    return prim.HitInfo;
            }

            // Check blocks
            {
                foreach(GameObject block in _blocks)
                {
                    if (block.Visible)
                    {
                        foreach (Collision_Primitive prim in block.CollisionPrimitives)
                        {
                            if (prim.CheckSphere(start, end, _ballRadius, block.WorldMatrix))
                            {
                                block.Visible = false;
                                return prim.HitInfo;
                            }
                        }
                    }
                }
            }

            // Check walls
            foreach (GameObject wall in _walls)
            {
                foreach (Collision_Primitive prim in wall.CollisionPrimitives)
                {
                    if (prim.CheckSphere(start, end, _ballRadius, wall.WorldMatrix))
                        return prim.HitInfo;
                }
            }

            return null;
        }
    }
}
